import request from '@/utils/request'

// 获取自然资源信息接口
export const getHousebuildInfo = (params) => request({ url: '/housebuild/info', method: 'get', params })

// 修改房屋建筑信息接口
export const updateHousebuildInfo = (id, data) => request({ url: `/housebuild/${id}`, method: 'put', data })

// 添加房屋建筑信息接口
export const addHousebuildInfo = data => request({ url: '/housebuild/add', method: 'post', data })

// 删除房屋建筑信息接口
export const removeHousebuildInfo = id => request({ url: `/housebuild/info/${id}/off`, method: 'post' })

// 批量删除房屋建筑信息接口
export const batchRemoveHousebuildInfo = ids => request({ url: '/housebuild/info/batchremove', method: 'post', data: ids })
