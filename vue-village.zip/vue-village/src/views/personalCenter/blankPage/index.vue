<template>
  <div />
</template>

<script>
export default {
  name: 'BlankPage',
  data() {
    this.$router.replace({
      path: '/personalcenter/personalinformation',
      name: 'PersonalInformation'
    })
    return {}
  }
}
</script>

<style scoped></style>
