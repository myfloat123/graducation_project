import request from '@/utils/request'

// 新增帮扶计划
export const addAssistplanInfo = data => request({ url: '/assistplan/add', method: 'post', data })

// 查看帮扶计划
export const examineAssistplanInfo = () => request({ url: '/assistplan/', method: 'get' })

// 通过id获取某个帮扶计划
export const getOneAssistplanInfo = (id) => request({ url: `/assistplan/${id}`, method: 'get' })

// 通过assist_code获取某个帮扶计划
export const getOneAssistplanInfoByAssistCode = (assist_code) => request({ url: `/assistplan/get/${assist_code}`, method: 'get' })

// 修改帮扶计划
export const updateAssistplanInfo = (id, data) => request({ url: `/assistplan/${id}`, method: 'put', data })

// 删除帮扶计划
export const deleteAssistplan = id => request({ url: `/assistplan/${id}/off`, method: 'post' })

// 通过帮扶编号删除帮扶计划
export const deleteAssistplanByAssistCode = assist_code => request({ url: `/assistplan/remove/${assist_code}/off`, method: 'post' })

// 通过帮扶编号批量删除帮扶计划
export const removeAssistplanByAssistCode = assist_codes => request({ url: '/assistplan/batchremoves/assist_code/off', method: 'post', data: assist_codes })
