<template>
  <div>
    <el-container class="container">
      <el-header>个人信息</el-header>
      <el-main>
        <div class="top">
          <div class="left"><span>用户名</span><el-input :value="user_name" /></div>
          <div class="right"><span class="role">角色</span><el-input :value="role" /></div>
        </div>
        <div class="bottom">
          <el-row>
            <el-col :span="6" class="box">
              <span>用户头像</span>
              <el-upload class="avatar-uploader" action="/dev-api/users/" :show-file-list="false" :on-success="handleAvatarSuccess" :before-upload="beforeAvatarUpload">
                <!-- eslint-disable -->
                <img v-if="avatar.indexOf('http') === -1" :src="'http://localhost:8000/' + avatar" class="avatar" />
                <img v-else-if="avatar.indexOf('http') !== -1" :src="avatar + '?imageView2/1/w/80/h/80'" class="avatar" />
                <i v-else class="el-icon-plus avatar-uploader-icon" />
                <div slot="tip" class="el-upload__tip">只能上传png/jpg/jpeg/gif文件，且不超过5MB</div>
              </el-upload>
            </el-col>
          </el-row>
        </div>
      </el-main>
    </el-container>
  </div>
</template>

<script>
export default {
  name: 'PersonalInformation',
  data() {
    return {
      user_name: '',
      role: '管理员',
      avatar: ''
    }
  },
  // watch: {
  //   avatar: {
  //     /* eslint-disable */
  //     handler: function (newVal, oldVal) {
  //       this.avatar = newVal
  //     }
  //     // immediate: true
  //   }
  // },
  mounted() {
    this.getUserInfo()
  },
  methods: {
    async getUserInfo() {
      const res = await this.$API.user.getInfo()
      // console.log(res)
      if (res.code === 0) {
        this.user_name = res.result.user_name
        switch (res.result.role_name) {
          case null:
            this.role = '管理员'
            break
          case '行政村领导':
            this.role = '行政村领导'
            break
          case '办事员':
            this.role = '办事员'
            break
          case '会计':
            this.role = '会计'
            break
        }
        this.avatar = res.result.avatar
      }
    },
    beforeAvatarUpload(file) {
      const fileTypes = ['image/png', 'image/jpg', 'image/jpeg', 'image/gif']
      if (!fileTypes.includes(file.type)) {
        this.$message.error('上传头像图片仅支持png、jpg、jpeg、gif 格式！')
      }
      if (!(file.size / 1024 / 1024 < 5)) {
        this.$message.error('上传头像图片大小不能超过 5MB！')
      }
      return file.type && file.size / 1024 / 1024 < 5
    },
    async handleAvatarSuccess(res, file) {
      this.avatar = res.result.imgUrl
      // this.$router.replace({
      //   path: '/personalcenter/blankpage',
      //   name: 'BlankPage'
      // })
      // this.$router.replace(window.localStorage.getItem('fullpath'))
      this.$store.commit('user/SET_AVATAR', this.avatar)
      this.$nextTick(() => {
        this.$message({
          type: 'success',
          message: '更新头像成功'
        })
      })
    }
  }
}
</script>

<style scoped>
.container {
  padding: 10px;
}
.el-header {
  border-radius: 5px 5px 0px 0px;
  background-color: #b3c0d1;
  color: #333;
  text-align: center;
  line-height: 60px;
}

.el-main {
  border-radius: 0px 0px 5px 5px;
  background-color: #fff;
  color: #333;
  text-align: center;
  /* line-height: 160px; */
}

.top {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.el-input__inner {
  margin-left: 15px;
}

span {
  width: 100px;
  text-align: center;
  line-height: 40px;
}

.left {
  display: flex;
  width: 50%;
  /* background-color: pink; */
}

.right {
  display: flex;
  width: 50%;
  /* background-color: skyblue; */
}

.role {
  position: relative;
  left: 10px;
}
</style>

<style>
.avatar-uploader .el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
.avatar-uploader .el-upload:hover {
  border-color: #409eff;
}
.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 178px;
  height: 178px;
  line-height: 178px;
  text-align: center;
}
.avatar {
  width: 178px;
  height: 178px;
  display: block;
}

.box {
  display: flex;
  margin-top: 20px;
}
</style>
