<template>
  <div>村务信息管理</div>
</template>

<script>
export default {
  name: 'VillageAffairs'
}
</script>

<style scoped></style>
