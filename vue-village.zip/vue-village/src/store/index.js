import Vue from 'vue'
import Vuex from 'vuex'
import getters from './getters'
import app from './modules/app'
import settings from './modules/settings'
import user from './modules/user'
import household from './modules/household.store'
import income from './modules/income'
import pay from './modules/pay'
import article from './modules/article'
import permission from './modules/permission'
import url from './modules/url'

Vue.use(Vuex)

const store = new Vuex.Store({
  modules: {
    app,
    settings,
    user,
    household,
    income,
    pay,
    article,
    permission,
    url
  },
  getters
})

export default store
