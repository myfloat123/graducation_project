const data = require('./data1.json')
module.exports = [
  {
    url: '/pay/list',
    type: 'get',
    response: config => {
      // const items = data.items
      return {
        code: 20000,
        data
      }
    }
  }
]
