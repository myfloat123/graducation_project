<template>
  <div>资产信息管理</div>
</template>

<script>
export default {
  name: 'AssetInformation'
}
</script>

<style scoped></style>
