import request from '@/utils/request'

// 获取土地流转信息
export const getLandInfo = (params) => request({ url: '/land/info', method: 'get', params })

// 修改土地流转信息
export const updateLandInfo = (id, data) => request({ url: `/land/${id}`, method: 'put', data })

// 新增土地流转信息
export const addLandInfo = data => request({ url: '/land/add', method: 'post', data })

// 删除土地流转信息
export const removeLandInfo = id => request({ url: `/land/info/${id}/off`, method: 'post' })

// 批量删除土地流转信息
export const batchremoveLandInfo = ids => request({ url: '/land/info/batchremove', method: 'post', data: ids })
