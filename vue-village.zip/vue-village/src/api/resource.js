import request from '@/utils/request'

// 获取自然资源信息接口
export const getResourceInfo = (params) => request({ url: '/resource/info', method: 'get', params })

// 新增自然资源信息接口
export const addResourceInfo = data => request({ url: '/resource/add', method: 'post', data })

// 修改自然资源信息接口
export const updateResourceInfo = (id, data) => request({ url: `/resource/${id}`, method: 'put', data })

// 删除自然资源信息接口
export const removeResourceInfo = id => request({ url: `/resource/info/${id}/off`, method: 'post' })

// 批量删除自然资源信息接口
export const batchRemoveResourceInfo = ids => request({ url: '/resource/info/batchremove', method: 'post', data: ids })
