<template>
  <div>贫困户信息管理</div>
</template>

<script>
export default {
  name: 'Poor'
}
</script>

<style scoped></style>
