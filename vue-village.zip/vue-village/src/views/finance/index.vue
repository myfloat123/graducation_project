<template>
  <div>村务财务状况管理模块</div>
</template>

<script>
export default {
  name: 'Finance'
}
</script>

<style scoped></style>
