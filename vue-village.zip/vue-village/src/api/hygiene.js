import request from '@/utils/request'

// 获取环境卫生信息
export const getHygieneInfo = (params) => request({ url: '/hygiene/info', method: 'get', params })

// 修改环境卫生信息
export const updatehygieneInfo = (id, data) => request({ url: `/hygiene/${id}`, method: 'put', data })

// 新增环境卫生信息
export const addHygieneInfo = data => request({ url: '/hygiene/add', method: 'post', data })

// 删除环境卫生信息
export const removeHygieneInfo = id => request({ url: `/hygiene/info/${id}/off`, method: 'post' })

// 批量删除环境卫生信息
export const batchRemoveHygieneInfo = ids => request({ url: '/hygiene/info/batchremove', method: 'post', data: ids })
