const state = {
  household_relation_length: 0
}
const mutations = {
  addLength(state, household_relation_length) {
    state.household_relation_length = household_relation_length
  }
}
const actions = {}
const getters = {}

export default {
  state,
  mutations,
  actions,
  getters
}
