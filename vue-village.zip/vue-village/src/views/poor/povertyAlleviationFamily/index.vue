<template>
  <div class="container">
    <el-form ref="form" label-width="80px" inline>
      <!-- 表单元素 -->
      <el-form-item>
        <el-input v-model="tempSearchObj.household_number" placeholder="户号" />
      </el-form-item>
      <el-form-item>
        <el-input v-model="tempSearchObj.household_name" placeholder="户主姓名" />
      </el-form-item>
      <!-- 查询与清空按钮 -->
      <!--  -->
      <!--  -->
      <el-button type="primary" icon="el-icon-search" @click="search">查询</el-button>
      <el-button type="default" @click="resetSearch">清空</el-button>
    </el-form>

    <!-- table表格：展示户口信息 -->
    <!-- @selection-change="handleSelectionChange" -->
    <el-table v-loading="listLoading" stripe :data="householdData" style="width: 100%" border>
      <el-table-column type="selection" width="55" />
      <el-table-column type="index" align="center" width="55" label="序号" />
      <el-table-column type="expand">
        <template slot-scope="props">
          <el-form label-position="left" inline class="demo-table-expand">
            <el-form-item label="户号">
              <span>{{ props.row.household_number }}</span>
            </el-form-item>
            <el-form-item label="户主姓名">
              <span>{{ props.row.household_name }}</span>
            </el-form-item>
            <el-form-item label="性别">
              <span>{{ props.row.household_sex }}</span>
            </el-form-item>
            <el-form-item label="身份证号">
              <span>{{ props.row.household_ID }}</span>
            </el-form-item>
            <el-form-item label="出生日期">
              <span>{{ props.row.household_birthday }}</span>
            </el-form-item>
            <el-form-item label="联系方式">
              <span>{{ props.row.household_phone }}</span>
            </el-form-item>
            <div v-for="item in props.row.household_relation" :key="item.id">
              <el-form-item label="姓名">
                <span>{{ item.name }}</span>
              </el-form-item>
              <el-form-item label="关系">
                <span>{{ item.relation }}</span>
              </el-form-item>
            </div>
          </el-form>
        </template>
      </el-table-column>
      <el-table-column label="户号" prop="household_number" />
      <el-table-column label="户主姓名" prop="household_name" />
      <el-table-column label="身份证号" prop="household_ID" />
      <el-table-column label="是否贫困" prop="is_poor_household">
        <template slot-scope="{ row, $index }">
          <el-select v-model="row.is_poor_household" @change="updatePoorHousehold(row, $index)">
            <el-option v-for="item in dict_is_poor_household" :key="item.id" :label="item.is_poor_household" :value="item.is" />
          </el-select>
        </template>
      </el-table-column>
      <!-- <el-table-column header-align="center" align="center" label="操作">
        <template slot-scope="{ row, $index }">
          <el-button type="info" size="mini" @click="showHouseholdDetail(row, $index)">查看</el-button>
        </template>
      </el-table-column> -->
    </el-table>

    <!-- 分页器 -->
    <!--   -->
    <el-pagination style="margin-top: 20px; text-align: center" :current-page="page" :page-sizes="[3, 5, 10]" :page-count="7" :page-size.sync="limit" layout="prev, pager, next, jumper, ->, sizes, total" :total="total" @current-change="handleCurrentChange" @size-change="handleSizeChange" />
  </div>
</template>

<script>
export default {
  name: 'PovertyAlleviationFamily',
  data() {
    return {
      // 当前页
      page: 1,
      // 每页显示数据条数
      limit: 3,
      // 总数
      total: 0,
      // 是否显示列表加载的提示
      listLoading: false,
      // 是否查看贫困家庭信息
      disabled_household: false,
      // 每页所有贫困户口信息
      householdData: [],
      // 每页贫困家庭信息列表
      pageList: [],
      // 贫困家庭信息列表
      list: [],
      // 收集搜索条件输入的对象
      tempSearchObj: {
        household_number: '',
        household_name: ''
      },
      // 搜索条件的对象
      searchObj: {
        household_number: '',
        household_name: ''
      },
      // 户主信息
      household: {
        household_number: '',
        household_name: '',
        household_sex: '',
        household_ID: '',
        household_birthday: '',
        household_phone: '',
        is_poor_household: ''
      },
      // 是否贫困字典
      dict_is_poor_household: [
        { id: 1, is: false, is_poor_household: '否' },
        { id: 2, is: true, is_poor_household: '是' }
      ]
    }
  },
  mounted() {
    this.getHouseholdData()
  },
  methods: {
    // 获取户口信息
    async getHouseholdData(page = 1, limit = 3, searchObj = { household_number: '', household_name: '' }) {
      this.page = page
      this.limit = limit
      this.searchObj = searchObj
      let params = { page, limit, ...searchObj }
      this.listLoading = true
      const res1 = await this.$API.household.getHouseholdNotPoorInfo(params)
      const res2 = await this.$API.relation.getRelationInfo(page, limit)
      this.listLoading = false
      console.log(res1)
      if (res1.code === 0) {
        res1.result.pageList.forEach(household => {
          this.dict_is_poor_household.forEach(item => {
            if (household.is_poor_household === item.is) {
              household.is_poor_household = item.is_poor_household
            }
          })
        })
        res1.result.list.forEach(household => {
          this.dict_is_poor_household.forEach(item => {
            if (household.is_poor_household === item.is) {
              household.is_poor_household = item.is_poor_household
            }
          })
        })
        this.pageList = res1.result.pageList
        this.householdData = res1.result.pageList
        this.list = res1.result.list
        this.total = res1.result.total
      }
      if (res2.code === 0) {
        this.relationList = res2.result.list
        this.relationTotal = res2.result.total
        this.householdData.forEach(household => {
          household.household_relation = []
          this.relationList.forEach(relation => {
            if (household.household_number === relation.household_number) {
              household.household_relation.push(relation)
            }
          })
        })
      } else {
        return Promise.reject(new Error('faile'))
      }
    },
    // 修改是否贫困
    async updatePoorHousehold(household, index) {
      console.log(household, index)
      const res = await this.$API.household.patchUpdateHouseholdPoor(household.id, { is_poor_household: household.is_poor_household })
      console.log(res)
      if (res.code === 0) {
        this.$message({
          type: 'success',
          message: '更新成功'
        })
        this.getHouseholdData(this.page, this.limit, this.searchObj)
      }
    },
    // 查询
    search() {
      this.searchObj = { ...this.tempSearchObj }
      this.getHouseholdData(this.page, this.limit, this.searchObj)
    },
    // 清空
    resetSearch() {
      this.searchObj = {
        household_number: '',
        household_name: ''
      }
      this.tempSearchObj = {
        household_number: '',
        household_name: ''
      }
      this.getHouseholdData()
    },
    handleCurrentChange(page) {
      console.log(page)
      this.page = page
      this.getHouseholdData(this.page, this.limit)
    },
    handleSizeChange(limit) {
      console.log(limit)

      this.limit = limit
      this.getHouseholdData(this.page, this.limit)
    }
  }
}
</script>

<style scoped>
.container {
  padding: 20px 20px;
}
.demo-table-expand {
  font-size: 0;
}
.demo-table-expand label {
  width: 90px;
  color: #99a9bf;
}
.demo-table-expand .el-form-item {
  margin-right: 0;
  margin-bottom: 0;
  width: 50%;
}
</style>
