const Article = () => import('@/views/dashboard/article')

export default [
  {
    path: '/article/:id',
    component: Article,
    meta: { show: true },
    name: 'article',
    props: ($route) => ({ id: $route.params.id })
  }
]
