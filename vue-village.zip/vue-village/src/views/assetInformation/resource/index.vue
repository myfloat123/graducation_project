<template>
  <div class="container">
    <el-form inline style="margin-top: 20px">
      <!-- 表单元素 -->
      <el-form-item>
        <el-input v-model="tempSearchObj.resource_code" placeholder="资源编号" />
      </el-form-item>
      <el-form-item>
        <el-input v-model="tempSearchObj.resource_name" placeholder="资源名称" />
      </el-form-item>
      <el-form-item>
        <el-select v-model="tempSearchObj.resource_kind" placeholder="资源种类">
          <el-option v-for="item in dict_resource_kind" :key="item.id" :label="item.resource_kind" :value="item.id" />
        </el-select>
      </el-form-item>
      <!-- 查询与清空按钮 -->
      <!--  @click="resetSearch" -->
      <el-button type="primary" icon="el-icon-search" @click="search">查询</el-button>
      <el-button type="default" @click="resetSearch">清空</el-button>
    </el-form>

    <div style="margin-bottom: 20px">
      <!-- 添加与批量删除按钮 -->
      <el-button type="primary" icon="el-icon-plus" @click="showAddResource">添加</el-button>
      <el-button type="danger" icon="el-icon-delete" :disabled="selectedIds.length === 0" @click="batchRemove">批量删除</el-button>
    </div>

    <!-- table表格：展示自然资源信息 -->
    <!--  -->
    <el-table v-loading="listLoading" border stripe :data="pageList" style="width: 100%" @selection-change="handleSelectionChange">
      <el-table-column type="selection" />
      <el-table-column type="index" label="序号" align="center" width="55" />
      <el-table-column prop="resource_code" label="资源编号" align="center" width="150" />
      <el-table-column prop="resource_name" label="资源名称" align="center" width="150" />
      <el-table-column prop="resource_picture" label="图片" align="center" width="250">
        <template slot-scope="{ row }">
          <!-- eslint-disable -->
          <img :src="`http://localhost:8000/${row.resource_picture}`" alt="" style="width: 100px; height: 100px; text-align: center" />
        </template>
      </el-table-column>
      <el-table-column prop="resource_kind" label="资源种类" align="center" width="150">
        <!-- <template slot-scope="{ row }">
          <el-select placeholder="资源种类">
            <el-option v-for="item in dict_resource_kind" :key="item.id" :label="item.resource_kind" :value="item.id" />
          </el-select>
        </template> -->
      </el-table-column>
      <el-table-column prop="resource_reserves" label="资源储量" align="center" width="100" />
      <el-table-column prop="resource_reserves_unit" label="单位" align="center" width="100" />
      <el-table-column prop="resource_location" label="位置" align="center" width="100" />
      <el-table-column prop="resource_use" label="用途" align="center" width="200" />
      <el-table-column label="操作" align="center" width="400" fixed="right">
        <template slot-scope="{ row }">
          <!-- @click="updateVillager(row)" -->
          <!-- @click="removeVillager(row)"  -->
          <el-button type="info" icon="el-icon-info" size="mini" @click="showResourceDetail(row)">查看</el-button>
          <el-button type="warning" icon="el-icon-edit" size="mini" @click="showUpdateResource(row)">修改</el-button>
          <el-button type="danger" icon="el-icon-delete" size="mini" @click="removeResource(row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页器 -->
    <!--  -->
    <!--  -->
    <el-pagination style="margin-top: 20px; text-align: center" :current-page="page" :page-sizes="[3, 5, 10]" :page-count="7" :page-size.sync="limit" layout="prev, pager, next, jumper, ->, sizes, total" :total="total" @current-change="handleCurrentChange" @size-change="handleSizeChange" />

    <!-- 添加/修改自然资源信息弹窗 -->
    <!-- :before-close="dialogBeforeClose" -->
    <el-dialog :title="resource.id ? `${disabled_resource ? '查看' : '修改'}自然资源信息` : '添加自然资源信息'" :visible.sync="dialogVisible" :before-close="handleClose">
      <el-form :model="resource" :rules="resourceRules" inline label-width="120px" ref="resourceForm">
        <el-form-item label="资源编号" prop="resource_code">
          <el-input v-model="resource.resource_code" :disabled="disabled_resource ? true : false"></el-input>
        </el-form-item>
        <el-form-item label="资源名称" prop="resource_name">
          <el-input v-model="resource.resource_name" :disabled="disabled_resource ? true : false"></el-input>
        </el-form-item>

        <el-form-item label="资源种类" prop="resource_kind">
          <el-select v-model="resource.resource_kind" :disabled="disabled_resource ? true : false">
            <el-option v-for="item in dict_resource_kind" :key="item.id" :label="item.resource_kind" :value="item.id" />
          </el-select>
        </el-form-item>

        <el-form-item label="位置" prop="resource_location">
          <el-input v-model="resource.resource_location" :disabled="disabled_resource ? true : false"></el-input>
        </el-form-item>

        <div class="reserves">
          <el-form-item label="资源储量" prop="resource_reserves">
            <el-input v-model="resource.resource_reserves" :disabled="disabled_resource ? true : false"> </el-input>
          </el-form-item>
          <el-form-item prop="resource_reserves_unit" style="width: 110px">
            <el-select v-model="resource.resource_reserves_unit" placeholder="单位" :disabled="disabled_resource ? true : false">
              <el-option v-for="item in dict_resource_reserves_unit" :key="item.id" :label="item.resource_reserves_unit" :value="item.id" />
            </el-select>
          </el-form-item>
        </div>
        <div class="uploadAndUse">
          <el-form-item label="图片" prop="resource_picture">
            <el-upload class="avatar-uploader" action="/dev-api/resource/upload" :show-file-list="false" :on-success="handleAvatarSuccess" :before-upload="beforeAvatarUpload" :disabled="disabled_resource ? true : false">
              <!-- eslint-disable -->
              <i v-if="resource.resource_picture === ''" class="el-icon-plus avatar-uploader-icon" />
              <!-- <img v-else-if="villager.villager_picture === null ? true : false" src="http://localhost:8000/1b84679d1b1c4b1879ce89200.gif" class="avatar" /> -->

              <img v-else :src="'http://localhost:8000/' + resource.resource_picture" class="avatar" />
              <div slot="tip" class="el-upload__tip">只能上传png/jpg/jpeg/gif文件，且不超过5MB</div>
            </el-upload>
          </el-form-item>
          <el-form-item label="用途" prop="resource_use">
            <el-input v-model="resource.resource_use" type="textarea" placeholder="请输入内容" :autosize="{ minRows: 5, maxRows: 10 }" :cols="100" :disabled="disabled_resource ? true : false"></el-input>
          </el-form-item>
        </div>
      </el-form>
      <div slot="footer" v-show="!disabled_resource">
        <el-button @click="cancel">取 消</el-button>
        <el-button type="primary" @click="resource.id ? updateResource() : addResource()">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import Cookies from 'js-cookie'
export default {
  name: 'Resource',
  // 种类字典
  data() {
    return {
      // 资源种类字典
      dict_resource_kind: [
        { id: 1, resource_kind: '矿产资源' },
        { id: 2, resource_kind: '水资源' },
        { id: 3, resource_kind: '森林资源' },
        { id: 4, resource_kind: '土地资源' },
        { id: 5, resource_kind: '生物资源' },
        { id: 6, resource_kind: '农业资源' },
        { id: 7, resource_kind: '其他资源' }
      ],
      // 储量单位字典
      dict_resource_reserves_unit: [
        { id: 1, resource_reserves_unit: '吨' },
        { id: 2, resource_reserves_unit: '升' },
        { id: 3, resource_reserves_unit: '亩' },
        { id: 4, resource_reserves_unit: '只' },
        { id: 5, resource_reserves_unit: '个' },
        { id: 6, resource_reserves_unit: '平方千米' }
      ],
      // 当前页码
      page: 1,
      // 每页数量
      limit: 3,
      // 总数量
      total: 0,
      // 是否显示列表加载的提示
      listLoading: false,
      // 是否显示用户添加/修改的dialog
      dialogVisible: false,
      // 是否查看自然资源信息
      disabled_resource: false,
      // 每页自然资源信息列表
      pageList: [],
      // 自然资源信息列表
      list: [],
      // 所有选择的resource的id数组
      selectedIds: [],
      // 收集搜索条件输入的对象
      tempSearchObj: {
        resource_code: '',
        resource_name: '',
        resource_kind: ''
      },
      // 包含请求搜索条件数据的对象
      searchObj: {
        resource_code: '',
        resource_name: '',
        resource_kind: ''
      },
      // 当前操作的自然资源信息对象
      resource: {
        resource_code: '',
        resource_name: '',
        resource_picture: '',
        resource_kind: '',
        resource_reserves: '',
        resource_location: '',
        resource_use: '',
        resource_reserves_unit: ''
      },
      // 自然资源信息验证规则
      resourceRules: {
        resource_code: [{ required: true, message: '请输入资源编号', trigger: 'blur' }],
        resource_name: [{ required: true, message: '请输入资源名称', trigger: 'blur' }],
        resource_picture: [{ required: false, message: '请上传图片', trigger: 'blur' }],
        resource_kind: [{ required: true, message: '请选择资源种类', trigger: 'blur' }],
        resource_reserves: [{ required: true, message: '请填写资源储量', trigger: 'blur' }],
        resource_reserves_unit: [{ required: true, message: '请选择单位', trigger: 'blur' }],
        resource_location: [{ required: true, message: '请填写位置', trigger: 'blur' }],
        resource_use: [{ required: false, message: '请填写用途', trigger: 'blur' }]
      }
    }
  },
  mounted() {
    this.getResourceData()
  },
  methods: {
    // 获取自然资源信息
    async getResourceData(page = 1, limit = 3, searchObj = { resource_code: '', resource_name: '', resource_kind: '' }) {
      this.page = page
      this.limit = limit
      this.searchObj = searchObj
      this.listLoading = true
      let params = { page, limit, ...searchObj }
      const res = await this.$API.resource.getResourceInfo(params)
      this.listLoading = false
      if (res.code === 0) {
        res.result.pageList.forEach(resource => {
          this.dict_resource_kind.forEach(item => {
            if (item.id === resource.resource_kind) {
              resource.resource_kind = item.resource_kind
            }
          })
        })
        res.result.pageList.forEach(resource => {
          this.dict_resource_reserves_unit.forEach(item => {
            if (item.id === resource.resource_reserves_unit) {
              resource.resource_reserves_unit = item.resource_reserves_unit
            }
          })
        })
        this.pageList = res.result.pageList
        this.list = res.result.list
        this.total = res.result.total
      }
    },
    // 搜索自然资源信息
    search() {
      this.searchObj = { ...this.tempSearchObj }
      this.getResourceData(this.page, this.limit, this.searchObj)
    },
    // 清空
    resetSearch() {
      this.searchObj = {
        resource_code: '',
        resource_name: '',
        resource_kind: ''
      }
      this.tempSearchObj = {
        resource_code: '',
        resource_name: '',
        resource_kind: ''
      }

      this.getResourceData()
    },
    // 显示添加自然资源信息弹窗
    showAddResource() {
      this.dialogVisible = true
      this.resource.resource_code = 'ZRZY' + `${+new Date()}`.slice(-4) || ''
    },
    // 添加自然资源信息
    addResource() {
      this.$refs['resourceForm'].validate(async valid => {
        if (valid) {
          const res = await this.$API.resource.addResourceInfo(this.resource)
          console.log(res)
          if (res.code === 0) {
            this.$message({
              type: 'success',
              message: '新增自然资源信息成功'
            })
            this.total = this.total + 1
            this.dialogVisible = false
            this.getResourceData(this.resource.id ? this.page : 1, this.limit, this.searchObj)
            this.resource = {
              resource_code: '',
              resource_name: '',
              resource_picture: '',
              resource_kind: '',
              resource_reserves: '',
              resource_location: '',
              resource_use: '',
              resource_reserves_unit: ''
            }
          } else {
            console.log('error submit!!')
            return false
          }
        }
      })
      this.dialogVisible = false
    },
    // 图片上传之前的函数处理
    beforeAvatarUpload(file) {
      const fileTypes = ['image/png', 'image/jpg', 'image/jpeg', 'image/gif']
      if (!fileTypes.includes(file.type)) {
        this.$message.error('上传图片仅支持png、jpg、jpeg、gif 格式！')
      }
      if (!(file.size / 1024 / 1024 < 5)) {
        this.$message.error('上传图片大小不能超过 5MB！')
      }
      const token = Cookies.get('vue_admin_template_token')
      console.log(token)
      return file.type && file.size / 1024 / 1024 < 5
    },
    // 图片上传成功后的函数处理
    async handleAvatarSuccess(res, file) {
      this.resource.resource_picture = res.result.resource_picture
      // this.$router.replace({
      //   path: '/personalcenter/blankpage',
      //   name: 'BlankPage'
      // })
      // this.$router.go(0)
    },
    // 处理当前页变化
    handleCurrentChange(page) {
      this.page = page
      this.getResourceData(this.page, this.limit, this.searchObj)
    },
    // 处理每页显示数目变化
    handleSizeChange(limit) {
      this.limit = limit
      this.getResourceData(this.page, this.limit, this.searchObj)
    },
    // 查看自然资源信息详情
    showResourceDetail(resource) {
      this.dialogVisible = true
      this.disabled_resource = true
      this.resource = { ...resource }
    },
    // 显示更新自然资源信息弹窗
    showUpdateResource(resource) {
      this.dialogVisible = true
      this.resource = { ...resource }
    },
    // 更新自然资源信息
    async updateResource() {
      let data = {
        resource_code: this.resource.resource_code,
        resource_name: this.resource.resource_name,
        resource_picture: this.resource.resource_picture,
        resource_kind: this.resource.resource_kind,
        resource_reserves: this.resource.resource_reserves,
        resource_location: this.resource.resource_location,
        resource_use: this.resource.resource_use,
        resource_reserves_unit: this.resource.resource_reserves_unit
      }

      if (typeof data.resource_kind === 'string') {
        this.dict_resource_kind.forEach(item => {
          if (item.resource_kind === data.resource_kind) {
            data.resource_kind = item.id
          }
        })
      }

      if (typeof data.resource_reserves_unit === 'string') {
        this.dict_resource_reserves_unit.forEach(item => {
          if (item.resource_reserves_unit === data.resource_reserves_unit) {
            data.resource_reserves_unit = item.id
          }
        })
      }

      const res = await this.$API.resource.updateResourceInfo(this.resource.id, data)
      console.log(res)
      if (res.code === 0) {
        this.$message({
          type: 'success',
          message: '更新成功'
        })
        this.resource = {
          resource_code: '',
          resource_name: '',
          resource_picture: '',
          resource_kind: '',
          resource_reserves: '',
          resource_location: '',
          resource_use: '',
          resource_reserves_unit: ''
        }
        this.getResourceData(this.page)
        this.dialogVisible = false
      }
    },
    // 弹窗关闭之前的处理函数
    handleClose(done) {
      this.$confirm('确认关闭？')
        .then(_ => {
          done()
          this.resource = {
            resource_code: '',
            resource_name: '',
            resource_picture: '',
            resource_kind: '',
            resource_reserves: '',
            resource_location: '',
            resource_use: '',
            resource_reserves_unit: ''
          }
          this.disabled_resource = false
          this.$refs['resourceForm'].clearValidate()
        })
        .catch(_ => {})
    },
    // 取消
    cancel() {
      this.resource = {
        resource_code: '',
        resource_name: '',
        resource_picture: '',
        resource_kind: '',
        resource_reserves: '',
        resource_location: '',
        resource_use: '',
        resource_reserves_unit: ''
      }
      this.dialogVisible = false
      this.disabled_resource = false
      this.$refs['resourceForm'].clearValidate()
    },
    // 删除自然资源信息
    removeResource(resource) {
      this.$confirm(`确定删除${resource.resource_code}的信息？`, '提示', {
        confirmButtonClass: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(async () => {
          const res = await this.$API.resource.removeResourceInfo(resource.id)
          if (res.code === 0) {
            this.$message({
              type: 'success',
              message: '删除成功'
            })
            this.getResourceData(this.pageList.length > 1 ? this.page : (this.page = this.page - 1))
          }
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
    },
    // 选中的数据
    handleSelectionChange(selection) {
      this.selectedIds = selection.map(item => item.id)
    },
    // 批量删除自然资源信息
    batchRemove() {
      this.$confirm('确定删除吗？')
        .then(async () => {
          const res = await this.$API.resource.batchRemoveResourceInfo(this.selectedIds)
          if (res.code === 0) {
            this.$message.success('删除成功')
            this.getResourceData(this.page)
          }
        })
        .catch(() => {
          this.$message.info('取消删除')
        })
    }
  }
}
</script>

<style scoped>
.container {
  padding: 0px 20px;
}

>>> .avatar-uploader .el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
.avatar-uploader .el-upload:hover {
  border-color: #409eff;
}
.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 178px;
  height: 178px;
  line-height: 178px;
  text-align: center;
}
.avatar {
  width: 178px;
  height: 178px;
  display: block;
}

.reserves {
  display: flex;
}

.uploadAndUse {
  display: flex;
  flex-direction: column;
}

.el-select {
  margin-left: 0;
}

.el-form-item.is-required {
  margin-right: 0px;
}

>>> .el-textarea.is-disabled .el-textarea__inner {
  background-color: #fff;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  color: #606266;
}

>>> .el-input.is-disabled .el-input__inner {
  background-color: #fff;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  color: #606266;
}
</style>
