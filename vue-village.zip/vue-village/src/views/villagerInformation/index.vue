<template>
  <div>村民信息模块</div>
</template>

<script>
export default {
  name: 'VillagerInformation'
}
</script>

<style scoped></style>
