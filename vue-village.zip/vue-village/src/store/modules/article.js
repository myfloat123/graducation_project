const state = {
  articleData1: ''
}

const mutations = {
  getArticleData1(state, str) {
    state.articleData1 = str
  }
}

const actions = {}

const getters = {}

export default {
  state,
  mutations,
  actions,
  getters
}
