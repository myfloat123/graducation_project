<template>
  <div class="container">
    <el-form inline style="margin-top: 20px">
      <!-- 表单元素 -->
      <el-form-item>
        <el-input v-model="tempSearchObj.recipient" placeholder="受助户主" />
      </el-form-item>
      <el-form-item>
        <el-select v-model="tempSearchObj.executive_condition" placeholder="执行情况">
          <el-option v-for="item in dict_executive_condition" id="option_executive_condition" :key="item.id" :label="item.executive_condition" :value="item.id" />
        </el-select>
      </el-form-item>
      <!-- 查询与清空按钮 -->
      <el-button type="primary" icon="el-icon-search" :disabled="tempSearchObj.recipient === '' && tempSearchObj.executive_condition === ''" @click="search">查询</el-button>
      <el-button type="default" @click="resetSearch">清空</el-button>
    </el-form>

    <!-- 添加与批量删除按钮 -->
    <div style="margin-bottom: 20px">
      <el-button type="primary" @click="showAddAssistinfo">添加</el-button>
      <el-button type="danger" :disabled="selectedIds.length === 0" @click="batchRemoveAssist">批量删除</el-button>
    </div>

    <!-- table表格：展示帮扶信息 -->
    <el-table v-loading="listLoading" :data="assistinfoData" border stripe style="width: 100%" @selection-change="handleSelectionChange">
      <el-table-column type="selection" align="center" />
      <el-table-column type="index" align="center" label="序号" />
      <el-table-column prop="recipient" label="受助户主" align="center" />
      <el-table-column prop="assist_content" label="帮扶内容" align="center" />
      <el-table-column prop="executive_condition" label="执行情况" align="center" />
      <el-table-column prop="createdAt" label="创建时间" align="center" />
      <el-table-column align="center" label="操作" fixed="right" width="500">
        <template slot-scope="{ row, $index }">
          <!-- v-show="is_not_fill_assistplan(row)" -->
          <div>
            <el-button :type="is_not_fill_assistplan(row) ? 'primary' : 'info'" :icon="is_not_fill_assistplan(row) ? 'el-icon-plus' : 'el-icon-info'" size="mini" @click="is_not_fill_assistplan(row) ? showAddAssistplan(row) : lookOneAssistplan(row)">{{
              is_not_fill_assistplan(row) ? '帮扶计划' : '查看计划'
            }}</el-button>
            <!-- <el-button v-show="is_look_assistplan(row)" type="info" icon="el-icon-info" size="mini" style="margin: 0px 5px 0px 5px" @click="lookOneAssistplan(row)">查看计划</el-button> -->
            <el-button type="warning" icon="el-icon-edit" size="mini" @click="showUpdateAssist($event, row, $index)">修改</el-button>
            <el-button type="danger" icon="el-icon-delete" size="mini" @click="showDeleteAssist($event, row, $index)">删除</el-button>
          </div>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页器 -->
    <!--  -->
    <el-pagination style="margin-top: 20px; text-align: center" :current-page="page" :page-sizes="[3, 5, 10]" :page-count="7" :page-size.sync="limit" layout="prev, pager, next, jumper, ->, sizes, total" :total="total" @current-change="handleCurrentChange" @size-change="handleSizeChange" />

    <!-- 新增帮扶信息对话框 -->
    <!-- :before-close="dialogBeforeClose" -->
    <el-dialog title="添加帮扶信息" :visible.sync="assistinfo_dialogVisible" width="width">
      <el-form ref="assistinfo_form" :model="assistinfo" inline label-width="80px" :rules="assistinfoRules">
        <el-form-item label="帮扶编号" prop="assist_code">
          <el-input v-model="assistinfo.assist_code" />
        </el-form-item>
        <el-form-item label="受助户主" prop="recipient">
          <el-input v-model="assistinfo.recipient" />
        </el-form-item>
        <el-form-item label="帮扶内容" prop="assist_content">
          <el-input v-model="assistinfo.assist_content" style="width: 180%" />
        </el-form-item>
      </el-form>
      <div slot="footer">
        <el-button @click="cancelAssistinfo">取 消</el-button>
        <el-button type="primary" @click="addAssistinfo">确 定</el-button>
      </div>
    </el-dialog>

    <!-- 新增帮扶计划对话框 -->
    <!-- :before-close="dialogBeforeClose" -->
    <el-dialog title="添加帮扶计划" :visible.sync="dialogVisible" width="width">
      <el-form ref="assistplanForm" :model="assistplan" label-width="80px" :rules="assistplanRules">
        <el-form-item label="帮扶需求" prop="assist_demand">
          <el-input v-model="assistplan.assist_demand" type="textarea" :rows="5" />
        </el-form-item>
        <el-form-item label="帮扶类型" prop="assist_type">
          <el-select v-model="assistplan.assist_type">
            <el-option v-for="item in dict_assist_type" :key="item.id" :value="item.id" :label="item.assist_type" />
          </el-select>
        </el-form-item>
        <el-form-item label="责任单位" prop="accountability_unit">
          <el-input v-model="assistplan.accountability_unit" style="width: 350px" />
        </el-form-item>
        <el-form-item label="责任人" prop="principal">
          <el-input v-model="assistplan.principal" style="width: 350px" />
        </el-form-item>
      </el-form>
      <div slot="footer">
        <el-button @click="cancel">取 消</el-button>
        <el-button type="primary" @click="addAssistplan">确 定</el-button>
      </div>
    </el-dialog>

    <!-- 查看与修改帮扶计划抽屉 -->
    <el-drawer v-if="assistplanInfo.assistinfo" ref="el_drawer_assist" :title="assistplanInfo.id ? '帮扶计划详情' : ''" :visible.sync="visible_assistplan" direction="rtl" size="50%" :before-close="handleClose">
      <el-form ref="assistplan_form" :model="assistplanInfo" label-width="80px" :rules="assistinfoAndAssistplanRules">
        <el-form-item v-show="assistplanInfo.assist_demand !== undefined" label="帮扶需求" prop="assist_demand">
          <el-input v-model="assistplanInfo.assist_demand" type="textarea" :rows="5" :disabled="disabled_assistplan" style="width: 70%" />
        </el-form-item>
        <el-form-item v-show="assistplanInfo.assist_type !== undefined || assistplanInfo.assist_type === 0" label="帮扶类型" prop="assist_type">
          <el-select v-model="assistplanInfo.assist_type" :disabled="disabled_assistplan" style="width: 30%">
            <el-option v-for="item in dict_assist_type" :key="item.id" :label="item.assist_type" :value="item.id" />
          </el-select>
          <!-- <el-input v-model="assistplanInfo.assist_type" :disabled="disabled_assistplan" style="width: 30%" /> -->
        </el-form-item>
        <el-form-item v-show="assistplanInfo.createdAt" label="帮扶时间">
          <el-input v-model="assistplanInfo.createdAt" :disabled="true" style="width: 30%" />
        </el-form-item>
        <el-form-item v-show="assistplanInfo.updatedAt && assistplanInfo.updatedAt !== assistplanInfo.createdAt" label="修改时间">
          <el-input v-model="assistplanInfo.updatedAt" :disabled="true" style="width: 30%" />
        </el-form-item>
        <el-form-item v-show="assistplanInfo.accountability_unit !== undefined" label="责任单位" prop="accountability_unit">
          <el-input v-model="assistplanInfo.accountability_unit" :disabled="disabled_assistplan" style="width: 30%" />
        </el-form-item>
        <el-form-item v-show="assistplanInfo.principal !== undefined" label="责任人" style="margin-bottom: 60px" prop="principal">
          <el-input v-model="assistplanInfo.principal" :disabled="disabled_assistplan" style="width: 30%" />
        </el-form-item>
        <el-divider content-position="left">帮扶信息详情</el-divider>
        <div class="recipient">
          <el-form-item label="受助户主" prop="recipient">
            <el-input v-model="assistplanInfo.assistinfo.recipient" :disabled="disabled_assistplan" style="width: 30%" />
          </el-form-item>
          <el-form-item label="帮扶内容" prop="assist_content">
            <el-input v-model="assistplanInfo.assistinfo.assist_content" style="width: 30%" :disabled="disabled_assistplan" />
          </el-form-item>
          <el-form-item label="执行情况">
            <el-input v-model="assistplanInfo.assistinfo.executive_condition" style="width: 30%" :disabled="true" />
          </el-form-item>
          <el-form-item label="创建时间">
            <el-input v-model="assistplanInfo.assistinfo.createdAt" :disabled="true" style="width: 30%" />
          </el-form-item>
          <el-form-item v-show="assistplanInfo.id" label="执行时间">
            <el-input v-model="assistplanInfo.createdAt" :disabled="true" style="width: 30%" />
          </el-form-item>
          <el-form-item v-if="assistplanInfo.assistinfo.updatedAt !== assistplanInfo.assistinfo.createdAt" label="修改时间">
            <el-input v-model="assistplanInfo.assistinfo.updatedAt" :disabled="true" style="width: 30%" />
          </el-form-item>
        </div>
      </el-form>
    </el-drawer>
  </div>
</template>

<script>
import dayjs from 'dayjs'
export default {
  name: 'HelpInformation',
  data() {
    return {
      // 当前页码
      page: 1,
      // 每页数量
      limit: 3,
      // 总数量
      total: 0,
      // 是否显示列表加载提示
      listLoading: false,
      // 执行情况字典
      dict_executive_condition: [
        { id: 0, executive_condition: '未执行' },
        { id: 1, executive_condition: '已执行' }
      ],
      // 包含请求搜索条件数据的对象
      searchObj: {
        recipient: '',
        executive_condition: ''
      },
      // 收集搜索条件输入的对象
      tempSearchObj: {
        recipient: '',
        executive_condition: ''
      },
      // 所有帮扶信息列表
      list: [],
      // 每页帮扶信息
      assistinfoData: [
        {
          recipient: '李三',
          assist_content: '家庭经济困难资助',
          executive_condition: 0,
          createdAt: '2023-04-03'
        }
      ],
      // 帮扶类型字典
      dict_assist_type: [
        { id: 0, assist_type: '经济扶贫' },
        { id: 1, assist_type: '教育扶贫' },
        { id: 2, assist_type: '医疗扶贫' },
        { id: 3, assist_type: '住房扶贫' },
        { id: 4, assist_type: '精准扶贫' },
        { id: 5, assist_type: '社会扶贫' },
        { id: 6, assist_type: '就业扶贫' },
        { id: 7, assist_type: '产业扶贫' },
        { id: 8, assist_type: '其他' }
      ],
      // 是否显示新增帮扶信息的dialog
      assistinfo_dialogVisible: false,
      // 是否显示新增/修改帮扶计划的dialog
      dialogVisible: false,
      // 是否显示帮扶计划详情
      visible_assistplan: false,
      // 是否查看帮扶计划
      disabled_assistplan: true,
      // 帮扶计划详情
      assistplan_detail: {},
      // 当前操作的帮扶计划
      assistplan: {
        assist_code: '',
        assist_demand: '',
        assist_type: '',
        accountability_unit: '',
        principal: ''
      },
      // 当前操作的帮扶信息
      assistinfo: {
        assist_code: '',
        recipient: '',
        assist_content: ''
      },
      // 当前操作的帮扶信息的原始数据
      original_assistinfo: {
        assist_code: '',
        recipient: '',
        assist_content: '',
        executive_condition: ''
      },
      // 当前操作的帮扶计划的原始数据
      original_assistplan: {
        assist_demand: '',
        assist_type: '',
        accountability_unit: '',
        principal: ''
      },
      // 查询到的某个帮扶计划信息
      assistplanInfo: {},
      // 帮扶信息验证规则
      assistinfoRules: {
        assist_code: [{ required: true, message: '请输入帮扶编号', trigger: 'blur' }],
        recipient: [{ required: true, message: '请输入受助户主', trigger: 'blur' }],
        assist_content: [{ required: true, message: '请输入帮扶内容', trigger: 'blur' }]
      },
      // 帮扶计划验证规则
      assistplanRules: {
        assist_demand: [{ required: true, message: '请输入帮扶需求', trigger: 'blur' }],
        assist_type: [{ required: true, message: '请选择帮扶类型', trigger: 'blur' }],
        accountability_unit: [{ required: true, message: '请输入责任单位', trigger: 'blur' }],
        principal: [{ required: true, message: '请输入责任人', trigger: 'blur' }]
      },
      // 帮扶信息和帮扶计划验证规则
      assistinfoAndAssistplanRules: {
        assist_code: [{ required: true, message: '请输入帮扶编号', trigger: 'blur' }],
        recipient: [
          // { required: true, message: '请输入受助户主', trigger: 'blur' },
          { required: true, validator: this.validator_recipient, trigger: 'blur' }
        ],
        assist_content: [
          // { required: true, message: '请输入帮扶内容', trigger: 'blur' },
          { required: true, validator: this.validator_assist_content, trigger: 'blur' }
        ],
        assist_demand: [{ required: true, message: '请输入帮扶需求', trigger: 'blur' }],
        assist_type: [{ required: true, message: '请选择帮扶类型', trigger: 'blur' }],
        accountability_unit: [{ required: true, message: '请输入责任单位', trigger: 'blur' }],
        principal: [{ required: true, message: '请输入责任人', trigger: 'blur' }]
      },
      // 是否填写帮扶计划
      isFillAssistplan: false,
      // 所有选择的帮扶信息id数组
      selectedIds: [],
      // 所有选择的帮扶计划assist_code数组
      selectedAssistCodes: []
    }
  },
  created() {},
  mounted() {
    this.getAssistinfoData()
    this.examineAssistplan()
  },
  methods: {
    // 获取所有帮扶信息
    async getAssistinfoData(pager = 1, limitr = 3) {
      this.listLoading = true
      let res
      if (this.tempSearchObj.recipient !== '' || this.tempSearchObj.executive_condition !== '') {
        this.search()
        this.listLoading = false
      } else {
        this.page = pager
        this.limit = limitr
        const { page, limit } = this
        res = await this.$API.assistinfo.getAssistinfo(page, limit)
      }

      console.log(res)
      this.listLoading = false
      if (res.code === 0) {
        res.result.list.forEach(assistinfo => {
          assistinfo.executive_condition = assistinfo.executive_condition ? '已执行' : '未执行'
          assistinfo.createdAt = dayjs(assistinfo.createdAt).format('YYYY-MM-DD HH:mm:ss')
          assistinfo.updatedAt = dayjs(assistinfo.updatedAt).format('YYYY-MM-DD HH:mm:ss')
        })
        res.result.pageList.forEach(assistinfo => {
          assistinfo.executive_condition = assistinfo.executive_condition ? '已执行' : '未执行'
          assistinfo.createdAt = dayjs(assistinfo.createdAt).format('YYYY-MM-DD HH:mm:ss')
          assistinfo.updatedAt = dayjs(assistinfo.updatedAt).format('YYYY-MM-DD HH:mm:ss')
        })
        this.list = res.result.list
        this.total = res.result.total
        this.assistinfoData = res.result.pageList
      } else {
        return Promise.reject(new Error('faile'))
      }
    },
    // 获取某个帮扶信息
    async lookOneAssistinfo(assistinfo) {
      console.log(assistinfo)
    },
    // 显示新增帮扶信息弹窗
    showAddAssistinfo() {
      this.assistinfo_dialogVisible = true
      this.assistinfo = {
        assist_code: 'BF' + `${+new Date()}`.slice(-4) || '',
        recipient: '',
        assist_content: ''
      }
    },
    // 新增帮扶信息
    addAssistinfo() {
      this.$refs['assistinfo_form'].validate(async valid => {
        if (valid) {
          const res = await this.$API.assistinfo.addAssistinfoData(this.assistinfo)
          console.log(res)
          this.assistinfo = {
            assist_code: '',
            recipient: '',
            assist_content: ''
          }
          this.assistinfo_dialogVisible = false
          this.getAssistinfoData(this.page, this.limit)
        }
      })
    },
    // 取消新增帮扶信息
    cancelAssistinfo() {
      this.assistinfo = {
        assist_code: '',
        recipient: '',
        assist_content: ''
      }
      this.assistinfo_dialogVisible = false
    },
    // 修改帮扶信息
    async updateAssistinfoData() {
      if (this.assistplan_detail !== {}) {
        let data = {
          assist_code: this.assistplan_detail.pageList[0].assistinfo.asssist_code,
          recipient: this.assistplan_detail.pageList[0].assistinfo.recipient,
          assist_content: this.assistplan_detail.pageList[0].assistinfo.assist_content,
          executive_condition: true
        }
        const res = await this.$API.assistinfo.updateAssistinfo(this.assistplan_detail.pageList[0].assistinfo.id, data)
        console.log(res)
      }
    },
    // 判断帮扶计划是否已填写
    is_not_fill_assistplan(assistinfo) {
      // console.log('判断帮扶计划是否已填写')
      // console.log(assistinfo)
      // console.log('assistinfo.id', assistinfo.assist_code)
      let assistinfo_assist_codes = []
      this.assistplan_detail.list &&
        this.assistplan_detail.list.forEach(item => {
          assistinfo_assist_codes.push(item.assist_code)
        })
      // console.log(assistinfo_assist_codes)
      if (assistinfo_assist_codes.includes(assistinfo.assist_code)) {
        return false
      } else {
        return true
      }
      // this.assistinfoData.forEach(assistinfo => {
      //   this.assistplan_detail.list.forEach(assistplan => {
      //     if (assistinfo.assist_code === assistplan.assist_code) {
      //       return true
      //     } else {
      //       return false
      //     }
      //   })
      // })
    },
    // 判断是否可查看帮扶计划
    is_look_assistplan(assistinfo) {
      console.log('判断是否可查看帮扶计划')
      console.log('assistinfo.id', assistinfo.assist_code)
      let assistinfo_assist_codes = []
      this.assistplan_detail.list.forEach(item => {
        assistinfo_assist_codes.push(item.assist_code)
      })
      console.log(assistinfo_assist_codes)
      if (assistinfo_assist_codes.includes(assistinfo.assist_code)) {
        return true
      } else {
        return false
      }
      // this.assistinfoData.forEach(assistinfo => {
      //   this.assistplan_detail.list.forEach(assistplan => {
      //     if (assistinfo.assist_code === assistplan.assist_code) {
      //       return true
      //     } else {
      //       return false
      //     }
      //   })
      // })
    },
    // 显示新增帮扶计划界面
    showAddAssistplan(assistinfo) {
      this.dialogVisible = true
      this.assistinfo = assistinfo
      this.assistplan = {
        assist_code: assistinfo.assist_code,
        assist_demand: '',
        assist_type: '',
        accountability_unit: '',
        principal: ''
      }
    },
    // 新增帮扶计划
    addAssistplan() {
      this.$refs['assistplanForm'].validate(async valid => {
        console.log('valid', valid)
        if (valid) {
          const res1 = await this.$API.assistplan.addAssistplanInfo(this.assistplan)
          console.log('新增帮扶计划', res1)
          let assistinfoData = {
            assist_code: this.assistinfo.assist_code,
            recipient: this.assistinfo.recipient,
            assist_content: this.assistinfo.assist_content,
            executive_condition: true
          }
          const res2 = await this.$API.assistinfo.updateAssistinfo(this.assistinfo.id, assistinfoData)
          console.log('修改帮扶信息执行情况', res2)
          // if (res2.result.recipient === this.assistinfo.recipient || res2.result.assist_content === this.assistinfo.assist_content) {
          //   this.assistinfo.updatedAt = this.assistinfo.createdAt
          // }
          this.examineAssistplan()
          this.is_not_fill_assistplan(this.assistinfo.assist_code)
          this.getAssistinfoData(this.assistinfo.id ? this.page : 1, this.limit)
          console.log('新增帮扶计划', this.assistinfo.assist_code)
        }
      })
      this.dialogVisible = false
    },
    // 取消
    cancel() {
      this.dialogVisible = false
      this.assistplan = {
        assist_code: '',
        assist_demand: '',
        assist_type: '',
        accountability_unit: '',
        principal: ''
      }
    },
    // 获取帮扶计划
    async examineAssistplan() {
      const res = await this.$API.assistplan.examineAssistplanInfo()
      console.log('获取帮扶计划', res)
      if (res.code === 0) {
        // res.result.pageList.forEach(assistplan => {
        //   assistplan.createdAt = dayjs(assistplan.createdAt).format('YYYY-MM-DD HH:mm:ss')
        //   assistplan.assistinfo.createdAt = dayjs(assistplan.assistinfo.createdAt).format('YYYY-MM-DD HH:mm:ss')
        //   assistplan.updatedAt = dayjs(assistplan.updatedAt).format('YYYY-MM-DD HH:mm:ss')
        //   assistplan.assistinfo.executive_condition = assistplan.assistinfo.executive_condition ? '已执行' : '未执行'
        //   this.dict_assist_type.forEach(item => {
        //     if (assistplan.assist_type === item.id) {
        //       assistplan.assist_type = item.assist_type
        //     }
        //   })
        // })
        // res.result.list.forEach(assistplan => {
        //   assistplan.createdAt = dayjs(assistplan.createdAt).format('YYYY-MM-DD HH:mm:ss')
        //   assistplan.updatedAt = dayjs(assistplan.updatedAt).format('YYYY-MM-DD HH:mm:ss')
        //   this.dict_assist_type.forEach(item => {
        //     if (assistplan.assist_type === item.id) {
        //       assistplan.assist_type = item.assist_type
        //     }
        //   })
        // })
        this.assistplan_detail = res.result
      } else {
        return Promise.reject(new Error('faile'))
      }
    },
    // 获取某个帮扶计划
    async lookOneAssistplan(assistinfo) {
      this.original_assistinfo = assistinfo
      console.log('获取某个帮扶计划', assistinfo)
      this.visible_assistplan = true
      let id = null
      this.assistplan_detail.list.forEach(item => {
        if (item.assist_code === assistinfo.assist_code) {
          id = item.id
        }
      })
      console.log('获取某个帮扶计划', id)
      console.log(assistinfo)
      if (id !== null) {
        const res = await this.$API.assistplan.getOneAssistplanInfo(id)
        console.log('res1', res)
        if (res.code === 0) {
          this.dict_assist_type.forEach(item => {
            if (item.id === res.result.assist_type) {
              res.result.assist_type = item.assist_type
            }
          })
          if (res.result.assistinfo === null) {
            const res2 = await this.$API.assistinfo.getOneAssistinfo(assistinfo.id)
            if (res2.code === 0) {
              /* eslint-disable */
              res.result.assistinfo = res2.result
            }
          }
          res.result.assistinfo.executive_condition = res.result.assistinfo.executive_condition ? '已执行' : '未执行'
          res.result.createdAt = dayjs(res.result.createdAt).format('YYYY-MM-DD HH:mm:ss')
          res.result.updatedAt = dayjs(res.result.updatedAt).format('YYYY-MM-DD HH:mm:ss')
          res.result.assistinfo.createdAt = dayjs(res.result.assistinfo.createdAt).format('YYYY-MM-DD HH:mm:ss')
          res.result.assistinfo.updatedAt = dayjs(res.result.assistinfo.updatedAt).format('YYYY-MM-DD HH:mm:ss')
          this.original_assistplan = {
            assist_demand: res.result.assist_demand,
            assist_type: res.result.assist_type,
            accountability_unit: res.result.accountability_unit,
            principal: res.result.principal
          }
          console.log('this.assistplanInfo = res.result', res.result)
          return (this.assistplanInfo = res.result)
        } else {
          return Promise.reject(new Error('faile'))
          // const res = await this.$API.assistinfo.getOneAssistinfo(assistinfo.id)
          // console.log('res2', res)
        }
      } else {
        const res = await this.$API.assistinfo.getOneAssistinfo(assistinfo.id)
        console.log('查看帮扶信息', res)
        if (res.code === 0) {
          res.result.createdAt = dayjs(res.result.createdAt).format('YYYY-MM-DD HH:mm:ss')
          res.result.updatedAt = dayjs(res.result.updatedAt).format('YYYY-MM-DD HH:mm:ss')
          res.result.executive_condition = res.result.executive_condition ? '已执行' : '未执行'
          return (this.assistplanInfo = {
            accountability_unit: undefined,
            assist_code: undefined,
            assist_demand: undefined,
            assist_type: undefined,
            assistinfo: res.result,
            principal: undefined
            // assistplan_status: '',
            // createdAt: '',
            // id: '',
            // updatedAt: ''
          })
        } else {
          return Promise.reject(new Error('faile'))
        }
      }
    },
    // 当前页变化
    handleCurrentChange(page) {
      console.log(page)
      this.page = page

      this.getAssistinfoData(this.page, this.limit)
    },
    // 每页条数变化
    handleSizeChange(limit) {
      this.limit = limit
      this.getAssistinfoData(this.page, this.limit)
    },
    // 查询
    async search() {
      this.listLoading = true
      this.searchObj = { ...this.tempSearchObj }

      const res = await this.$API.assistinfo.getEveryAssistinfoData(this.searchObj, this.page, this.limit)
      this.listLoading = false
      console.log(res)
      if (res.code === 0) {
        res.result.list.forEach(item => {
          item.executive_condition = item.executive_condition ? '已执行' : '未执行'
          item.createdAt = dayjs(item.createdAt).format('YYYY-MM-DD HH:mm:ss')
          item.updatedAt = dayjs(item.updatedAt).format('YYYY-MM-DD HH:mm:ss')
        })
        res.result.pageList.forEach(item => {
          item.executive_condition = item.executive_condition ? '已执行' : '未执行'
          item.createdAt = dayjs(item.createdAt).format('YYYY-MM-DD HH:mm:ss')
          item.updatedAt = dayjs(item.updatedAt).format('YYYY-MM-DD HH:mm:ss')
        })
        this.assistinfoData = res.result.pageList
        this.total = res.result.total
        this.limit = res.result.limit
      }
    },
    // 清空
    resetSearch() {
      this.searchObj = {
        recipient: '',
        executive_condition: ''
      }
      this.tempSearchObj = {
        recipient: '',
        executive_condition: ''
      }
      this.getAssistinfoData(this.page, this.limit)
    },
    // 显示修改帮扶信息与计划窗口
    async showUpdateAssist(e, assist, index) {
      this.disabled_assistplan = false

      const res = await this.lookOneAssistplan(assist)
      console.log('显示修改帮扶信息与计划窗口', res)
      console.log('assist', assist)
      this.original_assistinfo = assist
      if (res) {
        const { assist_demand, assist_type, accountability_unit, principal } = res

        let assistplanData = [assist_demand, assist_type, accountability_unit, principal]
        // this.dict_assist_type.forEach(item => {
        //   if (item.assist_type === assist_type) {
        //     assistplanData[1] = item.id
        //   }
        // })
        console.log('assistplanData', assistplanData)
        let i = 0
        for (let key in this.original_assistplan) {
          this.original_assistplan[key] = assistplanData[i]
          i = i + 1
        }
      }
    },
    // 关闭抽屉前的处理函数
    handleClose(done) {
      this.$confirm('确认关闭？')
        .then(async _ => {
          let res1 = {}
          let res2 = {}
          if (this.assistplanInfo.assistinfo.recipient !== this.original_assistinfo.recipient || this.assistplanInfo.assistinfo.assist_content !== this.original_assistinfo.assist_content) {
            res1 = await this.updateAssist()
            console.log('updateAssist', res1)
          }

          if (
            (this.original_assistplan.assist_demand !== this.assistplanInfo.assist_demand ||
              this.original_assistplan.assist_type !== this.assistplanInfo.assist_type ||
              this.original_assistplan.accountability_unit !== this.assistplanInfo.accountability_unit ||
              this.original_assistplan.principal !== this.assistplanInfo.principal) &&
            this.assistplanInfo.id
          ) {
            res2 = await this.updateAssistplan()
            console.log('updateAssistplan', res2)
          }
          console.log('res2,res1', res2, res1)

          if (res2.code === 0 || res1.code === 0) {
            done()

            this.assistplanInfo = {
              accountability_unit: undefined,
              assist_code: undefined,
              assist_demand: undefined,
              assist_type: undefined,
              assistinfo: {},
              principal: undefined
            }
            this.$message({
              type: 'success',
              message: '修改信息成功'
            })
            this.getAssistinfoData(this.page, this.limit)
            console.log('帮扶信息和帮扶计划验证规则对象success', this.$refs['assistplan_form'])
            this.visible_assistplan = false
          }

          console.log('关闭抽屉', _)
          done()

          this.assistplanInfo = {
            accountability_unit: undefined,
            assist_code: undefined,
            assist_demand: undefined,
            assist_type: undefined,
            assistinfo: {},
            principal: undefined
          }

          this.visible_assistplan = false
        })
        .catch(_ => {
          console.log('取消关闭抽屉', _)
        })
    },

    // 修改帮扶信息
    async updateAssist() {
      let data = {
        assist_code: this.assistplanInfo.assistinfo.assist_code || '',
        recipient: this.assistplanInfo.assistinfo.recipient || '',
        assist_content: this.assistplanInfo.assistinfo.assist_content || '',
        executive_condition: this.assistplanInfo.assistinfo.executive_condition === '未执行' ? false : true || ''
      }
      const res = await this.$API.assistinfo.updateAssistinfo(this.assistplanInfo.assistinfo.id, data)
      console.log('修改信息成功', res)

      if (res.code === 0) {
        this.original_assistinfo = {
          assist_code: '',
          recipient: '',
          assist_content: '',
          executive_condition: ''
        }
        this.assistplanInfo.assistinfo = res.result
        // this.assistplanInfo = {
        //   accountability_unit: '',
        //   assist_code: '',
        //   assist_demand: '',
        //   assist_type: '',
        //   assistinfo: res.result,
        //   principal: ''
        //   // assistplan_status: '',
        //   // createdAt: '',
        //   // id: '',
        //   // updatedAt: ''
        // }

        return res

        // this.getAssistinfoData(this.page)
      } else {
        return Promise.reject(new Error('faile'))
      }
    },
    // 修改帮扶计划
    async updateAssistplan() {
      this.dict_assist_type.forEach(item => {
        if (item.assist_type === this.assistplanInfo.assist_type) {
          this.assistplanInfo.assist_type = item.id
        }
      })
      let data = {
        assist_demand: this.assistplanInfo.assist_demand,
        assist_type: this.assistplanInfo.assist_type,
        accountability_unit: this.assistplanInfo.accountability_unit,
        principal: this.assistplanInfo.principal
      }
      console.log('修改帮扶计划', data)

      const res = await this.$API.assistplan.updateAssistplanInfo(this.assistplanInfo.id, data)
      if (res.code === 0) {
        this.original_assistplan = {
          assist_demand: '',
          assist_type: '',
          accountability_unit: '',
          principal: ''
        }
        return res
      } else {
        return Promise.reject(new Error('faile'))
      }
    },
    // 验证受助户主
    validator_recipient(rule, value = this.assistplanInfo.assistinfo.recipient, callback) {
      console.log('受助户主', value)
      console.log(rule)
      // const recipient = value.replace(/\s/g, '') // 去除空格
      if (!value) {
        callback('请输入受助户主')
      } else {
        callback()
      }
    },
    // 验证帮扶内容
    validator_assist_content(rule, value = this.assistplanInfo.assistinfo.assist_content, callback) {
      // const assist_content = value.replace(/\s/g, '') // 去除空格
      if (!value) {
        callback('请输入帮扶内容')
      } else {
        callback()
      }
    },
    // 删除帮扶
    showDeleteAssist(e, assist, index) {
      console.log('删除帮扶', e, assist, index)
      this.$confirm('确定删除？', '提示', {
        confirmButtonClass: '确定',
        cancelButtonClass: '取消',
        type: 'warning'
      })
        .then(async () => {
          const res1 = await this.$API.assistinfo.deleteAssistinfo(assist.id)
          let res2
          if (this.assistinfoData[index].executive_condition !== '未执行') {
            res2 = await this.$API.assistplan.deleteAssistplanByAssistCode(assist.assist_code)
          }

          if (res1.code === 0 && res2.code === 0) {
            this.$message({
              type: 'success',
              message: '删除成功'
            })

            this.getAssistinfoData(this.page, this.limit)
          } else {
            return Promise.reject(new Error('faile'))
          }
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
    },
    // 批量删除选中的帮扶信息
    handleSelectionChange(selection) {
      console.log('selection', selection)
      this.selectedIds = selection.map(item => item.id)
      this.selectedAssistCodes = selection.map(item => item.assist_code)
      console.log('this.selectedIds', this.selectedIds)
      console.log('this.selectedAssistCodes', this.selectedAssistCodes)
    },
    // 批量删除帮扶信息与计划
    batchRemoveAssist() {
      this.$confirm('确定删除吗？')
        .then(async () => {
          const res1 = await this.$API.assistinfo.batchRemoveAssistinfo(this.selectedIds)
          const res2 = await this.$API.assistplan.removeAssistplanByAssistCode(this.selectedAssistCodes)

          if (res1.code === 0 && res2.code === 0) {
            this.$message.success('删除成功')
            this.getAssistinfoData(this.page)
          }
        })
        .catch(() => {
          this.$message.info('取消删除')
        })
    }
  }
}
</script>

<style scoped>
.container {
  padding: 20px 20px;
}
>>> .el-textarea.is-disabled .el-textarea__inner {
  background-color: #fff;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  color: #606266;
}

>>> .el-input.is-disabled .el-input__inner {
  background-color: #fff;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  color: #606266;
}

>>> .el-drawer__header {
  font-weight: 700;
  font-size: 20px;
  color: #303133;
}

.el-divider__text,
.el-link {
  font-weight: 700;
  font-size: 20px;
}

.recipient {
  margin-top: 50px;
}

/* >>> .el-table_1_column_1 .is-center .el-table-column--selection {
  width: 48px;
}

>>> .el-table_1_column_2 .is-center {
  width: 55px;
}

>>> .el-table_1_column_3 .is-center {
  width: 400px;
}

>>> .el-table_1_column_4 .is-center {
  width: 500px;
}

>>> .el-table_1_column_5 .is-center {
  width: 200px;
}

>>> .el-table_1_column_6 .is-center {
  width: 300px;
}

>>> .el-table_1_column_7 .is-center {
  width: 600px;
} */
</style>
