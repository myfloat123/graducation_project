<template>
  <div class="container">
    <el-form inline style="margin-top: 20px">
      <!-- 表单元素 -->
      <el-form-item>
        <el-input v-model.trim="tempSearchObj.infra_code" placeholder="基础设施编号" />
      </el-form-item>
      <el-form-item>
        <el-input v-model.trim="tempSearchObj.infra_name" placeholder="基础设施名称" />
      </el-form-item>
      <el-form-item>
        <el-input v-model.trim="tempSearchObj.construction_unit" placeholder="建设单位" />
      </el-form-item>
      <!-- 查询与清空按钮 -->
      <el-button type="primary" icon="el-icon-search" @click="search">查询</el-button>
      <el-button type="default" @click="resetSearch">清空</el-button>
    </el-form>

    <div style="margin-bottom: 20px">
      <!-- 添加与批量删除按钮 -->
      <el-button type="primary" @click="showAddInfra">添加</el-button>
      <el-button type="danger" :disabled="selectedIds.length === 0" @click="batchRemove">批量删除</el-button>
    </div>

    <!-- table表格：展示基础设施信息 -->
    <el-table v-loading="listLoading" :data="pageList" border stripe style="width: 100%" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" />
      <el-table-column type="index" align="center" width="55" label="序号" />
      <el-table-column prop="infra_code" label="基础设施编号" align="center" width="200" />
      <el-table-column prop="infra_name" label="基础设施名称" align="center" width="200" />
      <el-table-column prop="infra_type" label="基础设施类型" align="center" width="300" />
      <el-table-column prop="location" label="位置" align="center" width="150" />
      <el-table-column prop="construction_date" label="建设日期" align="center" width="300" />
      <el-table-column prop="construction_unit" label="建设单位" align="center" width="300" />
      <el-table-column prop="construction_capital" label="建设资金" align="center" width="100" />
      <el-table-column prop="tag" label="使用情况" align="center" width="150">
        <template slot-scope="{ row }">
          <el-tag :type="use_condition_tag(row)" disable-transitions>{{ row.use_condition }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="tag" label="运行状况" align="center" width="150">
        <template slot-scope="{ row }">
          <el-tag :type="operation_condition_tag(row)" disable-transitions>{{ row.operation_condition }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="tag" label="维修情况" align="center" width="150">
        <template slot-scope="{ row }">
          <el-tag :type="maintain_condition_tag(row)" disable-transitions>{{ row.maintain_condition }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="exist_issue" label="存在问题" align="center" width="300" />
      <el-table-column prop="improvement_measure" label="改进措施" align="center" width="300" />
      <el-table-column label="操作" width="300" align="center" fixed="right">
        <template slot-scope="{ row }">
          <el-button type="warning" icon="el-icon-edit" size="mini" @click="showUpdateInfra(row)">修改</el-button>
          <el-button type="danger" icon="el-icon-delete" size="mini" @click="removeInfra(row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页器 -->
    <!--  -->
    <el-pagination style="margin-top: 20px; text-align: center" :current-page="page" :page-sizes="[3, 5, 10]" :page-count="7" :page-size.sync="limit" layout="prev, pager, next, jumper, ->, sizes, total" :total="total" @current-change="handleCurrentChange" @size-change="handleSizeChange" />

    <!-- :before-close="dialogBeforeClose" -->
    <!-- 添加/修改基础设施弹窗 -->
    <el-dialog :title="infra.id ? '修改基础设施' : '添加基础设施'" :visible.sync="dialogVisible" :before-close="handleClose">
      <el-form ref="infraForm" :model="infra" inline label-width="120px" :rules="infraRules">
        <el-form-item label="基础设施编号" prop="infra_code">
          <el-input v-model="infra.infra_code" />
        </el-form-item>
        <el-form-item label="基础设施名称" prop="infra_name">
          <el-input v-model="infra.infra_name" />
        </el-form-item>
        <el-form-item label="基础设施类型" prop="infra_type">
          <el-select v-model="infra.infra_type">
            <el-option v-for="item in dict_infra_type" :key="item.id" :label="item.infra_type" :value="item.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="位置" prop="location">
          <el-input v-model="infra.location" />
        </el-form-item>
        <el-form-item label="建设日期" prop="construction_date">
          <el-date-picker v-model="infra.construction_date" type="date" placeholder="选择日期" style="width: 100%" :picker-options="expireTimeOption" />
        </el-form-item>
        <el-form-item label="建设单位" prop="construction_unit">
          <el-input v-model="infra.construction_unit" />
        </el-form-item>
        <el-form-item label="建设资金" prop="construction_capital">
          <el-input v-model="infra.construction_capital" />
        </el-form-item>
        <el-form-item label="使用情况" prop="use_condition">
          <el-select v-model="infra.use_condition">
            <el-option v-for="item in dict_use_condition" :key="item.id" :label="item.use_condition" :value="item.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="运行状况" prop="operation_condition">
          <el-select v-model="infra.operation_condition">
            <el-option v-for="item in dict_operation_condition" :key="item.id" :label="item.operation_condition" :value="item.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="维修情况" prop="maintain_condition">
          <el-select v-model="infra.maintain_condition">
            <el-option v-for="item in dict_maintain_condition" :key="item.id" :label="item.maintain_condition" :value="item.id" />
          </el-select>
        </el-form-item>
        <el-form-item v-if="!((infra.use_condition === 1 || infra.use_condition === '正常') && (infra.operation_condition === 1 || infra.operation_condition === '良好') && (infra.maintain_condition === 1 || infra.maintain_condition === '无需维修'))" label="存在问题">
          <el-input v-model="infra.exist_issue" type="textarea" :rows="5" />
        </el-form-item>
        <el-form-item v-if="!((infra.use_condition === 1 || infra.use_condition === '正常') && (infra.operation_condition === 1 || infra.operation_condition === '良好') && (infra.maintain_condition === 1 || infra.maintain_condition === '无需维修'))" label="改进措施">
          <el-input v-model="infra.improvement_measure" type="textarea" :rows="5" />
        </el-form-item>
      </el-form>
      <div slot="footer">
        <el-button @click="cancel">取 消</el-button>
        <el-button type="primary" @click="infra.id ? updateInfra() : addInfra()">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import dayjs from 'dayjs'
export default {
  name: 'Infrastructure',
  data() {
    return {
      // 当前页码
      page: 1,
      // 每页数量
      limit: 3,
      // 总数量
      total: 0,
      // 是否显示列表加载提示
      listLoading: false,
      // 每页基础设施列表
      pageList: [],
      // 所有基础设施列表
      list: [],
      // 基础设施类型
      dict_infra_type: [
        { id: 1, infra_type: '生产性基础设施' },
        { id: 2, infra_type: '生活性基础设施' },
        { id: 3, infra_type: '人文基础设施' },
        { id: 4, infra_type: '流通性基础设施' }
      ],
      // 使用情况
      dict_use_condition: [
        { id: 1, use_condition: '正常' },
        { id: 2, use_condition: '闲置' },
        { id: 3, use_condition: '废弃' }
      ],
      // 运行状况
      dict_operation_condition: [
        { id: 1, operation_condition: '良好' },
        { id: 2, operation_condition: '一般' },
        { id: 3, operation_condition: '较差' }
      ],
      // 维修情况
      dict_maintain_condition: [
        { id: 1, maintain_condition: '无需维修' },
        { id: 2, maintain_condition: '已维修' },
        { id: 3, maintain_condition: '待维修' }
      ],
      // 当前操作的基础设施
      infra: {
        infra_code: '',
        infra_name: '',
        infra_type: '',
        location: '',
        construction_date: '',
        construction_unit: '',
        construction_capital: '',
        use_condition: '',
        operation_condition: '',
        maintain_condition: '',
        // infra_status: '',
        exist_issue: '',
        improvement_measure: ''
      },
      // 是否显示添加/修改基础设施的dialog
      dialogVisible: false,
      // 基础设施信息验证规则
      infraRules: {
        infra_code: [{ required: true, message: '请输入基础设施编号', trigger: 'blur' }],
        infra_name: [{ required: true, message: '请输入基础设施名称', trigger: 'blur' }],
        infra_type: [{ required: true, message: '请选择基础设施类型', trigger: 'blur' }],
        location: [{ required: true, message: '请输入位置', trigger: 'blur' }],
        construction_date: [
          { required: true, message: '请选择建设日期', trigger: 'blur' }
          // { validator: this.validator_construction_date, trigger: 'blur' }
        ],
        construction_unit: [{ required: true, message: '请输入建设单位', trigger: 'blur' }],
        construction_capital: [{ required: true, message: '请输入建设单位', trigger: 'blur' }],
        use_condition: [{ required: true, message: '请选择使用情况', trigger: 'blur' }],
        operation_condition: [{ required: true, message: '请选择运行状况', trigger: 'blur' }],
        maintain_condition: [{ required: true, message: '请选择维修情况', trigger: 'blur' }],
        exist_issue: [{ required: true, message: '请输入存在问题', trigger: 'blur' }],
        improvement_measure: [{ required: true, message: '请输入改进措施', trigger: 'blur' }]
      },
      // 包含请求搜索条件数据的对象
      searchObj: {
        infra_code: '',
        infra_name: '',
        construction_unit: ''
      },
      // 收集搜索条件输入的对象
      tempSearchObj: {
        infra_code: '',
        infra_name: '',
        construction_unit: ''
      },
      // 选中数据id数组
      selectedIds: [],
      // 到期日期
      expireTimeOption: {
        // 选择今天以及今天以前的日期
        disabledDate(time) {
          return time.getTime() > Date.now() - 8.64e6
        }
      }
    }
  },
  watch: {
    infra: {
      deep: true,
      handler(newVal) {
        console.log('newVal', newVal)
      }
    }
  },
  mounted() {
    this.getInfraData()
  },
  methods: {
    // 获取基础设施信息
    async getInfraData(page = 1, limit = 3) {
      this.listLoading = true
      const res = await this.$API.infrastructure.getInfrastructureInfo(page, limit)
      this.listLoading = false
      console.log(res)
      if (res.code === 0) {
        res.result.pageList.forEach(infra => {
          this.dict_infra_type.forEach(item => {
            if (item.id === infra.infra_type) {
              infra.infra_type = item.infra_type
            }
          })
          this.dict_maintain_condition.forEach(item => {
            if (item.id === infra.maintain_condition) {
              infra.maintain_condition = item.maintain_condition
            }
          })
          this.dict_use_condition.forEach(item => {
            if (item.id === infra.use_condition) {
              infra.use_condition = item.use_condition
            }
          })
          this.dict_operation_condition.forEach(item => {
            if (item.id === infra.operation_condition) {
              infra.operation_condition = item.operation_condition
            }
          })
          infra.construction_date = dayjs(infra.construction_date).format('YYYY-MM-DD')
        })

        res.result.list.forEach(infra => {
          this.dict_infra_type.forEach(item => {
            if (item.id === infra.infra_type) {
              infra.infra_type = item.infra_type
            }
          })
          this.dict_maintain_condition.forEach(item => {
            if (item.id === infra.maintain_condition) {
              infra.maintain_condition = item.maintain_condition
            }
          })
          this.dict_use_condition.forEach(item => {
            if (item.id === infra.use_condition) {
              infra.use_condition = item.use_condition
            }
          })
          this.dict_operation_condition.forEach(item => {
            if (item.id === infra.operation_condition) {
              infra.operation_condition = item.operation_condition
            }
          })
          infra.construction_date = dayjs(infra.construction_date).format('YYYY-MM-DD HH:mm:ss')
        })

        this.pageList = res.result.pageList
        this.list = res.result.list
        this.total = res.result.total
      }
    },
    // 使用情况
    use_condition_tag(infra) {
      if (infra.use_condition === '正常') {
        return 'success'
      } else if (infra.use_condition === '闲置') {
        return 'warning'
      } else {
        return 'danger'
      }
    },
    // 运行状况
    operation_condition_tag(infra) {
      if (infra.operation_condition === '良好') {
        return 'success'
      } else if (infra.operation_condition === '一般') {
        return 'warning'
      } else {
        return 'danger'
      }
    },
    // 维修情况
    maintain_condition_tag(infra) {
      if (infra.maintain_condition === '无需维修') {
        return 'success'
      } else if (infra.maintain_condition === '已维修') {
        return 'warning'
      } else {
        return 'danger'
      }
    },
    // 显示修改基础设施弹窗
    showUpdateInfra(infra) {
      this.dialogVisible = true
      console.log(infra)
      this.infra = { ...infra }
    },
    // 修改基础设施信息
    async updateInfra() {
      let data = {
        infra_code: this.infra.infra_code,
        infra_name: this.infra.infra_name,
        infra_type: this.infra.infra_type,
        location: this.infra.location,
        construction_date: dayjs(this.infra.construction_date).format('YYYY-MM-DD'),
        construction_unit: this.infra.construction_unit,
        construction_capital: this.infra.construction_capital,
        use_condition: this.infra.use_condition,
        operation_condition: this.infra.operation_condition,
        maintain_condition: this.infra.maintain_condition,
        exist_issue: this.infra.exist_issue || '',
        improvement_measure: this.infra.improvement_measure || ''
      }
      console.log('infra_type', typeof data.infra_type)
      console.log('use_condition', typeof data.use_condition)
      if (typeof data.infra_type === 'string') {
        this.dict_infra_type.forEach(item => {
          if (item.infra_type === data.infra_type) {
            data.infra_type = item.id
          }
        })
      }
      if (typeof data.use_condition === 'string') {
        this.dict_use_condition.forEach(item => {
          if (item.use_condition === data.use_condition) {
            data.use_condition = item.id
          }
        })
      }
      if (typeof data.operation_condition === 'string') {
        this.dict_operation_condition.forEach(item => {
          if (item.operation_condition === data.operation_condition) {
            data.operation_condition = item.id
          }
        })
      }
      if (typeof data.maintain_condition === 'string') {
        this.dict_maintain_condition.forEach(item => {
          if (item.maintain_condition === data.maintain_condition) {
            data.maintain_condition = item.id
          }
        })
      }
      // || typeof data.use_condition || typeof data.operation_condition || typeof maintain_condition

      if ((this.infra.use_condition === 1 || this.infra.use_condition === '正常') && (this.infra.operation_condition === 1 || this.infra.operation_condition === '良好') && (this.infra.maintain_condition === 1 || this.infra.maintain_condition === '无需维修')) {
        delete data.exist_issue
        delete data.improvement_measure
        let id = this.infra.id
        let dataPatch = {
          exist_issue: '',
          improvement_measure: ''
        }
        const res1 = await this.$API.infrastructure.updatePatchInfrastructureInfo(id, dataPatch)
        console.log('res1', res1)
      }

      console.log('data', data)
      const res = await this.$API.infrastructure.updateInfrastructureInfo(this.infra.id, data)
      console.log(res)
      if (res.code === 0) {
        this.$message({
          type: 'success',
          message: '更新成功'
        })
        this.infra = {
          infra_code: '',
          infra_name: '',
          infra_type: '',
          location: '',
          construction_date: '',
          construction_unit: '',
          construction_capital: '',
          use_condition: '',
          operation_condition: '',
          maintain_condition: '',
          infra_status: '',
          exist_issue: '',
          improvement_measure: ''
        }
        this.getInfraData(this.page, this.limit)
        this.dialogVisible = false
      }
    },
    // 取消
    cancel() {
      this.$refs['infraForm'].clearValidate()
      this.infra = {
        infra_code: '',
        infra_name: '',
        infra_type: '',
        location: '',
        construction_date: '',
        construction_unit: '',
        construction_capital: '',
        use_condition: '',
        operation_condition: '',
        maintain_condition: '',
        infra_status: '',
        exist_issue: '',
        improvement_measure: ''
      }
      this.dialogVisible = false
    },
    // 弹窗关闭之前
    handleClose(done) {
      this.$confirm('确认关闭？')
        .then(_ => {
          done()
          this.$refs['infraForm'].clearValidate()
          this.infra = {
            infra_code: '',
            infra_name: '',
            infra_type: '',
            location: '',
            construction_date: '',
            construction_unit: '',
            construction_capital: '',
            use_condition: '',
            operation_condition: '',
            maintain_condition: '',
            infra_status: '',
            exist_issue: '',
            improvement_measure: ''
          }
        })
        .catch(_ => {})
    },
    // 显示添加基础设施弹窗
    showAddInfra() {
      this.dialogVisible = true
      this.infra.infra_code = 'JCSS' + `${+new Date()}`.slice(-4) || ''
      // this.infra.construction_date = dayjs(this.infra.construction_date).format('YYYY-MM-DD')
      console.log(this.infra)
    },
    // 添加基础设施信息
    async addInfra() {
      this.$refs['infraForm'].validate(async valid => {
        console.log(valid)
        if (valid) {
          this.infra.construction_date = dayjs(this.infra.construction_date).format('YYYY-MM-DD')
          if ((this.infra.use_condition === 1 || this.infra.use_condition === '正常') && (this.infra.operation_condition === 1 || this.infra.operation_condition === '良好') && (this.infra.maintain_condition === 1 || this.infra.maintain_condition === '无需维修')) {
            delete this.infra.exist_issue
            delete this.infra.improvement_measure
          }
          console.log(this.infra)
          const res = await this.$API.infrastructure.addInfrastructureInfo(this.infra)
          console.log(res)
          if (res.code === 0) {
            this.$message({
              type: 'success',
              message: '新增基础设施信息成功'
            })
            console.log('this.total', this.total)
            this.total = this.total + 1
            // this.getInfraData(this.infra.id ? this.page : 1)
            // this.getInfraData(this.pageList.length <= this.limit ? this.page : this.page + 1)

            this.dialogVisible = false
            this.getInfraData((this.page = Math.ceil(this.total / this.limit)))
            this.infra = {
              infra_code: '',
              infra_name: '',
              infra_type: '',
              location: '',
              construction_date: '',
              construction_unit: '',
              construction_capital: '',
              use_condition: '',
              operation_condition: '',
              maintain_condition: '',
              // infra_status: '',
              exist_issue: '',
              improvement_measure: ''
            }
          } else {
            console.log('error submit!!')
            return false
          }
        }
      })
    },
    // 处理当前页变化
    handleCurrentChange(page) {
      this.page = page
      this.getInfraData(this.page, this.limit)
    },
    // 处理每页显示数目变化
    handleSizeChange(limit) {
      this.limit = limit
      this.getInfraData(this.page, this.limit)
    },
    // 删除基础设施信息
    removeInfra(infra) {
      console.log(infra)
      this.$confirm(`确定删除${infra.infra_code}的信息？`, '提示', {
        confirmButtonClass: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(async () => {
          const res = await this.$API.infrastructure.removeOneInfrastructureInfo(infra.id)
          if (res.code === 0) {
            this.$message({
              type: 'success',
              message: '删除成功'
            })
            this.getInfraData(this.pageList.length > 1 ? this.page : (this.page = this.page - 1))
          }
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
    },
    // 查询
    async search() {
      this.listLoading = true
      this.searchObj = { ...this.tempSearchObj }

      const res = await this.$API.infrastructure.getMoreInfrastructureInfo(this.searchObj, this.page, this.limit)
      this.listLoading = false
      console.log('search', res)
      if (res.code === 0) {
        res.result.pageList.forEach(infra => {
          this.dict_infra_type.forEach(item => {
            if (item.id === infra.infra_type) {
              infra.infra_type = item.infra_type
            }
          })
          this.dict_maintain_condition.forEach(item => {
            if (item.id === infra.maintain_condition) {
              infra.maintain_condition = item.maintain_condition
            }
          })
          this.dict_use_condition.forEach(item => {
            if (item.id === infra.use_condition) {
              infra.use_condition = item.use_condition
            }
          })
          this.dict_operation_condition.forEach(item => {
            if (item.id === infra.operation_condition) {
              infra.operation_condition = item.operation_condition
            }
          })
          infra.construction_date = dayjs(infra.construction_date).format('YYYY-MM-DD')
        })

        res.result.list.forEach(infra => {
          this.dict_infra_type.forEach(item => {
            if (item.id === infra.infra_type) {
              infra.infra_type = item.infra_type
            }
          })
          this.dict_maintain_condition.forEach(item => {
            if (item.id === infra.maintain_condition) {
              infra.maintain_condition = item.maintain_condition
            }
          })
          this.dict_use_condition.forEach(item => {
            if (item.id === infra.use_condition) {
              infra.use_condition = item.use_condition
            }
          })
          this.dict_operation_condition.forEach(item => {
            if (item.id === infra.operation_condition) {
              infra.operation_condition = item.operation_condition
            }
          })
          infra.construction_date = dayjs(infra.construction_date).format('YYYY-MM-DD HH:mm:ss')
        })

        this.pageList = res.result.list
        this.list = res.result.list
        this.total = res.result.total
      }
    },
    // 清空
    resetSearch() {
      this.searchObj = {
        infra_code: '',
        infra_name: '',
        construction_unit: ''
      }

      this.tempSearchObj = {
        infra_code: '',
        infra_name: '',
        construction_unit: ''
      }
      // this.page = 1
      // this.limit = 3

      this.getInfraData(this.page, this.limit)
    },
    // 选中的数据
    handleSelectionChange(selection) {
      console.log(selection)
      this.selectedIds = selection.map(item => item.id)
    },
    // 批量删除
    batchRemove() {
      this.$confirm('确定删除吗？')
        .then(async () => {
          const res = await this.$API.infrastructure.batchRemoveInfrastructureInfo(this.selectedIds)
          if (res.code === 0) {
            this.$message.success('删除成功')
            this.getInfraData(this.page, this.limit)
          }
        })
        .catch(() => {
          this.$message.info('取消删除')
        })
    }
  }
}
</script>

<style scoped>
.container {
  padding: 0px 20px;
}
</style>
