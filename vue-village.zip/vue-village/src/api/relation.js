import request from '@/utils/request'

/* eslint-disable */
export const getRelationInfo = (page, limit) => request({ url: '/relation', method: 'get', params: { page, limit } })

export const getMoreRelationInfo = ({ household_number }, page, limit) => request({ url: `/relation/moreinfo?page=${page}&limit=${limit}&household_number=${household_number}` })
