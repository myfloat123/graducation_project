<template>
  <div>人口死亡信息</div>
</template>

<script>
export default {
  name: 'Death'
}
</script>

<style scoped></style>
