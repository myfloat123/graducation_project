<template>
  <div class="app-container">
    <el-form inline>
      <!-- 表单元素 -->
      <el-form-item>
        <el-input v-model="tempSearchObj.user_name" placeholder="用户名" />
      </el-form-item>
      <!-- 查询与清空的按钮 -->
      <el-button type="primary" icon="el-icon-search" @click="search">查询</el-button>
      <el-button type="default" @click="resetSearch">清空</el-button>
    </el-form>

    <div style="margin-bottom: 20px">
      <!-- 添加与批量添加按钮 -->
      <el-button type="primary" @click="showAddUser">添加</el-button>
      <el-button type="danger" :disabled="selectedIds.length === 0" @click="revomveUsers">批量删除</el-button>
    </div>

    <!-- table表格：展示用户信息的地方 -->
    <el-table v-loading="listLoading" border stripe :data="users" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" />

      <el-table-column type="index" label="序号" width="80" align="center" />

      <el-table-column prop="user_name" label="用户名" width="150" />
      <el-table-column prop="avatar" label="用户头像" width="180" align="center">
        <template slot-scope="{ row }">
          <!-- eslint-disable -->
          <img :src="`http://localhost:8000/${row.avatar}`" alt="" style="width: 100px; height: 100px; text-align: center" />
        </template>
      </el-table-column>
      <el-table-column prop="role_name" label="权限列表" />

      <el-table-column prop="createdAt" label="创建时间" width="180" />
      <el-table-column prop="updatedAt" label="更新时间" width="180" />

      <el-table-column label="操作" width="230" align="center">
        <template slot-scope="{ row }">
          <HintButton type="info" size="mini" icon="el-icon-user-solid" title="分配角色" @click="showAssignRole(row)" />
          <HintButton type="primary" size="mini" icon="el-icon-edit" title="修改用户" @click="showUpdateUser(row)" />
          <el-popconfirm :title="`确定删除 ${row.user_name} 吗?`" @onConfirm="removeUser(row.id)">
            <HintButton slot="reference" style="margin-left: 10px" type="danger" size="mini" icon="el-icon-delete" title="删除用户" />
          </el-popconfirm>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页器 -->
    <el-pagination :current-page="page" :total="total" :page-size="limit" :page-sizes="[3, 10, 20, 30, 40, 50, 100]" style="margin-top: 20px; text-align: center" layout="prev, pager, next, jumper, ->, sizes, total" @current-change="handleCurrentChange" @size-change="handleSizeChange" />
    <!-- 对话框的结构 -->
    <el-dialog :title="user.id ? '修改用户' : '添加用户'" :visible.sync="dialogUserVisible">
      <el-form ref="userForm" :model="user" :rules="userRules" label-width="120px">
        <el-form-item label="用户名" prop="user_name">
          <el-input v-model="user.user_name" />
        </el-form-item>
        <el-form-item label="用户头像" prop="avatar" v-show="user.id">
          <el-upload class="avatar-uploader" action="/dev-api/users/" :show-file-list="false" :on-success="handleAvatarSuccess" :before-upload="beforeAvatarUpload">
            <!-- eslint-disable -->
            <i v-if="user.avatar === ''" class="el-icon-plus avatar-uploader-icon" />
            <!-- <img v-else-if="villager.villager_picture === null ? true : false" src="http://localhost:8000/1b84679d1b1c4b1879ce89200.gif" class="avatar" /> -->

            <img v-else :src="'http://localhost:8000/' + user.avatar" class="avatar" />
            <div slot="tip" class="el-upload__tip">只能上传png/jpg/jpeg/gif文件，且不超过5MB</div>
          </el-upload>
        </el-form-item>

        <el-form-item v-if="!user.id" label="用户密码" prop="password">
          <el-input v-model="user.password" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="cancel">取 消</el-button>
        <el-button :loading="loading" type="primary" @click="addOrUpdate">确 定</el-button>
      </div>
    </el-dialog>

    <el-dialog title="设置角色" :visible.sync="dialogRoleVisible" :before-close="resetRoleData">
      <el-form label-width="80px">
        <el-form-item label="用户名">
          <el-input disabled :value="user.user_name" />
        </el-form-item>

        <el-form-item label="角色列表">
          <el-checkbox v-model="checkAll" :indeterminate="isIndeterminate" @change="handleCheckAllChange">全选</el-checkbox>
          <div style="margin: 15px 0" />
          <el-checkbox-group v-model="userRoleIds" @change="handleCheckedChange">
            <el-checkbox v-for="role in allRoles" :key="role.id" :label="role.id">{{ role.role_name }}</el-checkbox>
          </el-checkbox-group>
        </el-form-item>
      </el-form>

      <div slot="footer">
        <el-button :loading="loading" type="primary" @click="assignRole">保存</el-button>
        <el-button @click="resetRoleData">取消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import cloneDeep from 'lodash/cloneDeep'
import Cookies from 'js-cookie'
import dayjs from 'dayjs'
// import {validUsername} from '@/utils/validate'

export default {
  name: 'AclUserList',

  data() {
    return {
      listLoading: false, // 是否显示列表加载的提示
      searchObj: {
        // 包含请求搜索条件数据的对象
        user_name: ''
      },
      tempSearchObj: {
        // 收集搜索条件输入的对象
        user_name: ''
      },
      // 所有用户信息列表
      list: [],
      // 每页显示用户信息列表
      pageList: [],
      selectedIds: [], // 所有选择的user的id的数组
      users: [], // 当前页的用户列表
      page: 1, // 当前页码
      limit: 3, // 每页数量
      total: 0, // 总数量
      user: {}, // 当前要操作的user
      dialogUserVisible: false, // 是否显示用户添加/修改的dialog
      userRules: {
        // 用户添加/修改表单的校验规则
        user_name: [
          { required: true, message: '用户名必须输入' },
          { min: 4, message: '用户名不能小于4位' }
        ],
        password: [{ required: true, validator: this.validatePassword }]
      },
      loading: false, // 是否正在提交请求中
      dialogRoleVisible: false, // 是否显示角色Dialog
      allRoles: [], // 所有角色列表
      userRoleIds: [], // 用户的角色ID的列表
      isIndeterminate: false, // 是否是不确定的
      checkAll: false // 是否全选
    }
  },

  // 发请求一般情况下，我们都是在mounted去发，但是也可以在created内部去发
  created() {
    this.getUsers()
  },

  methods: {
    /*
    显示指定角色的界面
    */
    showAssignRole(user) {
      this.user = user
      this.dialogRoleVisible = true
      this.getRoles()
    },

    /*
    全选勾选状态发生改变的监听
    */
    handleCheckAllChange(value) {
      // value 当前勾选状态true/false
      // 如果当前全选, userRoleIds就是所有角色id的数组, 否则是空数组
      this.userRoleIds = value ? this.allRoles.map(item => item.id) : []
      // 如果当前不是全选也不全不选时, 指定为false
      this.isIndeterminate = false
    },

    /*
    异步获取用户的角色列表
    */
    async getRoles() {
      const roles = await this.$API.role.getPageList()
      const res = await this.$API.useracl.getRoles(this.user.id)
      // console.log(this.user.id)
      // const { allRolesList, assignRoles } = res.result
      let allRolesList = roles.result.list
      let assignRoles = res.result.list
      this.allRoles = allRolesList
      this.userRoleIds = assignRoles.map(item => item.id)

      this.checkAll = allRolesList.length === assignRoles.length
      this.isIndeterminate = assignRoles.length > 0 && assignRoles.length < allRolesList.length
    },

    /*
    角色列表选中项发生改变的监听
    */
    handleCheckedChange(value) {
      const { userRoleIds, allRoles } = this
      this.checkAll = userRoleIds.length === allRoles.length && allRoles.length > 0
      this.isIndeterminate = userRoleIds.length > 0 && userRoleIds.length < allRoles.length
    },

    /*
    请求给用户进行角色授权
    */
    async assignRole() {
      const userId = this.user.id
      const roleIds = this.userRoleIds
      this.loading = true
      const res = await this.$API.useracl.assignRoles(userId, roleIds, 'add')

      if (res.code === 0) {
        // window.location.reload()
        this.loading = false
        this.getUsers(this.page, this.limit, this.searchObj)
        this.$message.success('分配角色成功')
        this.resetRoleData()
      } else {
        this.loading = false
        this.getUsers()
        this.resetRoleData()
      }

      // console.log(this.$store.getters.name, this.user)
      if (this.$store.getters.name === this.user.user_name) {
        window.location.reload()
      }
    },

    /*
    重置用户角色的数据
    */
    resetRoleData() {
      this.dialogRoleVisible = false
      this.allRoles = []
      this.userRoleIds = []
      this.isIndeterminate = false
      this.checkAll = false
    },

    /*
    自定义密码校验
    */
    validatePassword(rule, value, callback) {
      if (!value) {
        callback('密码必须输入')
      } else if (!value || value.length < 6) {
        callback('密码不能小于6位')
      } else {
        callback()
      }
    },
    /*
    根据输入进行搜索
    */
    search() {
      this.searchObj = { ...this.tempSearchObj }
      this.getUsers(this.page, this.limit, this.searchObj)
    },

    /*
    重置输入后搜索
    */
    resetSearch() {
      this.searchObj = {
        user_name: ''
      }
      this.tempSearchObj = {
        user_name: ''
      }
      this.getUsers()
    },

    /*
    显示添加用户的界面
    */
    showAddUser() {
      this.user = {}
      this.dialogUserVisible = true

      this.$nextTick(() => this.$refs.userForm.clearValidate())
    },

    /*
    删除所有选中的用户
    */
    revomveUsers() {
      // console.log(this.selectedIds)
      let ids = []
      ids = Array.from(this.selectedIds)
      // console.log(ids)
      this.$confirm('确定删除吗?')
        .then(async () => {
          await this.$API.useracl.removeUsers(ids)
          this.$message.success('删除成功')
          this.getUsers()
        })
        .catch(err => {
          console.log(err)
          this.$message.info('取消删除')
        })
    },

    /*
    列表选中状态发生改变的监听回调
    */
    handleSelectionChange(selection) {
      // console.log(selection)
      this.selectedIds = selection.map(item => item.id)
    },

    /*
    显示更新用户的界面
    */
    showUpdateUser(user) {
      this.user = cloneDeep(user)

      this.dialogUserVisible = true
    },

    /*
    删除某个用户
    */
    async removeUser(id) {
      await this.$API.useracl.removeById(id)
      this.$message.success('删除成功')
      this.getUsers(this.users.length === 1 ? this.page - 1 : this.page)
    },

    /*
    获取分页列表
    */
    async getUsers(page = 1, limit = 3, searchObj = { user_name: '' }) {
      this.page = page
      this.limit = limit
      this.searchObj = searchObj

      this.listLoading = true
      let params = { page, limit, ...searchObj }
      const res = await this.$API.useracl.getPageList(params)
      this.listLoading = false
      res.result.list.forEach(item => {
        item.createdAt = dayjs(item.createdAt).format('YYYY-MM-DD HH:mm:ss')
        item.updatedAt = dayjs(item.updatedAt).format('YYYY-MM-DD HH:mm:ss')
      })
      res.result.pageList.forEach(item => {
        item.createdAt = dayjs(item.createdAt).format('YYYY-MM-DD HH:mm:ss')
        item.updatedAt = dayjs(item.updatedAt).format('YYYY-MM-DD HH:mm:ss')
      })
      this.list = res.result.list
      this.pageList = res.result.pageList

      this.users = this.pageList.filter(item => item.user_name !== 'admin')
      this.total = res.result.total - 1
      this.selectedIds = []
    },
    // 处理当前页变化
    handleCurrentChange(page) {
      this.page = page
      this.getUsers(this.page, this.limit, this.searchObj)
    },

    /*
    处理pageSize发生改变的监听回调
    */
    handleSizeChange(pageSize) {
      this.limit = pageSize
      this.getUsers(this.page, this.limit, this.searchObj)
    },

    /*
    取消用户的保存或更新
    */
    cancel() {
      this.dialogUserVisible = false
      this.user = {}
    },

    /*
    保存或者更新用户
    */
    addOrUpdate() {
      this.$refs.userForm.validate(valid => {
        if (valid) {
          const { user } = this
          // console.log(user)
          this.loading = true
          this.$API.useracl[user.id ? 'update' : 'add'](user).then(result => {
            if (result.message === '用户注册成功') {
            }
            this.loading = false
            this.$message.success('保存成功!')
            this.getUsers(user.id ? this.page : 1)
            this.user = {}
            this.dialogUserVisible = false
          })
        }
      })
    },
    // 头像上传之前的函数处理
    beforeAvatarUpload(file) {
      const fileTypes = ['image/png', 'image/jpg', 'image/jpeg', 'image/gif']
      if (!fileTypes.includes(file.type)) {
        this.$message.error('上传头像图片仅支持png、jpg、jpeg、gif 格式！')
      }
      if (!(file.size / 1024 / 1024 < 5)) {
        this.$message.error('上传头像图片大小不能超过 5MB！')
      }
      const token = Cookies.get('vue_admin_template_token')
      console.log(token)
      return file.type && file.size / 1024 / 1024 < 5
    },
    // 头像上传成功后的函数处理
    async handleAvatarSuccess(res, file) {
      // console.log(res)
      this.user.avatar = res.result.imgUrl
      // this.$router.replace({
      //   path: '/personalcenter/blankpage',
      //   name: 'BlankPage'
      // })
      // this.$router.go(0)
    }
  }
}
</script>

<style scoped>
>>> .avatar-uploader .el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
.avatar-uploader .el-upload:hover {
  border-color: #409eff;
}
.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 178px;
  height: 178px;
  line-height: 178px;
  text-align: center;
}
.avatar {
  width: 178px;
  height: 178px;
  display: block;
}
</style>
