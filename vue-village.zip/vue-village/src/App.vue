<template>
  <div id="app">
    <!-- <keep-alive :exclude="exclude"> -->
    <!-- <keep-alive> -->
    <router-view />
    <!-- </keep-alive> -->
    <!-- </keep-alive> -->
  </div>
</template>

<script>
export default {
  name: 'App',
  data() {
    return {
      exclude: '' // 定义一个字符串来存储不需要缓存的页面
    }
  },
  watch: {
    // 监听路由的变化
    $route(to, from) {
      // 如果路由带有reload参数，就把目标路由添加到exclude字符串中

      console.log(window.location.hash.substring(1))
      // this.$router.push()
      console.log(from)
      console.log(to)
      if (this.$route.fullPath !== '/404') {
        this.$store.commit('SET_URL', this.$route.fullPath)
      }
    }
  },
  mounted() {
    // window.addEventListener('beforeunload', this.beforeUnload)
    // window.addEventListener('unload', this.unload)
    console.log(this.$route.fullPath)
  },
  beforeDestroy() {
    // this.$store.commit('url/SET_URL', window.location.hash.substring(1))
    // window.removeEventListener('beforeunload', this.beforeUnload)
    // window.removeEventListener('unload', this.unload)
  },
  destroyed() {},
  methods: {
    // beforeUnload(event) {
    //   // 在页面刷新前执行的代码
    //   localStorage.setItem('beforeUnloadTime', Date.now())
    // },
    // unload(event) {
    //   // 在页面刷新后执行的代码
    //   const beforeUnloadTime = localStorage.getItem('beforeUnloadTime')
    //   if (beforeUnloadTime && Date.now() - beforeUnloadTime < 1000) {
    //     // 判断页面是否刷新
    //     this.$router.push('/other-page') // 跳转到指定页面
    //     event.preventDefault() // 阻止页面卸载
    //   }
    // }
  }
}
</script>
