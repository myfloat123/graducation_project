const fs = require('fs')(fs.readFile('./textfiles/txt1.txt', 'utf8', (err, dataStr) => {
  if (err) return console.log('读物文件失败！' + err.message)
  console.log('读取文件成功！')
  console.log(dataStr)
}))()

