<template>
  <div class="container">
    <el-form inline style="margin-top: 20px">
      <!-- 表单元素 -->
      <el-form-item>
        <el-input v-model="tempSearchObj.hygiene_code" placeholder="环境卫生编号" />
      </el-form-item>
      <el-form-item>
        <el-input v-model="tempSearchObj.hygiene_accendant" placeholder="维护人员" />
      </el-form-item>
      <!-- 查询与清空按钮 -->
      <!--  -->
      <!--  -->
      <el-button type="primary" icon="el-icon-search" @click="search">查询</el-button>
      <el-button type="default" @click="resetSearch">清空</el-button>
    </el-form>

    <!-- 添加与批量删除按钮 -->
    <div style="margin-bottom: 20px">
      <el-button type="primary" @click="showAddHygiene">添加</el-button>
      <el-button type="danger" :disabled="selectedIds.length === 0" @click="batchRemove">批量删除</el-button>
    </div>

    <!-- table表格：展示环境卫生信息 -->
    <el-table v-loading="listLoading" border stripe :data="pageList" style="width: 100%" @selection-change="handleSelectionChange">
      <el-table-column type="selection" />
      <el-table-column type="index" label="序号" align="center" />
      <el-table-column header-align="center" align="center" prop="hygiene_code" label="环境卫生编号" width="200" />
      <el-table-column header-align="center" align="center" prop="hygiene_accendant" label="维护人员" width="200" />
      <el-table-column header-align="center" align="center" prop="hygiene_trash_can_number" label="垃圾桶数量" width="100" />
      <el-table-column header-align="center" align="center" prop="hygiene_trash_can_clean_situation" label="垃圾桶清理情况" width="200">
        <template slot-scope="{ row }">
          <el-tag :type="hygiene_trash_can_clean_situation_tag(row)" disable-transitions>{{ row.hygiene_trash_can_clean_situation }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column header-align="center" align="center" prop="hygiene_toilet_number" label="厕所数量" width="100" />
      <el-table-column header-align="center" align="center" prop="hygiene_toilet_clean_situation" label="厕所清洁情况" width="200">
        <template slot-scope="{ row }">
          <el-tag :type="hygiene_toilet_clean_situation_tag(row)" disable-transitions>{{ row.hygiene_toilet_clean_situation }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column header-align="center" align="center" prop="hygiene_remark" label="备注" />
      <el-table-column header-align="center" align="center" prop="prop" label="操作" width="300px" fixed="right">
        <template slot-scope="{ row }">
          <el-button type="info" icon="el-icon-info" size="mini" @click="showHygieneDetail(row)">查看</el-button>
          <el-button type="warning" icon="el-icon-edit" size="mini" @click="showUpdateHygiene(row)">修改</el-button>
          <el-button type="danger" icon="el-icon-delete" size="mini" @click="removeHygiene(row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页器 -->
    <!--   -->
    <el-pagination style="margin-top: 20px; text-align: center" :current-page="page" :page-sizes="[3, 5, 10]" :page-count="7" :page-size.sync="limit" layout="prev, pager, next, jumper, ->, sizes, total" :total="total" @current-change="handleCurrentChange" @size-change="handleSizeChange" />

    <!-- 环境卫生信息弹窗 -->
    <!--  -->
    <el-dialog :title="hygiene.id ? `${disabled_hygiene ? '查看' : '修改'}环境卫生信息` : '添加环境卫生信息'" :visible.sync="dialogVisible" :before-close="dialogBeforeClose">
      <el-form ref="hygieneForm" :model="hygiene" :rules="hygieneRules" inline>
        <el-form-item label="环境卫生编号" prop="hygiene_code">
          <el-input v-model="hygiene.hygiene_code" :disabled="disabled_hygiene ? true : false" />
        </el-form-item>
        <el-form-item label="维护人员" prop="hygiene_accendant" label-width="130px">
          <el-input v-model="hygiene.hygiene_accendant" :disabled="disabled_hygiene ? true : false" />
        </el-form-item>
        <el-form-item label="垃圾桶数量" prop="hygiene_trash_can_number" label-width="130px">
          <el-input v-model="hygiene.hygiene_trash_can_number" :disabled="disabled_hygiene ? true : false" />
        </el-form-item>
        <el-form-item v-show="hygiene.hygiene_trash_can_number != 0 || hygiene.hygiene_trash_can_number === ''" label="垃圾桶清理情况" prop="hygiene_trash_can_clean_situation">
          <el-select v-model="hygiene.hygiene_trash_can_clean_situation" :disabled="disabled_hygiene ? true : false">
            <el-option v-for="item in dict_hygiene_trash_can_clean_situation" :key="item.id" :label="item.hygiene_trash_can_clean_situation" :value="item.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="厕所数量" prop="hygiene_toilet_number" label-width="100px">
          <el-input v-model="hygiene.hygiene_toilet_number" :disabled="disabled_hygiene ? true : false" />
        </el-form-item>
        <el-form-item v-show="hygiene.hygiene_toilet_number != 0 || hygiene.hygiene_toilet_number === ''" label="厕所清洁情况" prop="hygiene_toilet_clean_situation" label-width="150px">
          <el-select v-model="hygiene.hygiene_toilet_clean_situation" :disabled="disabled_hygiene ? true : false" style="width: 100px">
            <el-option v-for="item in dict_hygiene_toilet_clean_situation" :key="item.id" :label="item.hygiene_toilet_clean_situation" :value="item.id" />
          </el-select>
        </el-form-item>
        <div>
          <el-form-item v-show="hygiene.id" label="创建时间" prop="createdAt">
            <el-input v-model="hygiene.createdAt" disabled />
          </el-form-item>
        </div>
        <div v-show="hygiene.createdAt !== hygiene.updatedAt">
          <el-form-item label="更新时间" prop="updatedAt">
            <el-input v-model="hygiene.updatedAt" disabled />
          </el-form-item>
        </div>
        <div>
          <el-form-item label="备注" prop="hygiene_remark">
            <el-input v-model="hygiene.hygiene_remark" type="textarea" :disabled="disabled_hygiene ? true : false" :autosize="{ minRows: 5, maxRows: 10 }" :cols="100" />
          </el-form-item>
        </div>
      </el-form>
      <div v-show="!disabled_hygiene" slot="footer">
        <el-button @click="cancel">取 消</el-button>
        <el-button type="primary" @click="hygiene.id ? updateHygiene() : addHygiene()">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import dayjs from 'dayjs'
export default {
  name: 'Assanation',
  data() {
    return {
      // 当前页码
      page: 1,
      // 每页数量
      limit: 3,
      // 总数
      total: 0,
      // 是否显示列表加载的提示
      listLoading: false,
      // 选择的环境卫生信息id数组
      selectedIds: [],
      // 每页环境卫生信息列表
      pageList: [],
      // 环境卫生信息列表
      list: [],
      // 是否显示弹窗
      dialogVisible: false,
      // 是否查信息看环境卫生
      disabled_hygiene: false,
      // 收集搜索条件输入的对象
      tempSearchObj: {
        hygiene_code: '',
        hygiene_accendant: ''
      },
      // 包含请求搜索条件数据的对象
      searchObj: {
        hygiene_code: '',
        hygiene_accendant: ''
      },
      // 当前操作的环境卫生信息对象
      hygiene: {
        hygiene_code: '',
        hygiene_accendant: '',
        hygiene_trash_can_number: '',
        hygiene_trash_can_clean_situation: '',
        hygiene_toilet_number: '',
        hygiene_toilet_clean_situation: '',
        hygiene_remark: ''
      },
      // 垃圾桶清理情况字典
      dict_hygiene_trash_can_clean_situation: [
        // { id: 0, hygiene_trash_can_clean_situation: '无' },
        { id: 1, hygiene_trash_can_clean_situation: '待清理' },
        { id: 2, hygiene_trash_can_clean_situation: '已清理' }
      ],
      // 厕所清洁情况字典
      dict_hygiene_toilet_clean_situation: [
        // { id: 0, hygiene_toilet_clean_situation: '无' },
        { id: 1, hygiene_toilet_clean_situation: '干净' },
        { id: 2, hygiene_toilet_clean_situation: '较干净' },
        { id: 3, hygiene_toilet_clean_situation: '很脏' }
      ],
      // 环境卫生信息验证规则
      hygieneRules: {
        hygiene_code: [{ required: true, message: '请输入环境卫生编号', trigger: 'blur' }],
        hygiene_accendant: [{ required: true, message: '请输入维护人员', trigger: 'blur' }],
        hygiene_trash_can_number: [{ required: true, message: '请输入垃圾桶数量', trigger: 'blur' }],
        hygiene_trash_can_clean_situation: [{ required: true, message: '请选择垃圾清理情况', trigger: 'blur' }],
        hygiene_toilet_number: [{ required: true, message: '请输入厕所数量', trigger: 'blur' }],
        hygiene_toilet_clean_situation: [{ required: true, message: '请选择厕所清洁情况', trigger: 'blur' }],
        hygiene_remark: [{ required: false, message: '请输入备注', trigger: 'blur' }]
      }
    }
  },
  mounted() {
    this.getHygieneData()
  },
  methods: {
    // 获取环境卫生信息
    async getHygieneData(page = 1, limit = 3, searchObj = { hygiene_code: '', hygiene_accendant: '' }) {
      this.page = page
      this.limit = limit
      this.searchObj = searchObj
      this.listLoading = true
      let params = { page, limit, ...searchObj }
      const res = await this.$API.hygiene.getHygieneInfo(params)
      this.listLoading = false
      if (res.code === 0) {
        res.result.pageList.forEach(hygiene => {
          hygiene.createdAt = dayjs(hygiene.createdAt).format('YYYY-MM-DD HH:mm:ss')
          hygiene.updatedAt = dayjs(hygiene.updatedAt).format('YYYY-MM-DD HH:mm:ss')
          if (hygiene.hygiene_trash_can_clean_situation === 0) {
            hygiene.hygiene_trash_can_clean_situation = '无'
          }
          if (hygiene.hygiene_toilet_clean_situation === 0) {
            hygiene.hygiene_toilet_clean_situation = '无'
          }
          this.dict_hygiene_trash_can_clean_situation.forEach(item => {
            if (item.id === hygiene.hygiene_trash_can_clean_situation) {
              hygiene.hygiene_trash_can_clean_situation = item.hygiene_trash_can_clean_situation
            }
          })
          this.dict_hygiene_toilet_clean_situation.forEach(item => {
            if (item.id === hygiene.hygiene_toilet_clean_situation) {
              hygiene.hygiene_toilet_clean_situation = item.hygiene_toilet_clean_situation
            }
          })
        })
        res.result.list.forEach(hygiene => {
          hygiene.createdAt = dayjs(hygiene.createdAt).format('YYYY-MM-DD HH:mm:ss')
          hygiene.updatedAt = dayjs(hygiene.updatedAt).format('YYYY-MM-DD HH:mm:ss')
          if (hygiene.hygiene_trash_can_clean_situation === 0) {
            hygiene.hygiene_trash_can_clean_situation = '无'
          }
          if (hygiene.hygiene_toilet_clean_situation === 0) {
            hygiene.hygiene_toilet_clean_situation = '无'
          }
          this.dict_hygiene_trash_can_clean_situation.forEach(item => {
            if (item.id === hygiene.hygiene_trash_can_clean_situation) {
              hygiene.hygiene_trash_can_clean_situation = item.hygiene_trash_can_clean_situation
            }
          })
          this.dict_hygiene_toilet_clean_situation.forEach(item => {
            if (item.id === hygiene.hygiene_toilet_clean_situation) {
              hygiene.hygiene_toilet_clean_situation = item.hygiene_toilet_clean_situation
            }
          })
        })

        this.pageList = res.result.pageList
        this.list = res.result.list
        this.total = res.result.total
      }
    },
    // 查看环境卫生信息
    async showHygieneDetail(hygiene) {
      this.dialogVisible = true
      this.disabled_hygiene = true
      this.hygiene = { ...hygiene }
    },
    // 弹窗关闭前的处理函数
    dialogBeforeClose(done) {
      this.$confirm('确认关闭？')
        .then(_ => {
          done()
          this.$refs['hygieneForm'].clearValidate()
          this.hygiene = {
            hygiene_code: '',
            hygiene_accendant: '',
            hygiene_trash_can_number: '',
            hygiene_trash_can_clean_situation: '',
            hygiene_toilet_number: '',
            hygiene_toilet_clean_situation: '',
            hygiene_remark: ''
          }
          this.disabled_hygiene = false
        })
        .catch(_ => {
          console.log(_)
        })
    },
    // 显示修改环境卫生信息弹窗
    showUpdateHygiene(hygiene) {
      this.dialogVisible = true
      this.hygiene = { ...hygiene }
    },
    // 修改环境卫生信息
    async updateHygiene() {
      let id = this.hygiene.id
      let data = {
        hygiene_code: this.hygiene.hygiene_code,
        hygiene_accendant: this.hygiene.hygiene_accendant,
        hygiene_trash_can_number: this.hygiene.hygiene_trash_can_number - 0,
        hygiene_trash_can_clean_situation: this.hygiene.hygiene_trash_can_clean_situation,
        hygiene_toilet_number: this.hygiene.hygiene_toilet_number - 0,
        hygiene_toilet_clean_situation: this.hygiene.hygiene_toilet_clean_situation,
        hygiene_remark: this.hygiene.hygiene_remark
      }
      if (data.hygiene_trash_can_number == 0) {
        data.hygiene_trash_can_clean_situation = 0
      }
      if (data.hygiene_toilet_number == 0) {
        data.hygiene_toilet_clean_situation = 0
      }

      if (typeof data.hygiene_trash_can_clean_situation === 'string') {
        this.dict_hygiene_trash_can_clean_situation.forEach(item => {
          if (item.hygiene_trash_can_clean_situation === data.hygiene_trash_can_clean_situation) {
            data.hygiene_trash_can_clean_situation = item.id
          }
        })
      }
      if (typeof data.hygiene_toilet_clean_situation === 'string') {
        this.dict_hygiene_toilet_clean_situation.forEach(item => {
          if (item.hygiene_toilet_clean_situation === data.hygiene_toilet_clean_situation) {
            data.hygiene_toilet_clean_situation = item.id
          }
        })
      }

      data.hygiene_trash_can_clean_situation === '无' && Object.assign(data, { hygiene_trash_can_clean_situation: 0 })
      data.hygiene_toilet_clean_situation === '无' && Object.assign(data, { hygiene_toilet_clean_situation: 0 })

      if (data.hygiene_remark === '') {
        delete data.hygiene_remark
      }

      const res = await this.$API.hygiene.updatehygieneInfo(id, data)
      if (res.code === 0) {
        this.$message({
          type: 'success',
          message: '更新成功'
        })
        this.hygiene = {
          hygiene_code: '',
          hygiene_accendant: '',
          hygiene_trash_can_number: '',
          hygiene_trash_can_clean_situation: '',
          hygiene_toilet_number: '',
          hygiene_toilet_clean_situation: '',
          hygiene_remark: ''
        }
        this.getHygieneData(this.page, this.limit)
        this.dialogVisible = false
      }
    },
    // 取消
    cancel() {
      this.$refs['hygieneForm'].clearValidate()
      this.hygiene = {
        hygiene_code: '',
        hygiene_accendant: '',
        hygiene_trash_can_number: '',
        hygiene_trash_can_clean_situation: '',
        hygiene_toilet_number: '',
        hygiene_toilet_clean_situation: '',
        hygiene_remark: ''
      }
      this.dialogVisible = false
      this.disabled_hygiene = false
    },
    // 显示添加环境卫生信息弹窗
    showAddHygiene() {
      this.dialogVisible = true
      this.hygiene.hygiene_code = 'HJWS' + `${+new Date()}`.slice(-4) || ''
    },
    // 新增环境卫生信息
    addHygiene() {
      this.$refs['hygieneForm'].validate(async valid => {
        if (valid) {
          if (this.hygiene.hygiene_trash_can_number == 0 || this.hygiene.hygiene_trash_can_clean_situation === '') {
            delete this.hygiene.hygiene_trash_can_clean_situation
          }
          if (this.hygiene.hygiene_toilet_number == 0 || this.hygiene.hygiene_toilet_clean_situation === '') {
            delete this.hygiene.hygiene_toilet_clean_situation
          }
          this.hygiene.hygiene_trash_can_number = this.hygiene.hygiene_trash_can_number - 0
          this.hygiene.hygiene_toilet_number = this.hygiene.hygiene_toilet_number - 0
          const res = await this.$API.hygiene.addHygieneInfo(this.hygiene)
          if (res.code === 0) {
            this.$message({
              type: 'success',
              message: '新增环境卫生信息成功'
            })
            // this.total = this.total + 1
            this.dialogVisible = false
            // this.getHygieneData((this.page = Math.ceil(this.total / this.limit)), this.limit, this.searchObj)
            this.getHygieneData(this.page, this.limit, this.searchObj)
            this.hygiene = {
              hygiene_code: '',
              hygiene_accendant: '',
              hygiene_trash_can_number: '',
              hygiene_trash_can_clean_situation: '',
              hygiene_toilet_number: '',
              hygiene_toilet_clean_situation: '',
              hygiene_remark: ''
            }
          } else {
            console.log('error submit!!')
            return false
          }
        }
        this.dialogVisible = false
      })
    },
    // 处理当前页变化
    handleCurrentChange(page) {
      this.page = page
      this.getHygieneData(this.page, this.limit, this.searchObj)
    },
    // 处理每页显示数目变化
    handleSizeChange(limit) {
      this.limit = limit
      this.getHygieneData(this.page, this.limit, this.searchObj)
    },
    // 垃圾桶清理情况
    hygiene_trash_can_clean_situation_tag(hygiene) {
      if (hygiene.hygiene_trash_can_clean_situation === '无' || hygiene.hygiene_trash_can_clean_situation == 0) {
        return 'info'
      } else if (hygiene.hygiene_trash_can_clean_situation === '待清理' || hygiene.hygiene_trash_can_clean_situation == 1) {
        return 'danger'
      } else {
        return 'success'
      }
    },
    // 厕所清洁情况
    hygiene_toilet_clean_situation_tag(hygiene) {
      if (hygiene.hygiene_toilet_clean_situation === '无' || hygiene.hygiene_toilet_clean_situation == 0) {
        return 'info'
      } else if (hygiene.hygiene_toilet_clean_situation === '干净' || hygiene.hygiene_toilet_clean_situation == 1) {
        return 'success'
      } else if (hygiene.hygiene_toilet_clean_situation === '较干净' || hygiene.hygiene_toilet_clean_situation == 2) {
        return ''
      } else {
        return 'danger'
      }
    },
    // 查询
    search() {
      this.searchObj = { ...this.tempSearchObj }
      this.getHygieneData(this.page, this.limit, this.searchObj)
    },
    // 清空
    resetSearch() {
      this.searchObj = {
        hygiene_code: '',
        hygiene_accendant: ''
      }
      this.tempSearchObj = {
        hygiene_code: '',
        hygiene_accendant: ''
      }
      this.getHygieneData(this.page, this.limit, this.searchObj)
    },
    // 删除
    removeHygiene(hygiene) {
      this.$confirm(`确定删除${hygiene.hygiene_code}的信息？`, '提示', {
        confirmButtonClass: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(async () => {
          const res = await this.$API.hygiene.removeHygieneInfo(hygiene.id)
          if (res.code === 0) {
            this.$message({
              type: 'success',
              message: '删除成功'
            })
            this.getHygieneData(this.pageList.length > 1 ? this.page : (this.page = this.page - 1), this.limit)
          }
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
    },
    // 选中的数据
    handleSelectionChange(selection) {
      this.selectedIds = selection.map(item => item.id)
    },
    // 批量删除环境卫生信息
    batchRemove() {
      this.$confirm('确定删除吗？')
        .then(async () => {
          const res = await this.$API.hygiene.batchRemoveHygieneInfo(this.selectedIds)
          if (res.code === 0) {
            this.$message.success('删除成功')
            this.getHygieneData(this.page, this.limit)
          }
        })
        .catch(() => {
          this.$message.info('取消删除')
        })
    }
  }
}
</script>

<style scoped>
.container {
  padding: 0px 20px;
}

>>> .el-textarea.is-disabled .el-textarea__inner {
  background-color: #fff;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  color: #606266;
}

>>> .el-input.is-disabled .el-input__inner {
  background-color: #fff;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  color: #606266;
}
</style>
