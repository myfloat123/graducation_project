<template>
  <div class="container">
    <el-form inline style="margin-top: 20px">
      <!-- 表单元素 -->
      <el-form-item>
        <el-input ref="el_input_name" v-model="tempSearchObj.villager_name" placeholder="姓名" />
      </el-form-item>
      <el-form-item>
        <el-input ref="el_input_ID_number" v-model="tempSearchObj.villager_ID_number" placeholder="身份证号" />
      </el-form-item>
      <el-form-item>
        <el-input ref="el_input_phone" v-model="tempSearchObj.villager_phone" placeholder="手机号" />
      </el-form-item>
      <!-- 查询与清空按钮 -->
      <el-button type="primary" icon="el-icon-search" @click="search">查询</el-button>
      <el-button type="default" @click="resetSearch">清空</el-button>
    </el-form>

    <div style="margin-bottom: 20px">
      <!-- 添加与批量删除按钮 -->
      <el-button type="primary" @click="showAddVillager">添加</el-button>
      <el-button type="danger" :disabled="selectedIds.length === 0" @click="batchRemove">批量删除</el-button>
    </div>

    <!-- table表格：展示村民信息 -->
    <el-table v-loading="listLoading" border stripe :data="pageList" style="width: 100%" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" />
      <el-table-column type="index" label="序号" width="55" align="center" />
      <el-table-column prop="villager_name" label="姓名" align="center" />
      <el-table-column prop="villager_age" label="年龄" width="100" align="center" />
      <el-table-column prop="villager_sex" label="性别" width="100" align="center" />
      <el-table-column prop="villager_phone" label="手机号" align="center" width="200" />
      <el-table-column prop="villager_ID_number" label="身份证号" align="center" width="250" />
      <el-table-column prop="villager_address" label="住址" width="250" align="center" />
      <el-table-column prop="villager_birthday" label="出生日期" width="150" align="center" />
      <el-table-column prop="villager_marriage" label="婚姻情况" width="80" align="center" />
      <el-table-column prop="villager_picture" label="相片" width="180" align="center">
        <template slot-scope="{ row }">
          <!-- eslint-disable -->
          <img :src="`http://localhost:8000/${row.villager_picture}`" alt="" style="width: 100px; height: 100px; text-align: center" />
        </template>
      </el-table-column>
      <el-table-column prop="villager_email" label="邮箱" width="180" align="center" />

      <el-table-column label="操作" width="230" align="center" fixed="right">
        <template slot-scope="{ row }">
          <el-button type="warning" icon="el-icon-edit" size="mini" @click="updateVillager(row)">修改</el-button>
          <el-button type="danger" icon="el-icon-delete" size="mini" @click="removeVillager(row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页器 -->
    <el-pagination style="margin-top: 20px; text-align: center" :current-page="page" :page-sizes="[3, 5, 10]" :page-count="7" :page-size.sync="limit" layout="prev, pager, next, jumper, ->, sizes, total" :total="total" @current-change="handleCurrentChange" @size-change="handleSizeChange" />

    <!-- 对话框的结构 -->
    <el-dialog :title="villager.id ? '修改村民信息' : '添加村民信息'" :visible.sync="dialogVisible" :before-close="dialogBeforeClose">
      <el-form inline ref="villager" :model="villager" :rules="villagerRules" label-width="120px">
        <el-form-item label="姓名" prop="villager_name">
          <el-input v-model="villager.villager_name" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="年龄" prop="villager_age">
          <el-input v-model="villager.villager_age"></el-input>
        </el-form-item>
        <el-form-item label="性别" prop="villager_sex">
          <el-select v-model="villager.villager_sex" placeholder="请选择">
            <el-option v-for="item in dict_sex" id="option_sex" :key="item.id" :label="item.sex" :value="item.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="手机号" prop="villager_phone">
          <el-input v-model="villager.villager_phone"></el-input>
        </el-form-item>
        <el-form-item label="身份证号" prop="villager_ID_number">
          <el-input v-model="villager.villager_ID_number" @blur="villager.id === undefined && villager.villager_ID_number.length === 18 ? add_villager_birthday() : null"></el-input>
        </el-form-item>
        <el-form-item label="住址" prop="villager_address">
          <el-input v-model="villager.villager_address"></el-input>
        </el-form-item>
        <el-form-item label="出生日期" prop="villager_birthday">
          <el-input v-model="villager.villager_birthday"></el-input>
        </el-form-item>
        <el-form-item label="婚姻情况" prop="villager_marriage">
          <el-select v-model="villager.villager_marriage" placeholder="请选择">
            <el-option v-for="item in dict_villager_marriage" :key="item.id" :label="item.villager_marriage" :value="item.is"> </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="邮箱" prop="villager_email">
          <el-input v-model="villager.villager_email"></el-input>
        </el-form-item>
        <el-form-item label="相片" prop="villager_picture">
          <el-upload class="avatar-uploader" action="/dev-api/villagers/upload" :show-file-list="false" :on-success="handleAvatarSuccess" :before-upload="beforeAvatarUpload">
            <!-- eslint-disable -->
            <i v-if="villager.villager_picture === ''" class="el-icon-plus avatar-uploader-icon" />
            <!-- <img v-else-if="villager.villager_picture === null ? true : false" src="http://localhost:8000/1b84679d1b1c4b1879ce89200.gif" class="avatar" /> -->

            <img v-else :src="'http://localhost:8000/' + villager.villager_picture" class="avatar" />
            <div slot="tip" class="el-upload__tip">只能上传png/jpg/jpeg/gif文件，且不超过5MB</div>
          </el-upload>
        </el-form-item>
        <div class="footer">
          <el-form-item class="footer-button">
            <el-button type="primary" @click="submitForm('villager')">提交</el-button>
            <el-button @click="villager.id ? resetForm('villager') : resetData('villager')">重置</el-button>
          </el-form-item>
        </div>
      </el-form>
    </el-dialog>
  </div>
</template>

<script>
import Cookies from 'js-cookie'
export default {
  name: 'Villager',
  data() {
    return {
      listLoading: false, // 是否显示列表加载的提示
      page: 1, // 当前页码
      limit: 3, // 每页数量
      total: 0, // 总数量
      list: [], // 村民信息列表
      pageList: [], // 每页村民列表
      selectedIds: [], // 所有选择的villager的id数组
      villager: {
        // 当前要操作的村民个人信息
        villager_name: '',
        villager_age: '',
        villager_sex: '',
        villager_phone: '',
        villager_ID_number: '',
        villager_address: '',
        villager_birthday: '',
        villager_marriage: '',
        villager_picture: '',
        villager_email: ''
      },
      dialogVisible: false, // 是否显示用户添加/修改的dialog
      villagerRules: {
        // 用户添加/修改表单的校验规则
        villager_name: [{ required: true, message: '请输入姓名', trigger: 'blur' }],
        villager_age: [{ required: true, message: '请输入年龄', trigger: 'blur' }],
        villager_sex: [{ required: true, message: '请输入性别', trigger: 'blur' }],
        villager_phone: [
          { required: true, message: '请输入手机号', trigger: 'blur' },
          { validator: this.validatorPhone, trigger: 'blur' }
        ],
        villager_ID_number: [
          { required: true, message: '请输入身份证号', trigger: 'blur' },
          { validator: this.validatorIDNumber, trigger: 'blur' }
        ],
        villager_address: [{ required: true, message: '请输入住址', trigger: 'blur' }],
        villager_birthday: [{ required: true, message: '请输入出生日期', trigger: 'blur' }],
        villager_marriage: [{ required: true, message: '请输入婚姻情况', trigger: 'blur' }],
        villager_email: [
          { required: false, message: '请输入邮箱', trigger: 'blur' },
          { validator: this.validatorEmail, trigger: 'blur' }
        ],
        villager_picture: [{ required: false, message: '请上传相片', trigger: 'blur' }]
      },
      loading: false, // 是否正在提交请求中
      searchObj: {
        // 包含请求搜索条件数据的对象
        villager_name: '',
        villager_ID_number: '',
        villager_phone: ''
      },
      tempSearchObj: {
        // 收集搜索条件输入的对象
        villager_name: '',
        villager_ID_number: '',
        villager_phone: ''
      },
      // 性别字典
      dict_sex: [
        { id: 1, sex: '男' },
        { id: 2, sex: '女' }
      ],
      // 是否已婚字典
      dict_villager_marriage: [
        { id: 1, is: false, villager_marriage: '否' },
        { id: 2, is: true, villager_marriage: '是' }
      ]
    }
  },
  mounted() {
    this.getPageList()
  },
  methods: {
    // 获取分页列表信息
    async getPageList(pager = 1) {
      this.page = pager
      const { page, limit } = this
      this.listLoading = true
      const res = await this.$API.villager.getVillagerInfo(page, limit)
      console.log('all', res)
      this.listLoading = false
      if (res.code === 0) {
        res.result.list.forEach(item => {
          item.villager_marriage = item.villager_marriage === true ? '是' : '否'
          item.villager_sex = item.villager_sex == 1 ? '男' : '女'
        })
        res.result.pageList.forEach(item => {
          item.villager_marriage = item.villager_marriage === true ? '是' : '否'
          item.villager_sex = item.villager_sex == 1 ? '男' : '女'
        })
        this.list = res.result.list
        this.total = res.result.total
        this.pageList = res.result.pageList
        // console.log('this.pageList', this.pageList)
      } else {
        return Promise.reject(new Error('faile'))
      }
    },
    // 获取单条村民信息
    // async getOneVillager(searchObj) {
    //   this.listLoading = true
    //   const res = await this.$API.villager.getOneVillagerInfo(searchObj)
    //   console.log('one', res)
    //   this.listLoading = false
    //   if (res.code === 0) {
    //     res.result.villager_marriage = res.result.villager_marriage === 1 ? '是' : '否'
    //     this.list = [res.result]
    //   } else {
    //     return Promise.reject(new Error('faile'))
    //   }
    // },
    // 获取某条村民信息
    async getMoreVillager(searchObj, page = 1, limit = 3) {
      this.page = page
      this.limit = limit
      this.listLoading = true
      const res = await this.$API.villager.getMoreVillagerInfo(searchObj, this.page, this.limit)
      console.log('more', res)
      this.listLoading = false
      if (res.code === 0) {
        res.result.list.forEach(item => {
          item.villager_marriage = item.villager_marriage === true ? '是' : '否'
          item.villager_sex = item.villager_sex == 1 ? '男' : '女'
        })
        res.result.pageList.forEach(item => {
          item.villager_marriage = item.villager_marriage === true ? '是' : '否'
          item.villager_sex = item.villager_sex == 1 ? '男' : '女'
        })
        this.pageList = res.result.pageList
        this.list = res.result.list
        this.total = res.result.total
      } else {
        return Promise.reject(new Error('faile'))
      }
    },
    // 根据输入进行搜索
    search() {
      this.searchObj = { ...this.tempSearchObj }
      // console.log(this.searchObj)
      this.getMoreVillager(this.searchObj, this.page, this.limit)
    },
    // 重置输入后搜索
    resetSearch() {
      this.searchObj = {
        villager_name: '',
        villager_ID_number: '',
        villager_phone: ''
      }
      this.tempSearchObj = {
        villager_name: '',
        villager_ID_number: '',
        villager_phone: ''
      }
      this.getPageList()
    },
    // 显示添加村民信息的界面
    showAddVillager() {
      this.villager = {
        // 当前要操作的村民个人信息
        villager_name: '',
        villager_age: '',
        villager_sex: '',
        villager_phone: '',
        villager_ID_number: '',
        villager_address: '',
        villager_birthday: '',
        villager_marriage: '',
        villager_picture: '',
        villager_email: ''
      }
      this.dialogVisible = true

      this.$nextTick(() => this.$refs.villager.clearValidate())
    },
    // 自定义手机号校验
    validatorPhone(rule, value, callback) {
      const phone = value.replace(/\s/g, '') // 去除空格
      const regs = /^((13[0-9])|(17[0-1,6-8])|(15[^4,\\D])|(18[0-9]))\d{8}$/
      if (!value) {
        callback('请输入手机号')
      } else if (value.length !== 0) {
        if (!regs.test(phone)) {
          callback([new Error('手机号输入不合法')])
        } else {
          callback()
        }
      } else {
        callback()
      }
    },
    // 自定义邮箱校验
    validatorEmail(rule, value, callback) {
      console.log(value)

      const regs = /^\w+@[a-z0-9]+\.[a-z]{2,4}$/
      if (value.length !== 0) {
        const email = value.replace(/\s/g, '') // 去除空格
        if (!regs.test(email)) {
          callback([new Error('邮箱输入不合法')])
        } else {
          callback()
        }
      } else {
        callback()
      }
    },
    // 自定义身份证号校验
    validatorIDNumber(rule, value, callback) {
      // 4 40923 2000 01 23 685 4
      const IDNumber = value.replace(/\s/g, '') // 去除空格
      const regs = /^[1-9]\d{5}(18|19|20)\d{2}((0[1-9])|(1[0-2]))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/
      if (!value) {
        callback('请输入身份证号')
      } else if (value.length !== 0) {
        if (!regs.test(IDNumber)) {
          callback([new Error('身份证号输入不合法')])
        } else {
          callback()
        }
      } else {
        callback()
      }
    },

    // 从身份证号码中获取出生日期
    add_villager_birthday() {
      console.log(this.villager.villager_ID_number)
      let birthStr = this.villager.villager_ID_number.slice(6, 14)
      let birthStr1 = birthStr.slice(0, 4)
      let birthStr2 = birthStr.slice(4, 6)
      let birthStr3 = birthStr.slice(6, 8)
      let birthday = `${birthStr1}-${birthStr2}-${birthStr3}`
      this.villager.villager_birthday = birthday
    },
    // 头像上传之前的函数处理
    beforeAvatarUpload(file) {
      const fileTypes = ['image/png', 'image/jpg', 'image/jpeg', 'image/gif']
      if (!fileTypes.includes(file.type)) {
        this.$message.error('上传头像图片仅支持png、jpg、jpeg、gif 格式！')
      }
      if (!(file.size / 1024 / 1024 < 5)) {
        this.$message.error('上传头像图片大小不能超过 5MB！')
      }
      const token = Cookies.get('vue_admin_template_token')
      console.log(token)
      return file.type && file.size / 1024 / 1024 < 5
    },
    // 头像上传成功后的函数处理
    async handleAvatarSuccess(res, file) {
      this.villager.villager_picture = res.result.villager_picture
      // this.$router.replace({
      //   path: '/personalcenter/blankpage',
      //   name: 'BlankPage'
      // })
      // this.$router.go(0)
    },
    // 添加或更新村民信息
    submitForm(formName) {
      console.log(formName)
      console.log(this.$refs[formName])
      this.$refs[formName].validate(async valid => {
        console.log(valid)
        if (valid) {
          // this.villager.villager_marriage = this.villager.villager_marriage !== '否'
          this.villager.villager_age = this.villager.villager_age - 0
          console.log(this.villager)
          if (this.villager.villager_picture === '' && this.villager.villager_email !== '') {
            /* eslint-disable */
            const { villager_picture, ...cache } = this.villager
            this.villager = cache
          } else if (this.villager.villager_email === '' && this.villager.villager_picture !== '') {
            const { villager_email, ...cache } = this.villager
            // console.log(cache)
            this.villager = cache
            this.villager.villager_email = ''
          } else if (this.villager.villager_email === null && this.villager.villager_picture !== '') {
            const { villager_email, ...cache } = this.villager
            // console.log(cache)
            this.villager = cache
          } else if (this.villager.villager_email !== '' && this.villager.villager_picture === null) {
            const { villager_picture, ...cache } = this.villager
            // console.log(cache)
            this.villager = cache
          } else if (this.villager.villager_email === null && this.villager.villager_picture === null) {
            const { villager_picture, villager_email, ...cache } = this.villager
            // console.log(cache)
            this.villager = cache
          } else if (this.villager.villager_email === '' && this.villager.villager_picture === '') {
            const { villager_picture, villager_email, ...cache } = this.villager
            // console.log(cache)
            this.villager = cache
          } else {
            this.villager = this.villager
          }
          console.log(this.villager)
          this.villager.villager_sex = this.villager.villager_sex + ''

          const res = await this.$API.villager.addOrUpdateVillager(this.villager)
          if (res.code === 0) {
            this.$message({
              type: 'success',
              message: this.villager.id ? '修改村民信息成功' : '添加村民信息成功'
            })
            this.villager = {
              // 当前要操作的村民个人信息
              villager_name: '',
              villager_age: '',
              villager_sex: '',
              villager_phone: '',
              villager_ID_number: '',
              villager_address: '',
              villager_birthday: '',
              villager_marriage: '',
              villager_picture: '',
              villager_email: ''
            }
            this.getPageList(this.villager.id ? this.page : 1)
            this.dialogVisible = false
          }
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    // 重置提交之前的数据
    resetData(formName) {
      this.villager = {
        // 当前要操作的村民个人信息
        villager_name: '',
        villager_age: '',
        villager_sex: '',
        villager_phone: '',
        villager_ID_number: '',
        villager_address: '',
        villager_birthday: '',
        villager_marriage: '',
        villager_picture: '',
        villager_email: ''
      }
      this.$refs[formName].clearValidate()
    },
    // 重置修改之前的数据
    resetForm(formName) {
      this.$refs[formName].resetFields()
    },
    handleSizeChange(limit) {
      console.log(limit)
      this.searchObj = { ...this.tempSearchObj }
      this.limit = limit
      let el_input_name = this.$refs.el_input_name.$vnode.data.model.value
      let el_input_ID_number = this.$refs.el_input_ID_number.$vnode.data.model.value
      let el_input_phone = this.$refs.el_input_phone.$vnode.data.model.value
      if (el_input_name || el_input_ID_number || el_input_phone) {
        this.getMoreVillager(this.searchObj, this.page, this.limit)
      } else {
        this.getPageList()
      }
    },
    handleCurrentChange(page) {
      console.log(page)
      this.searchObj = { ...this.tempSearchObj }
      let el_input_name = this.$refs.el_input_name.$vnode.data.model.value
      let el_input_ID_number = this.$refs.el_input_ID_number.$vnode.data.model.value
      let el_input_phone = this.$refs.el_input_phone.$vnode.data.model.value
      if (el_input_name || el_input_ID_number || el_input_phone) {
        this.getMoreVillager(this.searchObj, page, this.limit)
      } else {
        this.getPageList(page)
      }
    },
    // 更新村民信息
    updateVillager(row) {
      // console.log(row)
      this.dialogVisible = true
      const { createdAt, updatedAt, villager_status, ...data } = row
      data.villager_marriage = data.villager_marriage == '是' ? true : false
      this.villager = data
    },
    // 删除村民信息
    removeVillager(row) {
      this.$confirm(`你确定删除${row.villager_name}的信息？`, '提示', {
        confirmButtonClass: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(async () => {
          const res = await this.$API.villager.removeVillager(row.id)
          if (res.code === 0) {
            this.$message({
              type: 'success',
              message: '删除成功'
            })
            // 再次获取村民信息
            this.getPageList(this.list.length > 1 ? this.page : this.page - 1)
          }
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
    },
    // 批量删除
    batchRemove() {
      this.$confirm('确定删除吗？')
        .then(async () => {
          await this.$API.villager.batchRemoveVillager(this.selectedIds)
          this.$message.success('删除成功')
          this.getPageList()
        })
        .catch(() => {
          this.$message.info('取消删除')
        })
    },
    handleSelectionChange(selection) {
      this.selectedIds = selection.map(item => item.id)
    },
    // 关闭弹窗之前的处理函数
    dialogBeforeClose(done) {
      this.$confirm('确认关闭？')
        .then(_ => {
          done()
          this.villager = {
            // 当前要操作的村民个人信息
            villager_name: '',
            villager_age: '',
            villager_sex: '',
            villager_phone: '',
            villager_ID_number: '',
            villager_address: '',
            villager_birthday: '',
            villager_marriage: '',
            villager_picture: '',
            villager_email: ''
          }
          this.$refs['villager'].clearValidate()
        })
        .catch(_ => {
          console.log(_)
        })
    }
  }
}
</script>

<style scoped>
.container {
  padding: 0px 20px;
}

>>> .avatar-uploader .el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
.avatar-uploader .el-upload:hover {
  border-color: #409eff;
}
.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 178px;
  height: 178px;
  line-height: 178px;
  text-align: center;
}
.avatar {
  width: 178px;
  height: 178px;
  display: block;
}

.footer {
  display: flex;
}

.footer-button {
  margin-left: auto;
}
</style>
