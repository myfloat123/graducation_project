<template>
  <div class="container">
    <el-form inline style="margin-top: 20px">
      <!-- 表单元素 -->
      <el-form-item id="land_code">
        <el-input v-model="tempSearchObj.land_code" placeholder="土地流转合同编号" />
      </el-form-item>
      <el-form-item id="land_transfer_person">
        <el-input v-model="tempSearchObj.land_transfer_person" placeholder="流转人" />
      </el-form-item>
      <el-form-item id="land_receive_person">
        <el-input v-model="tempSearchObj.land_receive_person" placeholder="接收人" />
      </el-form-item>
      <el-form-item id="land_transfer_type">
        <el-select v-model="tempSearchObj.land_transfer_type" placeholder="流转类型">
          <el-option v-for="item in dict_land_transfer_type" :key="item.id" :label="item.land_transfer_type" :value="item.id" />
        </el-select>
      </el-form-item>
      <!-- 查询与清空按钮 -->
      <!--  -->
      <!--  -->
      <el-button type="primary" icon="el-icon-search" @click="search">查询</el-button>
      <el-button type="default" @click="resetSearch">清空</el-button>
    </el-form>

    <!-- 添加与批量删除按钮 -->
    <div style="margin-bottom: 20px">
      <el-button type="primary" @click="showAddLand">添加</el-button>
      <el-button type="danger" :disabled="selectedIds.length === 0" @click="batchRemove">批量删除</el-button>
    </div>

    <!-- table表格：展示土地流转信息 -->
    <!--  -->
    <el-table v-loading="listLoading" border stripe :data="pageList" style="width: 100%" @selection-change="handleSelectionChange">
      <el-table-column type="selection" />
      <el-table-column type="index" label="序号" align="center" />
      <el-table-column header-align="center" align="center" prop="land_code" label="土地流转合同编号" width="200" />
      <el-table-column header-align="center" align="center" prop="land_transfer_person" label="流转人" width="200" />
      <el-table-column header-align="center" align="center" prop="land_receive_person" label="接收人" width="200" />
      <el-table-column header-align="center" align="center" prop="land_sign_contract_date" label="签约日期" width="200" />
      <el-table-column header-align="center" align="center" prop="land_transfer_term" label="截止日期" width="200" />
      <el-table-column header-align="center" align="center" prop="land_transfer_type" label="流转类型" width="200">
        <template slot-scope="{ row }">
          <el-tag :type="land_transfer_type_tag(row)" disable-transitions>{{ row.land_transfer_type }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column header-align="center" align="center" prop="land_transfer_price" label="流转价格" width="200" />
      <el-table-column header-align="center" align="center" prop="land_use" label="用途" width="200">
        <!-- <template slot-scope="{ row }">
          <el-tag :type="hygiene_toilet_clean_situation_tag(row)" disable-transitions>{{ row.hygiene_toilet_clean_situation }}</el-tag>
        </template> -->
      </el-table-column>
      <el-table-column header-align="center" align="center" prop="prop" label="操作" width="300" fixed="right">
        <template slot-scope="{ row }">
          <el-button type="info" icon="el-icon-info" size="mini" @click="showLandDetail(row)">查看</el-button>
          <el-button type="warning" icon="el-icon-edit" size="mini" @click="showUpdateLand(row)">修改</el-button>
          <el-button type="danger" icon="el-icon-delete" size="mini" @click="removeLand(row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页器 -->
    <!--  -->
    <!--  -->
    <el-pagination style="margin-top: 20px; text-align: center" :current-page="page" :page-sizes="[3, 5, 10]" :page-count="7" :page-size.sync="limit" layout="prev, pager, next, jumper, ->, sizes, total" :total="total" @current-change="handleCurrentChange" @size-change="handleSizeChange" />

    <!-- 土地流转信息弹窗 -->
    <!--  -->
    <el-dialog :title="land.id ? `${disabled_land ? '查看' : '修改'}土地流转信息` : '添加土地流转信息'" :visible.sync="dialogVisible" :before-close="dialogBeforeClose">
      <el-form ref="LandForm" :model="land" :rules="landRules" inline>
        <el-form-item label="土地流转合同编号" prop="land_code">
          <el-input v-model="land.land_code" :disabled="disabled_land ? true : false" />
        </el-form-item>
        <el-form-item label="流转人" prop="land_transfer_person" label-width="130px">
          <el-input v-model="land.land_transfer_person" :disabled="disabled_land ? true : false" />
        </el-form-item>
        <el-form-item label="接收人" prop="land_receive_person" label-width="130px">
          <el-input v-model="land.land_receive_person" :disabled="disabled_land ? true : false" />
        </el-form-item>

        <el-form-item label="签约日期" prop="land_sign_contract_date" label-width="100px">
          <!-- <el-input v-model="land.land_sign_contract_date" :disabled="disabled_land ? true : false" /> -->
          <el-date-picker v-model="land.land_sign_contract_date" align="right" type="date" placeholder="选择日期" :picker-options="pickerOptions" :disabled="disabled_land ? true : false" />
        </el-form-item>
        <el-form-item label="截止日期" prop="land_transfer_term" label-width="130px">
          <!-- <el-input v-model="land.land_transfer_term" :disabled="disabled_land ? true : false" /> -->
          <el-date-picker v-model="land.land_transfer_term" align="right" type="date" placeholder="选择日期" :picker-options="pickerOptions" :disabled="disabled_land ? true : false" />
        </el-form-item>
        <el-form-item label="流转类型" prop="land_transfer_type" label-width="115px">
          <el-select v-model="land.land_transfer_type" placeholder="流转类型" :disabled="disabled_land ? true : false" style="width: 100px">
            <el-option v-for="item in dict_land_transfer_type" :key="item.id" :label="item.land_transfer_type" :value="item.id" />
          </el-select>
        </el-form-item>
        <div>
          <el-form-item label="流转价格" prop="land_transfer_price" label-width="100px">
            <el-input v-model="land.land_transfer_price" :disabled="disabled_land ? true : false" />
          </el-form-item>
          <el-form-item prop="land_unit">
            <el-select v-model="land.land_unit" placeholder="单位" :disabled="disabled_land ? true : false" style="width: 100px">
              <el-option v-for="item in dict_land_unit" :key="item.id" :label="item.land_unit" :value="item.id" />
            </el-select>
          </el-form-item>
        </div>
        <div>
          <el-form-item label="用途" prop="land_use" label-width="100px">
            <el-input v-model="land.land_use" :disabled="disabled_land ? true : false" type="textarea" :autosize="{ minRows: 5, maxRows: 10 }" :cols="100" />
          </el-form-item>
        </div>
      </el-form>
      <div v-show="!disabled_land" slot="footer">
        <el-button @click="cancel">取 消</el-button>
        <el-button type="primary" @click="land.id ? updateLand() : addLand()">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import dayjs from 'dayjs'
export default {
  name: 'Land',
  data() {
    return {
      // 当前页码
      page: 1,
      // 每页数量
      limit: 3,
      // 总数
      total: 0,
      // 是否显示列表加载的提示
      listLoading: false,
      // 选择的土地流转信息id数组
      selectedIds: [],
      // 每页土地流转信息列表
      pageList: [],
      // 土地流转信息列表
      list: [],
      // 是否显示弹窗
      dialogVisible: false,
      // 是否查信息看土地流转
      disabled_land: false,
      // 收集搜索条件输入的对象
      tempSearchObj: {
        land_code: '',
        land_transfer_person: '',
        land_receive_person: '',
        land_transfer_type: ''
      },
      // 包含请求搜索条件数据的对象
      searchObj: {
        land_code: '',
        land_transfer_person: '',
        land_receive_person: '',
        land_transfer_type: ''
      },
      // 当前操作的土地流转信息对象
      land: {
        land_code: '',
        land_transfer_person: '',
        land_receive_person: '',
        land_sign_contract_date: '',
        land_transfer_term: '',
        land_transfer_type: '',
        land_transfer_price: '',
        land_unit: '',
        land_use: ''
      },
      // 流转类型字典
      dict_land_transfer_type: [
        // { id: 0, hygiene_trash_can_clean_situation: '无' },
        { id: 1, land_transfer_type: '出租' },
        { id: 2, land_transfer_type: '转让' },
        { id: 3, land_transfer_type: '互换' }
      ],
      // 单位字典
      dict_land_unit: [
        // { id: 0, hygiene_toilet_clean_situation: '无' },
        { id: 1, land_unit: '万/亩' },
        { id: 2, land_unit: '万/公顷' },
        { id: 3, land_unit: '万/顷' }
      ],
      // 土地流转信息验证规则
      landRules: {
        land_code: [{ required: true, message: '请输入土地流转合同编号', trigger: 'blur' }],
        land_transfer_person: [{ required: true, message: '请输入流转人', trigger: 'blur' }],
        land_receive_person: [{ required: true, message: '请输入接收人', trigger: 'blur' }],
        land_sign_contract_date: [{ required: true, message: '请填写签约日期', trigger: 'blur' }],
        land_transfer_term: [{ required: true, message: '请填写截止日期', trigger: 'blur' }],
        land_transfer_type: [{ required: true, message: '请选择流转类型', trigger: 'blur' }],
        land_transfer_price: [{ required: true, message: '请输入流转价格', trigger: 'blur' }],
        land_unit: [{ required: true, message: '请选择单位', trigger: 'blur' }],
        land_use: [{ required: false, message: '请输入用途', trigger: 'blur' }]
      },
      // 日期选择快捷选项
      pickerOptions: {
        // disabledDate(time) {
        //   return time.getTime() > Date.now()
        // },
        shortcuts: [
          {
            text: '今天',
            onClick(picker) {
              picker.$emit('pick', new Date())
            }
          },
          {
            text: '昨天',
            onClick(picker) {
              const date = new Date()
              date.setTime(date.getTime() - 3600 * 1000 * 24)
              picker.$emit('pick', date)
            }
          },
          {
            text: '一周前',
            onClick(picker) {
              const date = new Date()
              date.setTime(date.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', date)
            }
          }
        ]
      }
    }
  },
  mounted() {
    this.getLandData()
  },
  methods: {
    // 获取土地流转信息
    async getLandData(page = 1, limit = 3, searchObj = { land_code: '', land_transfer_person: '', land_receive_person: '', land_transfer_type: '' }) {
      this.page = page
      this.limit = limit
      this.searchObj = searchObj
      this.listLoading = true
      let params = { page, limit, ...searchObj }
      const res = await this.$API.land.getLandInfo(params)
      this.listLoading = false
      console.log(res)

      if (res.code === 0) {
        res.result.pageList.forEach(land => {
          land.createdAt = dayjs(land.createdAt).format('YYYY-MM-DD HH:mm:ss')
          land.updatedAt = dayjs(land.updatedAt).format('YYYY-MM-DD HH:mm:ss')
          land.land_sign_contract_date = dayjs(land.land_sign_contract_date).format('YYYY-MM-DD')
          land.land_transfer_term = dayjs(land.land_transfer_term).format('YYYY-MM-DD')
          this.dict_land_transfer_type.forEach(item => {
            if (item.id === land.land_transfer_type) {
              land.land_transfer_type = item.land_transfer_type
            }
          })
          this.dict_land_unit.forEach(item => {
            if (item.id === land.land_unit) {
              land.land_unit = item.land_unit
            }
          })
        })
        res.result.list.forEach(land => {
          land.createdAt = dayjs(land.createdAt).format('YYYY-MM-DD HH:mm:ss')
          land.updatedAt = dayjs(land.updatedAt).format('YYYY-MM-DD HH:mm:ss')
          this.dict_land_transfer_type.forEach(item => {
            if (item.id === land.land_transfer_type) {
              land.land_transfer_type = item.land_transfer_type
            }
          })
          this.dict_land_unit.forEach(item => {
            if (item.id === land.land_unit) {
              land.land_unit = item.land_unit
            }
          })
        })
        this.pageList = res.result.pageList
        this.list = res.result.list
        this.total = res.result.total
      }
    },
    // 流转类型tag
    land_transfer_type_tag(land) {
      if (land.land_transfer_type === '出租' || land.land_transfer_type == 1) {
        return ''
      } else if (land.land_transfer_type === '转让' || land.land_transfer_type == 2) {
        return 'warning'
      } else {
        return 'success'
      }
    },
    // 查看土地流转信息详情
    showLandDetail(land) {
      this.dialogVisible = true
      this.disabled_land = true
      this.land = { ...land }
    },
    // 弹窗关闭前的处理函数
    dialogBeforeClose(done) {
      this.$confirm('确认关闭？')
        .then(_ => {
          done()
          this.land = {
            land_code: '',
            land_transfer_person: '',
            land_receive_person: '',
            land_sign_contract_date: '',
            land_transfer_term: '',
            land_transfer_type: '',
            land_transfer_price: '',
            land_unit: '',
            land_use: ''
          }
          this.disabled_land = false
          this.$refs['LandForm'].clearValidate()
        })
        .catch(_ => {
          console.log(_)
        })
    },
    // 取消
    cancel() {
      this.land = {
        land_code: '',
        land_transfer_person: '',
        land_receive_person: '',
        land_sign_contract_date: '',
        land_transfer_term: '',
        land_transfer_type: '',
        land_transfer_price: '',
        land_unit: '',
        land_use: ''
      }
      this.dialogVisible = false
      this.disabled_land = false
      this.$refs['LandForm'].clearValidate()
    },
    // 显示修改土地流转信息弹窗
    showUpdateLand(land) {
      this.dialogVisible = true
      this.land = { ...land }
    },
    // 更新土地流转信息
    async updateLand() {
      let id = this.land.id
      let data = {
        land_code: this.land.land_code,
        land_transfer_person: this.land.land_transfer_person,
        land_receive_person: this.land.land_receive_person,
        land_sign_contract_date: this.land.land_sign_contract_date,
        land_transfer_term: this.land.land_transfer_term,
        land_transfer_type: this.land.land_transfer_type,
        land_transfer_price: this.land.land_transfer_price,
        land_unit: this.land.land_unit,
        land_use: this.land.land_use
      }
      data.land_sign_contract_date = dayjs(data.land_sign_contract_date).format('YYYY-MM-DD')
      data.land_transfer_term = dayjs(data.land_transfer_term).format('YYYY-MM-DD')

      if (typeof data.land_transfer_type === 'string') {
        this.dict_land_transfer_type.forEach(item => {
          if (item.land_transfer_type === data.land_transfer_type) {
            data.land_transfer_type = item.id
          }
        })
      }
      if (typeof data.land_unit === 'string') {
        this.dict_land_unit.forEach(item => {
          if (item.land_unit === data.land_unit) {
            data.land_unit = item.id
          }
        })
      }

      // data.land_use === '' && Object.assign(data, { land_use: null })

      const res = await this.$API.land.updateLandInfo(id, data)
      if (res.code === 0) {
        this.$message({
          type: 'success',
          message: '更新成功'
        })
        this.land = {
          land_code: '',
          land_transfer_person: '',
          land_receive_person: '',
          land_sign_contract_date: '',
          land_transfer_term: '',
          land_transfer_type: '',
          land_transfer_price: '',
          land_unit: '',
          land_use: ''
        }
        this.getLandData(this.page)
        this.dialogVisible = false
      }
    },
    // 显示添加土地流转信息弹窗
    showAddLand() {
      this.dialogVisible = true
      this.land.land_code = 'TDLZ' + `${+new Date()}`.slice(-4) || ''
    },
    // 新增土地流转信息
    addLand() {
      this.$refs['LandForm'].validate(async valid => {
        if (valid) {
          this.land.land_sign_contract_date = dayjs(this.land.land_sign_contract_date).format('YYYY-MM-DD')
          this.land.land_transfer_term = dayjs(this.land.land_transfer_term).format('YYYY-MM-DD')
          const res = await this.$API.land.addLandInfo(this.land)
          if (res.code === 0) {
            this.$message({
              type: 'success',
              message: '新增土地流转信息成功'
            })
            // this.total = this.total + 1
            this.dialogVisible = false
            // this.getFinanceData((this.page = Math.ceil(this.total / this.limit)), this.limit, this.searchObj)
            this.getLandData(this.page, this.limit, this.searchObj)
            this.land = {
              land_code: '',
              land_transfer_person: '',
              land_receive_person: '',
              land_sign_contract_date: '',
              land_transfer_term: '',
              land_transfer_type: '',
              land_transfer_price: '',
              land_unit: '',
              land_use: ''
            }
          } else {
            console.log('error submit!!')
            return false
          }
        }
        this.dialogVisible = false
      })
    },
    // 处理当前页变化
    handleCurrentChange(page) {
      this.page = page
      this.getLandData(this.page, this.limit, this.searchObj)
    },
    // 处理每页显示数目变化
    handleSizeChange(limit) {
      this.limit = limit
      this.getLandData(this.page, this.limit, this.searchObj)
    },
    // 查询
    search() {
      this.searchObj = { ...this.tempSearchObj }
      this.getLandData(this.page, this.limit, this.searchObj)
    },
    // 清空
    resetSearch() {
      this.searchObj = {
        land_code: '',
        land_transfer_person: '',
        land_receive_person: '',
        land_transfer_type: ''
      }
      this.tempSearchObj = {
        land_code: '',
        land_transfer_person: '',
        land_receive_person: '',
        land_transfer_type: ''
      }
      this.getLandData()
    },
    // 删除土地流转信息
    removeLand(land) {
      this.$confirm(`确定删除${land.land_code}的信息？`, '提示', {
        confirmButtonClass: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(async () => {
          const res = await this.$API.land.removeLandInfo(land.id)
          if (res.code === 0) {
            this.$message({
              type: 'success',
              message: '删除成功'
            })
            this.getLandData(this.pageList.length > 1 ? this.page : (this.page = this.page - 1), this.limit, this.searchObj)
          }
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
    },
    // 选中的数据
    handleSelectionChange(selection) {
      this.selectedIds = selection.map(item => item.id)
    },
    // 批量删除土地流转信息
    batchRemove() {
      this.$confirm('确定删除吗？')
        .then(async () => {
          const res = await this.$API.land.batchremoveLandInfo(this.selectedIds)
          if (res.code === 0) {
            this.$message.success('删除成功')
            this.getLandData(this.page, this.limit, this.searchObj)
          }
        })
        .catch(err => {
          console.log(err)
          this.$message.info('取消删除')
        })
    }
  }
}
</script>

<style scoped>
.container {
  padding: 0px 20px;
}

.el-form--inline .el-form-item {
  margin-right: 0px;
}

#land_code,
#land_transfer_person,
#land_receive_person,
#land_transfer_type {
  margin-right: 10px;
}

>>> .el-textarea.is-disabled .el-textarea__inner {
  background-color: #fff;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  color: #606266;
}

>>> .el-input.is-disabled .el-input__inner {
  background-color: #fff;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  color: #606266;
}
</style>
