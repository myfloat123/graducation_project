<template>
  <div>收支情况</div>
</template>

<script>
export default {
  name: 'IncomeAndExpenses'
}
</script>

<style scoped></style>
