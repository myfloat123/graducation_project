import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

/* Layout */
import Layout from '@/layout'

/**
 * Note: sub-menu only appear when route children.length >= 1
 * Detail see: https://panjiachen.github.io/vue-element-admin-site/guide/essentials/router-and-nav.html
 *
 * hidden: true                   if set true, item will not show in the sidebar(default is false)
 * alwaysShow: true               if set true, will always show the root menu
 *                                if not set alwaysShow, when item has more than one children route,
 *                                it will becomes nested mode, otherwise not show the root menu
 * redirect: noRedirect           if set noRedirect will no redirect in the breadcrumb
 * name:'router-name'             the name is used by <keep-alive> (must set!!!)
 * meta : {
    roles: ['admin','editor']    control the page roles (you can set multiple roles)
    title: 'title'               the name show in sidebar and breadcrumb (recommend set)
    icon: 'svg-name'/'el-icon-x' the icon show in the sidebar
    breadcrumb: false            if set false, the item will hidden in breadcrumb(default is true)
    activeMenu: '/example/list'  if set path, the sidebar will highlight the path you set
  }
 */

/**
 * constantRoutes
 * a base page that does not have permission requirements
 * all roles can be accessed
 */
/*
{
    path: '/article/:id',
    component: () => import('@/views/dashboard/article'),
    meta: { show: true },
    name: 'article',
    props: ($route) => ({ id: $route.params.id })
  },
*/
export const constantRoutes = [

  {
    path: '/login',
    component: () => import('@/views/login/index'),
    hidden: true,
    name: 'login'
  },
  {
    path: '/register',
    component: () => import('@/views/register/index'),
    hidden: false,
    name: 'register'
  },

  {
    path: '/404',
    component: () => import('@/views/404'),
    hidden: true
  },

  { path: '*', redirect: '/404', hidden: true },

  {
    path: '/',
    component: Layout,
    redirect: '/dashboard',
    meta: { title: 'Home', icon: 'el-icon-house' },
    children: [
      {
        path: 'dashboard',
        name: 'Dashboard',
        component: () => import('@/views/dashboard/index'),
        meta: { title: 'Dashboard', icon: 'dashboard' }

      }
    ]
  },
  // {
  //   name: 'Acl',
  //   path: '/acl',
  //   component: Layout,
  //   redirect: '/acl/user/list',
  //   meta: {
  //     title: '权限管理',
  //     icon: 'el-icon-lock'
  //   },
  //   children: [
  //     {
  //       name: 'User',
  //       path: 'user/list',
  //       component: () => import('@/views/acl/user/list'),
  //       meta: {
  //         title: '用户管理'
  //       }
  //     },
  //     {
  //       name: 'Role',
  //       path: 'role/list',
  //       component: () => import('@/views/acl/role/list'),
  //       meta: {
  //         title: '角色管理'
  //       }
  //     },
  //     {
  //       name: 'RoleAuth',
  //       path: 'role/auth/:id',
  //       component: () => import('@/views/acl/role/roleAuth'),
  //       meta: {
  //         activeMenu: '/acl/role/list',
  //         title: '角色授权'
  //       },
  //       hidden: true
  //     },
  //     {
  //       name: 'Permission',
  //       path: 'permission/list',
  //       component: () => import('@/views/acl/permission/list'),
  //       meta: {
  //         title: '菜单管理'
  //       }
  //     }
  //   ]
  // },

  {
    path: '/personalcenter',
    component: Layout,
    name: 'PersonalCenter',
    meta: { title: '个人中心', icon: 'el-icon-user' },
    children: [
      {
        path: 'personalinformation',
        name: 'PersonalInformation',
        component: () => import('@/views/personalCenter/personalInformation'),
        meta: { title: '个人信息' }
      },
      {
        path: 'blankpage',
        name: 'BlankPage',
        component: () => import('@/views/personalCenter/blankPage')
      },
      {
        path: 'updatepassword',
        name: 'UpdatePassword',
        component: () => import('@/views/personalCenter/updatePassword'),
        meta: { title: '修改密码' }
      }
    ]
  }
  // {
  //   path: '/villagerinformation',
  //   component: Layout,
  //   name: 'VillagerInformation',
  //   meta: { title: '村民信息管理', icon: 'el-icon-house' },
  //   children: [
  //     {
  //       path: 'villager',
  //       name: 'Villager',
  //       component: () => import('@/views/villagerInformation/villager'),
  //       meta: { title: '村民个人信息' }
  //     },
  //     {
  //       path: 'birth',
  //       name: 'Birth',
  //       component: () => import('@/views/villagerInformation/birth'),
  //       meta: { title: '人口出生信息' }
  //     },
  //     {
  //       path: 'death',
  //       name: 'Death',
  //       component: () => import('@/views/villagerInformation/death'),
  //       meta: { title: '人口死亡信息' }
  //     }
  //   ]
  // },
  // {
  //   path: '/filing',
  //   component: Layout,
  //   name: 'Filing',
  //   meta: { title: '每户建档管理', icon: 'el-icon-s-management' },
  //   children: [
  //     {
  //       path: 'familyfiles',
  //       name: 'FamilyFiles',
  //       component: () => import('@/views/filing/familyFiles'),
  //       meta: { title: '家庭档案信息' }
  //     },
  //     {
  //       path: 'helpInformation',
  //       name: 'HelpInformation',
  //       component: () => import('@/views/filing/helpInformation'),
  //       meta: { title: '帮扶信息' }
  //     }
  //   ]
  // },
  // {
  //   path: '/assetinformation',
  //   component: Layout,
  //   name: 'AssetInformation',
  //   meta: { title: '资产管理', icon: 'el-icon-menu' },
  //   children: [
  //     {
  //       path: 'infrastructure',
  //       name: 'Infrastructure',
  //       component: () => import('@/views/assetInformation/infrastructure'),
  //       meta: { title: '基础设施管理' }
  //     },
  //     {
  //       path: 'resource',
  //       name: 'Resource',
  //       component: () => import('@/views//assetInformation/resource'),
  //       meta: { title: '自然资源管理' }
  //     }
  //   ]
  // },
  // {
  //   path: '/villageaffairs',
  //   component: Layout,
  //   name: 'VillageAffairs',
  //   meta: { title: '村务信息管理', icon: 'el-icon-s-grid' },
  //   children: [
  //     {
  //       path: 'house',
  //       name: 'House',
  //       component: () => import('@/views/villageAffairs/house'),
  //       meta: { title: '房屋建筑' }
  //     },
  //     {
  //       path: 'assanation',
  //       name: 'Assanation',
  //       component: () => import('@/views/villageAffairs/assanation'),
  //       meta: { title: '环境卫生' }
  //     },
  //     {
  //       path: 'land',
  //       name: 'Land',
  //       component: () => import('@/views/villageAffairs/land'),
  //       meta: { title: '土地流转' }
  //     }
  //   ]
  // },
  // {
  //   path: '/poor',
  //   component: Layout,
  //   name: 'Poor',
  //   meta: { title: '贫困户信息管理', icon: 'el-icon-s-home' },
  //   children: [
  //     {
  //       path: 'lowIncomeFamily',
  //       name: 'LowincomeFamily',
  //       component: () => import('@/views/poor/lowIncomeFamily'),
  //       meta: { title: '贫困家庭' }
  //     },
  //     {
  //       path: 'povertyAlleviationFamily',
  //       name: 'PovertyAlleviationFamily',
  //       component: () => import('@/views/poor/povertyAlleviationFamily'),
  //       meta: { title: '脱贫家庭' }
  //     }
  //   ]
  // },
  // {
  //   path: '/dailybusiness',
  //   component: Layout,
  //   name: 'DailyBusiness',
  //   meta: { title: '日常经营信息', icon: 'el-icon-money' },
  //   children: [
  //     {
  //       path: 'income',
  //       name: 'Income',
  //       component: () => import('@/views/dailyBusiness/income'),
  //       meta: { title: '收入信息' }
  //     },
  //     {
  //       path: 'pay',
  //       name: 'Pay',
  //       component: () => import('@/views/dailyBusiness/pay'),
  //       meta: { title: '支出信息' }
  //     }
  //   ]
  // },
  // {
  //   path: '/finance',
  //   component: Layout,
  //   name: 'Finance',
  //   meta: { title: '村务财务状况管理', icon: 'el-icon-coin' },
  //   children: [
  //     {
  //       path: 'information',
  //       name: 'Information',
  //       component: () => import('@/views/finance/information'),
  //       meta: { title: '财务信息' }
  //     },
  //     {
  //       path: 'incomeandexpenses',
  //       name: 'IncomeAndExpenses',
  //       component: () => import('@/views/finance/incomeAndExpenses'),
  //       meta: { title: '收支情况' }
  //     }
  //   ]
  // }

  // {
  //   path: '/example',
  //   component: Layout,
  //   redirect: '/example/table',
  //   name: 'Example',
  //   meta: { title: 'Example', icon: 'el-icon-s-help' },
  //   children: [
  //     {
  //       path: 'table',
  //       name: 'Table',
  //       component: () => import('@/views/table/index'),
  //       meta: { title: 'Table', icon: 'table' }
  //     },
  //     {
  //       path: 'tree',
  //       name: 'Tree',
  //       component: () => import('@/views/tree/index'),
  //       meta: { title: 'Tree', icon: 'tree' }
  //     }
  //   ]
  // },

  // {
  //   path: '/form',
  //   component: Layout,
  //   children: [
  //     {
  //       path: 'index',
  //       name: 'Form',
  //       component: () => import('@/views/form/index'),
  //       meta: { title: 'Form', icon: 'form' }
  //     }
  //   ]
  // },

  // {
  //   path: '/nested',
  //   component: Layout,
  //   redirect: '/nested/menu1',
  //   name: 'Nested',
  //   meta: {
  //     title: 'Nested',
  //     icon: 'nested'
  //   },
  //   children: [
  //     {
  //       path: 'menu1',
  //       component: () => import('@/views/nested/menu1/index'), // Parent router-view
  //       name: 'Menu1',
  //       meta: { title: 'Menu1' },
  //       children: [
  //         {
  //           path: 'menu1-1',
  //           component: () => import('@/views/nested/menu1/menu1-1'),
  //           name: 'Menu1-1',
  //           meta: { title: 'Menu1-1' }
  //         },
  //         {
  //           path: 'menu1-2',
  //           component: () => import('@/views/nested/menu1/menu1-2'),
  //           name: 'Menu1-2',
  //           meta: { title: 'Menu1-2' },
  //           children: [
  //             {
  //               path: 'menu1-2-1',
  //               component: () => import('@/views/nested/menu1/menu1-2/menu1-2-1'),
  //               name: 'Menu1-2-1',
  //               meta: { title: 'Menu1-2-1' }
  //             },
  //             {
  //               path: 'menu1-2-2',
  //               component: () => import('@/views/nested/menu1/menu1-2/menu1-2-2'),
  //               name: 'Menu1-2-2',
  //               meta: { title: 'Menu1-2-2' }
  //             }
  //           ]
  //         },
  //         {
  //           path: 'menu1-3',
  //           component: () => import('@/views/nested/menu1/menu1-3'),
  //           name: 'Menu1-3',
  //           meta: { title: 'Menu1-3' }
  //         }
  //       ]
  //     },
  //     {
  //       path: 'menu2',
  //       component: () => import('@/views/nested/menu2/index'),
  //       name: 'Menu2',
  //       meta: { title: 'menu2' }
  //     }
  //   ]
  // },

  // {
  //   path: 'external-link',
  //   component: Layout,
  //   children: [
  //     {
  //       path: 'https://panjiachen.github.io/vue-element-admin-site/#/',
  //       meta: { title: 'External Link', icon: 'link' }
  //     }
  //   ]
  // },

  // 404 page must be placed at the end !!!
  // { path: '*', redirect: '/404', hidden: true }
]

// 异步路由：不同的用户（角色），需要过滤筛选出的路由，称之为异步路由
export const asyncRoutes = [
  {
    name: 'Acl',
    path: '/acl',
    component: Layout,
    redirect: '/acl/user/list',
    meta: {
      title: '权限管理',
      icon: 'el-icon-lock',
      roles: ['admin']
    },
    children: [
      {
        name: 'User',
        path: 'user/list',
        component: () => import('@/views/acl/user/list'),
        meta: {
          title: '用户管理'
        }
      },
      {
        name: 'Role',
        path: 'role/list',
        component: () => import('@/views/acl/role/list'),
        meta: {
          title: '角色管理'
        }
      },
      {
        name: 'RoleAuth',
        path: 'role/auth/:id',
        component: () => import('@/views/acl/role/roleAuth'),
        meta: {
          activeMenu: '/acl/role/list',
          title: '角色授权'
        },
        hidden: true
      },
      {
        name: 'Permission',
        path: 'permission/list',
        component: () => import('@/views/acl/permission/list'),
        meta: {
          title: '菜单管理'
        },
        hidden: true
      }
    ]
  },
  // {
  //   path: '/article/:id',
  //   component: () => import('@/views/dashboard/article'),
  //   meta: { show: true },
  //   name: 'article',
  //   props: ($route) => ({ id: $route.params.id })
  // },
  {
    path: '/villagerinformation',
    component: Layout,
    name: 'VillagerInformation',
    redirect: '/villagerinformation/villager',
    meta: { title: '村民信息管理', icon: 'el-icon-house', roles: ['admin', 'leader', 'officer'] },
    children: [
      {
        path: 'villager',
        name: 'Villager',
        component: () => import('@/views/villagerInformation/villager'),
        meta: { title: '村民个人信息' }
      },
      {
        path: 'birth',
        name: 'Birth',
        component: () => import('@/views/villagerInformation/birth'),
        meta: { title: '人口出生信息' },
        hidden: true
      },
      {
        path: 'death',
        name: 'Death',
        component: () => import('@/views/villagerInformation/death'),
        meta: { title: '人口死亡信息' },
        hidden: true
      }
    ]
  },
  {
    path: '/filing',
    component: Layout,
    name: 'Filing',
    redirect: '/filing/familyfiles',
    meta: { title: '每户建档管理', icon: 'el-icon-s-management', roles: ['admin', 'officer'] },
    children: [
      {
        path: 'familyfiles',
        name: 'FamilyFiles',
        component: () => import('@/views/filing/familyFiles'),
        meta: { title: '家庭档案信息' }
      },
      {
        path: 'helpInformation',
        name: 'HelpInformation',
        component: () => import('@/views/filing/helpInformation'),
        meta: { title: '帮扶信息' }
      }
    ]
  },
  {
    path: '/assetinformation',
    component: Layout,
    name: 'AssetInformation',
    redirect: '/assetinformation/infrastructure',
    meta: { title: '资产管理', icon: 'el-icon-menu', roles: ['admin', 'leader'] },
    children: [
      {
        path: 'infrastructure',
        name: 'Infrastructure',
        component: () => import('@/views/assetInformation/infrastructure'),
        meta: { title: '基础设施管理' }
      },
      {
        path: 'resource',
        name: 'Resource',
        component: () => import('@/views//assetInformation/resource'),
        meta: { title: '自然资源管理' }
      }
    ]
  },
  {
    path: '/villageaffairs',
    component: Layout,
    name: 'VillageAffairs',
    redirect: '/villageaffairs/house',
    meta: { title: '村务信息管理', icon: 'el-icon-s-grid', roles: ['admin', 'officer'] },
    children: [
      {
        path: 'house',
        name: 'House',
        component: () => import('@/views/villageAffairs/house'),
        meta: { title: '房屋建筑' }
      },
      {
        path: 'assanation',
        name: 'Assanation',
        component: () => import('@/views/villageAffairs/assanation'),
        meta: { title: '环境卫生' }
      },
      {
        path: 'land',
        name: 'Land',
        component: () => import('@/views/villageAffairs/land'),
        meta: { title: '土地流转' }
      }
    ]
  },
  {
    path: '/poor',
    component: Layout,
    name: 'Poor',
    redirect: '/poor/lowIncomeFamily',
    meta: { title: '贫困户信息管理', icon: 'el-icon-s-home', roles: ['admin', 'officer'] },
    children: [
      {
        path: 'lowIncomeFamily',
        name: 'LowincomeFamily',
        component: () => import('@/views/poor/lowIncomeFamily'),
        meta: { title: '贫困家庭' }
      },
      {
        path: 'povertyAlleviationFamily',
        name: 'PovertyAlleviationFamily',
        component: () => import('@/views/poor/povertyAlleviationFamily'),
        meta: { title: '脱贫家庭' }
      }
    ]
  },
  {
    path: '/dailybusiness',
    component: Layout,
    name: 'DailyBusiness',
    redirect: '/dailybusiness/income',
    meta: { title: '日常经营信息', icon: 'el-icon-money', roles: ['admin', 'accountant'] },
    children: [
      {
        path: 'income',
        name: 'Income',
        component: () => import('@/views/dailyBusiness/income'),
        meta: { title: '收入信息' }
      },
      {
        path: 'pay',
        name: 'Pay',
        component: () => import('@/views/dailyBusiness/pay'),
        meta: { title: '支出信息' }
      }
    ]
  },
  {
    path: '/finance',
    component: Layout,
    name: 'Finance',
    redirect: '/finance/information',
    meta: { title: '村务财务状况管理', icon: 'el-icon-coin', roles: ['admin', 'leader'] },
    children: [
      {
        path: 'information',
        name: 'Information',
        component: () => import('@/views/finance/information'),
        meta: { title: '财务信息' }
      },
      {
        path: 'incomeandexpenses',
        name: 'IncomeAndExpenses',
        component: () => import('@/views/finance/incomeAndExpenses'),
        meta: { title: '收支情况' },
        hidden: true
      }
    ]
  }
]

// 任意路由：当路径出现错误的时候重定向404
export const anyRoutes = { path: '*', redirect: '/404', hidden: true }

export let asyncRoutesShow = []

const createRouter = () =>
  new Router({
    // mode: 'history', // require service support
    scrollBehavior: () => ({ y: 0 }),
    routes: constantRoutes
  })

const router = createRouter()

// Detail see: https://github.com/vuejs/vue-router/issues/1234#issuecomment-357941465
export function resetRouter() {
  const newRouter = createRouter()
  router.matcher = newRouter.matcher // reset router
}

export default router
