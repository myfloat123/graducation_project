import request from '@/utils/request'

const api_name = '/users'

/*
登陆
*/
export function login({ user_name, password }) {
  return request({
    url: '/users/login',
    method: 'post',
    data: { user_name, password }
  })
}

/*
获取用户信息(根据token)
*/
export function getInfo() {
  return request({
    url: '/users/',
    method: 'get'
  })
}

/*
登出
*/
export function logout() {
  return request({
    url: '/users/logout',
    method: 'post'
  })
}

/*
获取当前用户的菜单权限列表
*/
// export function getMenu() {
//   return request('/admin/acl/index/menu')
// }

export function getMenu(userId, page = 1, limit = 3) {
  return request({
    url: '/permission',
    method: 'get',
    data: {
      userId,
      page,
      limit
    }
  })
}

/*
获取后台用户分页列表(带搜索)
*/
// export function getPageList(page, limit, searchObj) {
//   return request({
//     url: `${api_name}/${page}/${limit}`,
//     method: 'get',
//     params: searchObj
//   })
// }
export function getPageList(params) {
  return request({
    url: `${api_name}/info`,
    method: 'get',
    params
  })
}

/*
根据ID获取某个后台用户
*/
export function getById(id) {
  return request({
    url: `${api_name}/get/${id}`,
    method: 'get'
  })
}

/*
保存一个新的后台用户
*/
export function add(user) {
  return request({
    url: `${api_name}/register`,
    method: 'post',
    data: user
  })
}

/*
更新一个后台用户
*/
export function update(user) {
  return request({
    url: `${api_name}/update`,
    method: 'put',
    data: user
  })
}

/*
获取某个用户的所有角色
*/
export function getRoles(userId) {
  return request({
    url: `${api_name}/toAssign/${userId}`,
    method: 'get'
  })
}

/*
给某个用户分配角色
roleId的结构: 字符串, 'rId1,rId2,rId3'
*/
export function assignRoles(userId, roleIds, action) {
  return request({
    url: `${api_name}/doAssign`,
    method: 'post',
    data: {
      userId,
      roleIds,
      action
    }
  })
}

/*
删除某个用户
*/
export function removeById(id) {
  return request({
    url: `${api_name}/delete/${id}`,
    method: 'delete'
  })
}

/*
批量删除多个用户
ids的结构: ids是包含n个id的数组
*/
export function removeUsers(ids) {
  return request({
    url: `${api_name}/delete/batchRemove`,
    method: 'delete',
    data: { ids }
  })
}
