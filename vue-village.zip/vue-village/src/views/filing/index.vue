<template>
  <div>每户建档信息管理</div>
</template>

<script>
export default {
  name: 'Filing'
}
</script>

<style scoped></style>
