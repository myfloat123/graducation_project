<template>
  <div class="dashboard-container">
    <div class="dashboard-text">您好 {{ name }}</div>
    <div class="wrapper">
      <header class="header">
        <div class="title-h1">
          <h1>欢迎使用农村村务管理系统</h1>
        </div>
        <div>
          <el-carousel :interval="3000" arrow="always" :height="`${bannerHeight}px`" type="card">
            <el-carousel-item v-for="item in backgroundIamge" :key="item.id">
              <!-- <h3>{{ item.id }}</h3> -->
              <img class="backgroundImage" :src="item.url" alt="" />
              <!-- <el-image :src="srcList[i]" :preview-src-list="srcList" /> -->
            </el-carousel-item>
          </el-carousel>
        </div>
      </header>

      <section class="content">
        <h3>最新公告</h3>
        <h4>关于开展夏季防火安全检查的通知</h4>
        <p>
          各村民： 为了保障夏季农村的防火安全，预防和减少火灾事故的发生，维护农村的生产秩序和社会稳定，现将有关事项通知如下：<br /><br />
          一、各村民要加强防火意识，遵守防火规定，不在室内或室外乱烧杂物，不在林区或草场放火烧荒，不在危险场所使用明火或电焊等设备，不在屋顶或阳台晾晒棉被或衣物。<br /><br />
          二、各村民要检查和整改自家的用电设施，不私拉乱接电线，不超负荷使用电器，不在床上使用电热毯或电暖器，不在易燃物附近使用电炉或微波炉，不在睡觉时插上充电器或开启电器。<br /><br />
          三、各村民要妥善保管和使用易燃易爆物品，如酒精、汽油、液化气等，不将其放置在高温或明火附近，不将其随意倒入下水道或垃圾桶，不将其私自运输或贩卖。<br /><br />
          四、各村民要配备和使用灭火器材，如灭火器、灭火毯、水桶等，将其放置在显眼和便捷的位置，并定期检查和更换。一旦发生火灾，要立即报警，并根据情况采取适当的灭火措施。<br /><br />
          五、本村将于本月底开展冬季防火安全检查，对存在隐患的村民进行提醒和督促整改，并对拒不整改或造成严重后果的村民进行处罚。请各村民积极配合和支持本次检查工作。 希望广大村民共同努力，营造一个安全、和谐、美丽的农村环境。 特此通知。
        </p>
      </section>

      <div class="box-1">
        <h3 class="h3-box-1" @click="showInformDetail($event)">关于老房翻建的通知</h3>
        <p style="text-indent: 2em" class="p-box-1" @click="showInformDetail($event)">
          在严格保护耕地的形势下，国家对农村村民建房管控越来越严格，按照《土地管理法》和《城乡规划法》的规定，农村村民建房需要取得宅基地批准书和乡村建设规划许可证，如果是拆掉旧房子建新房，相对来说，会简单一些。不过需注意的是，对于一些特殊情况，翻建老房也是不允许的，这些情况建好了也可能被拆!
        </p>
        <el-dialog id="elDialog" ref="el-dialog" title="关于老房翻建的通知详情" :visible.sync="dialogVisible1" :before-close="dialogBeforeClose">
          <pre id="preContent1" />
          <div slot="footer" style="display: none">
            <el-button @click="dialogVisible = false">取 消</el-button>
            <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
          </div>
        </el-dialog>
      </div>
      <div class="box-2">
        <h3 class="h3-box-2" @click="showInformDetail($event)">农村产权流转交易规范化试点工作的要求</h3>
        <p style="text-indent: 2em" class="p-box-2" @click="showInformDetail($event)">为贯彻落实国家有关农村产权流转交易规范化试点工作的要求，促进农村土地、林权、宅基地等产权的合法、有序、有效流转，提高农村资源的利用效率，增加农民收入，我村将开展以下工作：</p>
        <el-dialog id="elDialog" ref="el-dialog" title="农村产权流转交易规范化试点工作的要求" :visible.sync="dialogVisible2" :before-close="dialogBeforeClose">
          <pre id="preContent2" />
          <div slot="footer" style="display: none">
            <el-button @click="dialogVisible = false">取 消</el-button>
            <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
          </div>
        </el-dialog>
      </div>
      <div class="box-3">
        <h3 class="h3-box-3" @click="showInformDetail($event)">环境卫生整治提升活动通知</h3>
        <p style="text-indent: 2em" class="p-box-3" @click="showInformDetail($event)">为了改善农村人居环境，提升农民群众生活品质和卫生健康水平，根据中央和省市有关文件精神，我村决定开展环境卫生整治提升行动，现将有关事项通知如下：</p>
        <el-dialog id="elDialog" ref="el-dialog" title="环境卫生整治提升活动通知" :visible.sync="dialogVisible3" :before-close="dialogBeforeClose">
          <pre id="preContent3" />
          <div slot="footer" style="display: none">
            <el-button @click="dialogVisible = false">取 消</el-button>
            <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
          </div>
        </el-dialog>
      </div>
      <div class="sidebar">
        <h3>联系我们</h3>
        <ul>
          <li>农村村务管理系统</li>
          <li>中国</li>
          <li>123456@163.com</li>
          <li>12345678</li>
        </ul>
      </div>
      <footer class="footer">
        <p>Copyright &copy; 2023</p>
      </footer>
    </div>
  </div>
</template>

<script>
import axios from 'axios'
import { mapGetters } from 'vuex'

export default {
  name: 'Dashboard',
  computed: {
    ...mapGetters(['name'])
  },
  mounted() {
    // 首次加载时，初始化高度
    console.log(window.innerWidth)
    this.screenWidth = window.innerWidth
    this.bannerHeight = (400 / 1550) * this.screenWidth
    // 窗口大小发生改变
    window.onresize = () => {
      this.screenWidth = window.innerWidth
      this.bannerHeight = (400 / 1550) * this.screenWidth
    }
    console.log(this.bannerHeight)
    this.getFileData()
  },
  data() {
    return {
      // 轮播图图片
      backgroundIamge: [
        { id: 1, url: 'http://localhost:8000/banner1.jpg' },
        { id: 2, url: 'http://localhost:8000/banner2.jpg' },
        // { id: 3, url: 'http://localhost:8000/banner3.jpeg' },
        { id: 3, url: 'http://localhost:8000/R.jpg' }
      ],
      srcList: ['http://localhost:8000/banner1.jpg', 'http://localhost:8000/banner2.jpg', 'http://localhost:8000/R.jpg'],
      // el-carousel容器高度
      bannerHeight: 0,
      // 浏览器宽度
      screenWidth: 0,
      // 是否显示弹窗
      dialogVisible1: false,
      dialogVisible2: false,
      dialogVisible3: false,
      // 当前页码
      page: 1,
      // 每页显示条数
      limit: 3,
      // 收集搜索条件输入的对象
      tempSearchObj: {
        file_originalFilename: ''
      },
      // 包含搜索条件数据的对象
      searchObj: {
        file_originalFilename: ''
      },
      // 每页文件列表
      pageList: [],
      // 文件列表
      list: [],
      element: null
    }
  },
  methods: {
    // 获取文件
    async getFileData(page = 1, limit = 3, searchObj = { file_originalFilename: '' }) {
      this.page = page
      this.limit = limit
      this.searchObj = searchObj
      let params = { page, limit, ...searchObj }
      const res = await this.$API.file.getFileInfo(params)
      console.log(res)
      return res
    },

    async jsReadFiles(basename, n) {
      // const readElement = document.querySelector('#h3')
      const res = await axios({ url: `http://localhost:8000/${basename}`, method: 'get' })
      // console.log(res)
      // console.log(res.data)
      // console.log(Object.prototype.toString.call(res.data))

      this.$store.commit('getArticleData1', res.data)
      this[`dialogVisible${n}`] = true
      setTimeout(() => {
        const pre = document.querySelector(`#preContent${n}`)

        this.element = pre
        console.log('pre', pre)
        pre.style.marginTop = '0px'
        pre.style.whiteSpace = 'pre-wrap'
        pre.style.wordWrap = 'break-word'
        console.log(res.data)
        pre.innerHTML = res.data
      }, 200)
      // console.log(this.$route.params)
      // if (this.$route.params) {
      //   this.$router.push({ name: 'article', params: this.$route.params })
      // } else {
      //   this.$router.push({ name: 'article' })
      // }
      // readElement.href = `http://localhost:8000/${basename}`
      // readElement.click()
    },
    dialogBeforeClose(done) {
      this.$confirm('确认关闭？')
        .then(_ => {
          done()

          this.element.innerHTML = ''
          this.element = null
        })
        .catch(_ => {
          console.log(_)
        })
    },
    async showInformDetail(e) {
      console.log('e.target', e.target)

      if (e.target.className == 'p-box-1') {
        // console.log(e.target.previousElementSibling.innerText)

        this.searchObj.file_originalFilename = e.target.previousElementSibling.innerText
        const res1 = await this.getFileData(this.page, this.limit, this.searchObj)
        console.log('res1', res1)
        this.jsReadFiles(res1.result.pageList[0].file_basename, e.target.className.slice(-1))
      } else if (e.target.className == 'p-box-2') {
        this.searchObj.file_originalFilename = e.target.previousElementSibling.innerText
        const res1 = await this.getFileData(this.page, this.limit, this.searchObj)
        console.log('res1', res1)
        this.jsReadFiles(res1.result.pageList[0].file_basename, e.target.className.slice(-1))
      } else if (e.target.className == 'p-box-3') {
        this.searchObj.file_originalFilename = e.target.previousElementSibling.innerText
        const res1 = await this.getFileData(this.page, this.limit, this.searchObj)
        console.log('res1', res1)
        this.jsReadFiles(res1.result.pageList[0].file_basename, e.target.className.slice(-1))
      } else {
        this.searchObj.file_originalFilename = e.target.innerText
        const res1 = await this.getFileData(this.page, this.limit, this.searchObj)
        console.log('res1', res1)
        this.jsReadFiles(res1.result.pageList[0].file_basename, e.target.className.slice(-1))
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.dashboard {
  &-container {
    margin: 30px;
  }
  &-text {
    font-size: 30px;
    line-height: 46px;
  }
}
</style>

<style scoped>
.el-carousel__item h3 {
  color: #475669;
  font-size: 18px;
  opacity: 0.75;
  line-height: 300px;
  margin: 0;
}

.el-carousel__item:nth-child(2n) {
  background-color: #99a9bf;
}

.el-carousel__item:nth-child(2n + 1) {
  background-color: #d3dce6;
}

.backgroundImage {
  width: 100%;
  height: inherit;
}

.wrapper {
  display: grid;
  grid-template-areas:
    'header header header'
    'content content content'
    'box-1 box-2 box-3'
    'sidebar sidebar sidebar'
    'footer footer footer';
  grid-gap: 1rem;
}

@media (max-width: 500px) {
  .wrapper {
    grid-template-areas:
      'header'
      'content'
      'sidebar'
      'box-1'
      'box-2'
      'box-3'
      'footer';
  }
}

.header {
  grid-area: header;
  text-align: center;
}

.content {
  grid-area: content;
  /* height: 200px; */
}

.box-1 {
  grid-area: box-1;
}

.box-1:hover,
.box-2:hover,
.box-3:hover {
  cursor: pointer;
}
#h3 {
  display: block;
  font-size: 1.17em;
  margin-block-start: 1em;
  margin-block-end: 1em;
  margin-inline-start: 0px;
  margin-inline-end: 0px;
  font-weight: bold;
}

.box-2 {
  grid-area: box-2;
}

.box-3 {
  grid-area: box-3;
}

.sidebar {
  grid-area: sidebar;
}

.footer {
  grid-area: footer;
  text-align: center;
}

.header,
.content,
.sidebar,
.box-1,
.box-2,
.box-3,
.footer {
  padding: 0.5rem;
  border: 1px solid #ccc;
}
</style>
