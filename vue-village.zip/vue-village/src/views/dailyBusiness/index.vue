<template>
  <div>日常经营信息</div>
</template>

<script>
export default {
  name: 'DailyBusiness'
}
</script>

<style scoped></style>
