import request from '@/utils/request'

// 获取文件
export const getFileInfo = (params) => request({ url: '/files/info', method: 'get', params })
