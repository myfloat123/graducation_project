<template>
  <div class="container">
    <el-form ref="form" label-width="80px" inline>
      <!-- 表单元素 -->
      <el-form-item>
        <el-input v-model="tempSearchObj.household_number" placeholder="户号" />
      </el-form-item>
      <el-form-item>
        <el-input v-model="tempSearchObj.household_name" placeholder="户主姓名" />
      </el-form-item>
      <!-- 查询与清空按钮 -->
      <el-button type="primary" icon="el-icon-search" @click="search">查询</el-button>
      <el-button type="default" @click="resetSearch">清空</el-button>
    </el-form>

    <!-- 添加与批量删除按钮 -->
    <div style="margin-bottom: 20px">
      <el-button type="primary" @click="showAddHousehold">添加</el-button>
      <el-button type="danger" :disabled="selectedIds.length === 0" @click="batchRemoveHousehold">批量删除</el-button>
    </div>

    <!-- table表格：展示户口信息 -->
    <el-table v-loading="listLoading" stripe :data="householdData" style="width: 100%" border @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" />
      <el-table-column type="index" align="center" width="55" label="序号" />
      <el-table-column type="expand">
        <template slot-scope="props">
          <el-form label-position="left" inline class="demo-table-expand">
            <el-form-item label="户号">
              <span>{{ props.row.household_number }}</span>
            </el-form-item>
            <el-form-item label="户主姓名">
              <span>{{ props.row.household_name }}</span>
            </el-form-item>
            <el-form-item label="性别">
              <span>{{ props.row.household_sex }}</span>
            </el-form-item>
            <el-form-item label="身份证号">
              <span>{{ props.row.household_ID }}</span>
            </el-form-item>
            <el-form-item label="出生日期">
              <span>{{ props.row.household_birthday }}</span>
            </el-form-item>
            <el-form-item label="联系方式">
              <span>{{ props.row.household_phone }}</span>
            </el-form-item>
            <div v-for="item in props.row.household_relation" :key="item.id">
              <el-form-item label="姓名">
                <span>{{ item.name }}</span>
              </el-form-item>
              <el-form-item label="关系">
                <span>{{ item.relation }}</span>
              </el-form-item>
            </div>
          </el-form>
        </template>
      </el-table-column>
      <el-table-column label="户号" prop="household_number" />
      <el-table-column label="户主姓名" prop="household_name" />
      <el-table-column label="身份证号" prop="household_ID" />
      <el-table-column label="是否贫困" prop="is_poor_household" />
      <el-table-column header-align="center" align="center" label="操作">
        <template slot-scope="{ row, $index }">
          <el-button type="warning" size="mini" @click="updateHousehold(row, $index)">修改</el-button>
          <el-button type="danger" size="mini" @click="removeHousehold(row, $index)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页器 -->
    <!--   -->
    <el-pagination style="margin-top: 20px; text-align: center" :current-page="page" :page-sizes="[3, 5, 10]" :page-count="7" :page-size.sync="limit" layout="prev, pager, next, jumper, ->, sizes, total" :total="total" @current-change="handleCurrentChange" @size-change="handleSizeChange" />

    <!-- 对话框 -->
    <!--  -->
    <el-dialog ref="elDialog" :title="household.id ? '修改家庭档案信息' : '添加家庭档案信息'" :visible.sync="dialogVisible" :before-close="dialogBeforeClose">
      <el-form ref="household" inline :model="household" label-width="100px" style="width: 100%" :rules="householdRules">
        <el-form-item label="户号" prop="household_number">
          <el-input v-model="household.household_number" :disabled="!!household.id" @blur="household.id ? update_household($event) : null" />
        </el-form-item>
        <el-form-item label="户主姓名" prop="household_name">
          <el-input v-model="household.household_name" @blur="household.id ? update_household($event) : null" />
        </el-form-item>
        <el-form-item label="身份证号" prop="household_ID">
          <el-input v-model="household.household_ID" @blur="household.id && household.household_ID.length === 18 ? update_household($event) : add_household_birthday()" />
        </el-form-item>
        <el-form-item label="性别" prop="household_sex">
          <el-select id="select_sex" v-model="household.household_sex" @change="household.id ? update_household($event) : null">
            <el-option v-for="item in dict_sex" id="option_sex" :key="item.id" :label="item.sex" :value="item.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="出生日期" prop="household_birthday">
          <el-input v-model="household.household_birthday" @blur="household.id ? update_household($event) : null" />
        </el-form-item>
        <el-form-item label="联系方式" prop="household_phone">
          <el-input v-model="household.household_phone" @blur="household.id && household.household_phone.length === 11 ? update_household($event) : null" />
        </el-form-item>
        <el-form-item label="是否贫困" prop="is_poor_household">
          <el-select v-model="household.is_poor_household" @change="household.id ? update_household($event) : null">
            <el-option v-for="item in dict_is_poor_household" :key="item.id" :label="item.is_poor_household" :value="item.is" />
          </el-select>
        </el-form-item>

        <!-- <el-button type="primary" @click="addHouseMember">添加</el-button>
            <el-form id="household_relation" ref="household_relation" :model="household_relation" label-width="100px" inline style="margin-bottom: 20px; padding-top: 10px">
              <el-form-item label="姓名" prop="name" style="margin-bottom: 10px">
                <el-input v-model="household_relation.name" />
              </el-form-item>
              <el-form-item label="关系" prop="relation" style="margin-bottom: 10px">
                <el-input v-model="household_relation.relation" />
              </el-form-item>
              <el-form-item style="margin-left: 10px; margin-bottom: 10px">
                <el-button type="danger" @click="deleteHouseMember">删除</el-button>
              </el-form-item>
            </el-form> -->
      </el-form>
      <el-divider content-position="center">家庭成员</el-divider>
      <!-- eslint-disable -->
      <el-button type="primary" :disabled="household.household_number === ''" @click="household.id ? updateHouseholdRelation() : addHouseholdRelation()">添加</el-button>
      <el-button type="danger" :disabled="selectedRelationIds.length === 0" @click="confirmBatchRemoveRow" ref="batchRemove" id="batchRemove">批量删除</el-button>
      <el-table :data="household_relation" style="width: 100%; margin-top: 20px" border stripe @selection-change="handleHouseholdRelationChange">
        <el-table-column type="selection" />
        <el-table-column type="index" align="center" label="序号" />
        <el-table-column prop="name" label="姓名" align="center">
          <template slot-scope="{ row, $index }">
            <el-input v-model="row.household_name" ref="household_name" @change="onChangeHouseholdName" @blur="household.id ? updateHouseholdNameOrRelation($event, row, $index) : null" />
          </template>
        </el-table-column>
        <el-table-column prop="relation" label="关系" align="center">
          <template slot-scope="{ row, $index }">
            <el-input v-model="row.household_relation" ref="household_relation" @change="onChangeHouseholdRelation" @blur="household.id ? updateHouseholdNameOrRelation($event, row, $index) : null" />
          </template>
        </el-table-column>
        <el-table-column align="center" label="操作">
          <template slot-scope="{ row, $index }">
            <!-- <el-button type="warning" icon="el-icon-edit" size="mini" @click="updateHouseholdRelation(row, $index)">修改</el-button> -->
            <el-button type="danger" icon="el-icon-delete" size="mini" @click="removeHouseholdRelation(row, $index)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- <el-dialog title="添加户主关系" :visible.sync="dialogVisibleHouseholdRelation" width="width" :before-close="dialogBeforeClose">
        <div />
        <div slot="footer">
          <el-button @click="dialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
        </div>
      </el-dialog> -->
      <div slot="footer">
        <el-button @click="cancelHousehold">取 消</el-button>
        <el-button type="primary" v-if="deleteRowInfo.index >= 0 || tempBatchRemoveRowLength" @click="deleteRowInfo.index !== undefined ? confirmDeleteRow() : confirmBatchRemove()" id="confirmDelete">确 定</el-button>
        <el-button v-else type="primary" @click="household.id ? updateConfirmHouseholdRelation(household.id) : addConfirmHouseholdRelation()" id="confirm">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
// 菜单权限校验的规则
const menuRules = {
  name: [{ required: true, message: '姓名必须输入' }],
  code: [{ required: true, message: '关系必须输入' }]
}

// 按钮功能权限校验的规则
const btnRules = {
  name: [{ required: true, message: '姓名必须输入' }],
  code: [{ required: true, trigger: 'blur', message: '关系必须输入' }]
}
export default {
  name: 'FamilyFiles',
  data() {
    return {
      listLoading: false, // 是否显示列表加载的提示
      householdData: [], // 每页所有户口信息
      list: [], // 所有户口信息列表
      page: 1, // 当前页码
      limit: 3, // 每页数量
      total: 0, // 总数量
      relationList: [], // 所有户主关系信息
      relationTotal: 0, // 总户主关系数量
      selectedIds: [], // 所有选择的household的id数组
      selectedRelationIds: [], // 所有选择户主的id数组
      selectedHouseholdIndexs: [], // 所有选择户主的index数组
      searchObj: {
        // 包含请求搜索条件数据的对象
        household_number: '',
        household_name: ''
      },
      loading: false, // 是否正在提交请求中
      tempSearchObj: {
        // 收集搜索条件输入的对象
        household_number: '',
        household_name: ''
      },
      // 户主校验规则
      householdRules: {
        household_number: [{ required: true, message: '请输入户号', trigger: 'blur' }],
        household_name: [{ required: true, message: '请输入户主姓名', trigger: 'blur' }],
        household_sex: [{ required: true, message: '请输入性别', trigger: 'blur' }],
        household_ID: [
          { required: true, message: '请输入身份证号', trigger: 'blur' },
          { validator: this.validatorIDNumber, trigger: 'blur' }
        ],
        household_birthday: [{ required: true, message: '请输入出生日期', trigger: 'blur' }],
        household_phone: [
          { required: true, message: '请输入电话号码', trigger: 'blur' },
          { validator: this.validatorPhone, trigger: 'blur' }
        ]
      },
      // 性别字典
      dict_sex: [
        { id: 1, sex: '男' },
        { id: 2, sex: '女' }
      ],
      // 是否贫困家庭字典
      dict_is_poor_household: [
        { id: 1, is: false, is_poor_household: '否' },
        { id: 2, is: true, is_poor_household: '是' }
        // { id: 3, is: false, is_poor_household: '无' }
      ],

      // 户主信息
      household: {
        household_number: 'HH' + `${+new Date()}`.slice(-4) || '',
        household_name: '',
        household_sex: '',
        household_ID: '',
        household_birthday: '',
        household_phone: '',
        is_poor_household: ''
      },
      is_disabled: false, // 是否禁用添加户主关系按钮
      dialogVisibleHouseholdRelation: false, // 是否显示户主关系对话框
      household_relation: [], // 户主关系数组
      update_household_relation: [], // 更新添加户主关系数组
      household_relation_length: this.$store.state.household.household_relation_length || 0, // 户主关系数组长度
      household_name1: [], // 缓存户主关系人姓名
      household_relation1: [], // 缓存户主关系
      // household_relation1: {
      //   household_name: '',
      //   household_relation: ''
      // },
      // 删除行信息
      deleteRowInfo: {},
      // 批量删除行信息
      batchRemoveRowInfo: [],
      tempBatchRemoveRowLength: 0, // 暂存批量删除行信息
      buttonForm: {
        buttonList: [
          { id: 1, type: 'primary', text: '添加', style: { marginLeft: '20px' }, class: 'addHouseMemberButton' },
          { id: 2, type: 'danger', text: '删除', class: 'deleteHouseMemberButton' }
        ]
      },
      dialogVisible: false, // 是否显示用户添加/修改的dialog
      menuPermissionList: [], // 菜单列表
      expandKeys: [], // 需要自动展开的项
      dialogPermissionVisible: false, // 是否显示菜单权限的Dialog
      permission: {
        // 要操作的菜单权限对象
        level: 0,
        name: '',
        code: '',
        toCode: ''
      }
    }
  },
  computed: {
    /*
    动态计算得到Dialog的标题
    */
    dialogTitle() {
      const { id, level } = this.permission
      if (id) {
        return level === 4 ? '修改功能' : '修改菜单'
      } else {
        return level === 4 ? '添加功能' : `添加${level === 2 ? '一级' : '二级'}菜单`
      }
    },

    /*
    根据权限的等级来计算确定校验规则
    */
    permissionRules() {
      return this.permission.level === 4 ? btnRules : menuRules
    }
  },

  mounted() {
    this.getHouseholdData()
    console.log(this.$store)
  },
  methods: {
    // 自定义身份证号校验
    validatorIDNumber(rule, value, callback) {
      const IDNumber = value.replace(/\s/g, '') // 去除空格
      const regs = /^[1-9]\d{5}(18|19|20)\d{2}((0[1-9])|(1[0-2]))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/
      if (!value) {
        callback('请输入身份证号')
      } else if (value.length !== 0) {
        if (!regs.test(IDNumber)) {
          callback([new Error('身份证号输入不合法')])
        } else {
          callback()
        }
      } else {
        callback()
      }
    },
    // 自定义手机号校验
    validatorPhone(rule, value, callback) {
      const phone = value.replace(/\s/g, '') // 去除空格
      const regs = /^((13[0-9])|(17[0-1,6-8])|(15[^4,\\D])|(18[0-9]))\d{8}$/
      if (!value) {
        callback('请输入手机号')
      } else if (value.length !== 0) {
        if (!regs.test(phone)) {
          callback([new Error('手机号输入不合法')])
        } else {
          callback()
        }
      } else {
        callback()
      }
    },
    // 获取所有户口信息
    async getHouseholdData(pager = 1) {
      this.page = pager
      const { page, limit } = this
      this.listLoading = true
      const res1 = await this.$API.household.getHouseholdInfo(page, limit)
      const res2 = await this.$API.relation.getRelationInfo(page, limit)
      // console.log(res1)
      // console.log(res2)
      this.listLoading = false
      if (res1.code === 0) {
        res1.result.pageList.forEach(item1 => {
          this.dict_is_poor_household.forEach(item2 => {
            if (item1.is_poor_household === item2.is) {
              item1.is_poor_household = item2.is_poor_household
            }
          })
        })
        res1.result.list.forEach(item1 => {
          this.dict_is_poor_household.forEach(item2 => {
            if (item1.is_poor_household === item2.is) {
              item1.is_poor_household = item2.is_poor_household
            }
          })
        })
        this.list = res1.result.list
        this.total = res1.result.total
        this.householdData = res1.result.pageList
      } else {
        return Promise.reject(new Error('faile'))
      }
      if (res2.code === 0) {
        this.relationList = res2.result.list
        this.relationTotal = res2.result.total
        this.householdData.forEach(household => {
          household.household_relation = []
          this.relationList.forEach(relation => {
            if (household.household_number === relation.household_number) {
              household.household_relation.push(relation)
            }
          })
        })
      } else {
        return Promise.reject(new Error('faile'))
      }
    },
    // 从身份证号码中获取出生日期
    add_household_birthday() {
      console.log(this.household.household_ID)
      let birthStr = this.household.household_ID.slice(6, 14)
      let birthStr1 = birthStr.slice(0, 4)
      let birthStr2 = birthStr.slice(4, 6)
      let birthStr3 = birthStr.slice(6, 8)
      let birthday = `${birthStr1}-${birthStr2}-${birthStr3}`
      this.household.household_birthday = birthday
    },
    // 获取每户信息
    async getMoreHouseholdData(searchObject, page = 1, limit = 3) {
      const _this = this
      this.page = page
      this.limit = limit
      this.listLoading = true
      const res1 = await this.$API.household.getMoreHouseholdInfo(searchObject, this.page, this.limit)
      console.log('res1', res1)
      if (res1.code === 0) {
        this.list = res1.result.list
        this.total = res1.result.total
        this.householdData = res1.result.pageList
      } else {
        return Promise.reject(new Error('faile'))
      }
      let household_number_arr = []
      if (searchObject.household_number === '') {
        this.householdData.forEach(household => {
          if (searchObject.household_name === household.household_name) {
            searchObject.household_number = household.household_number
            household_number_arr.push(household.household_number)
          }
        })
      }
      console.log('household_number_arr', household_number_arr)
      let res3
      res3 = household_number_arr.map(async household_number => {
        const res4 = await this.$API.relation.getMoreRelationInfo({ household_number }, this.page, this.limit)

        return res4
      })
      this.listLoading = false
      console.log('res3', res3)
      Promise.all(res3)
        .then(result => {
          console.log('result', result)
          result.forEach(res2 => {
            console.log('res2', res2)
            if (res2.code === 0) {
              this.relationList.push(res2.result.list[0])
              console.log('this.relationList11', this.relationList)
            } else {
              return Promise.reject(new Error('faile'))
            }
          })
          // this.relationList = this.relationList.slice(0, this.relationList.length / 2)
          this.householdData.forEach(household => {
            household.household_relation = []
            this.relationList.forEach(relation => {
              if (household.household_number === relation.household_number) {
                console.log('relation', relation)
                household.household_relation.push(relation)
                console.log('household.household_relation', household.household_relation)
              }
            })
          })

          this.householdData.forEach(household => {
            household.household_relation.forEach((householdRelation, index) => {
              // console.log('householdRelation.household_info', householdRelation.household_info)
              if (householdRelation.household_info === undefined) {
                household.household_relation.splice(index, household.household_relation.length - 1)
              }
            })
          })
          this.relationTotal = result.length
          console.log('this.relationList22', this.relationList)
        })
        .catch(err => err)
      // const res2 = await _this.$API.relation.getMoreRelationInfo(searchObject, this.page, this.limit)
    },
    // 搜索
    search() {
      this.searchObj = { ...this.tempSearchObj }
      this.getMoreHouseholdData(this.searchObj, this.page, this.limit)
    },
    // 清空
    resetSearch() {
      this.searchObj = {
        household_number: '',
        household_name: ''
      }
      this.tempSearchObj = {
        household_number: '',
        household_name: ''
      }
      this.getHouseholdData()
    },
    // 显示添加户口信息的界面
    showAddHousehold() {
      this.dialogVisible = true
      this.household = {
        household_number: 'HH' + `${+new Date()}`.slice(-4) || '',
        household_name: '',
        household_sex: '',
        household_ID: '',
        household_birthday: '',
        household_phone: ''
      }
    },
    // 关闭弹窗前的处理函数
    dialogBeforeClose(done) {
      this.$confirm('确认关闭？')
        .then(async _ => {
          done()
          if (this.household.id) {
            this.$refs['household'].resetFields()
            console.log(this.$refs['household'].model)
            let id = this.$refs['household'].model.id
            let data = {
              household_number: this.$refs['household'].model.household_number,
              household_name: this.$refs['household'].model.household_name,
              household_sex: this.$refs['household'].model.household_sex,
              household_ID: this.$refs['household'].model.household_ID,
              household_birthday: this.$refs['household'].model.household_birthday,
              household_phone: this.$refs['household'].model.household_phone
            }
            let relationIds = []
            relationIds = this.$refs['household'].model.household_relation.map(item => item.id)
            await this.$API.household.updateHousehold(id, data)
            relationIds.forEach(async (relationId, i) => {
              let relationData = {
                household_number: this.$refs['household'].model.household_relation[i].household_number,
                name: this.$refs['household'].model.household_relation[i].name,
                relation: this.$refs['household'].model.household_relation[i].relation
              }
              await this.$API.household.updateHouseholdRelation(relationId, relationData)
              relationData = {}
            })
          }
          this.household = {
            household_number: '',
            household_name: '',
            household_sex: '',
            household_ID: '',
            household_birthday: '',
            household_phone: '',
            is_poor_household: '',
            household_relation: []
          }
          this.$refs['household'].clearValidate()
          this.batchRemoveRowInfo = []
          this.selectedRelationIds = []
          this.selectedHouseholdIndexs = []
          this.deleteRowInfo = {}
          this.household_relation = []
          this.tempBatchRemoveRowLength = 0
          this.dialogVisible = false
        })
        .catch(_ => {
          console.log(_)
        })
    },
    // 添加家庭成员
    addHouseMember() {
      let _this = this
      let household_relation = document.querySelector('#household_relation')

      let household_relation1 = household_relation.children[0].cloneNode(true)
      let household_relation2 = household_relation.children[1].cloneNode(true)
      let household_relation3 = household_relation.children[2].cloneNode(true)
      household_relation1.style = 'display:inline-block;'
      household_relation2.style = 'display:inline-block;'
      household_relation3.style = 'display:inline-block;margin-left: 10px; margin-bottom: 10px'
      // console.log('household_relation1', household_relation1)
      // console.log('household_relation2', household_relation2)
      console.log('household_relation3', household_relation3)
      // console.log(household_relation.children[0])
      // console.log(household_relation1)
      household_relation.appendChild(household_relation1)
      household_relation.appendChild(household_relation2)
      household_relation.appendChild(household_relation3)
      let deleteHouseMemberButton = household_relation3.children[0].children[0]
      deleteHouseMemberButton.addEventListener('click', _this.deleteHouseMember)

      // let addHouseMemberButton = household_relation1.children[household_relation1.children.length - 1].children[2].children[0].children[0]
      // addHouseMemberButton.addEventListener('click', _this.addHouseMember)
      // addHouseMemberButton.removeEventListener('click', _this.addHouseMember)
    },
    deleteHouseMember(e) {
      // console.log(e.target.childNodes[0])
      if (e.target.childNodes[0].nodeType === 3) {
        console.log('删除', e.target)
      } else {
        console.log('deleteButton', e.target)
        let deleteButtonDiv = e.target.parentNode.parentNode

        let elForm = deleteButtonDiv.parentNode
        let relationDiv = deleteButtonDiv.previousElementSibling

        let nameDiv = relationDiv.previousElementSibling

        for (let i = 0; i < elForm.children.length; i++) {
          elForm.children[i].className = 'el-form-item'
        }
        deleteButtonDiv.className = 'el-form-item deleted'
        relationDiv.className = 'el-form-item deleted'
        nameDiv.className = 'el-form-item deleted'
        console.log('elForm', elForm)
        console.log('deleteButtonDiv', deleteButtonDiv)
        console.log('relationDiv', relationDiv)
        console.log('nameDiv', nameDiv)
        console.log('elForm.children[0]', elForm.children[0])
        console.log('elForm.children[1]', elForm.children[1])
        console.log('elForm.children[2]', elForm.children[2])
        for (let j = 0; j < elForm.children.length; j++) {
          if ((elForm.children[j].className = 'el-form-item deleted')) {
            console.log(j)
          }
        }

        // for (let i = 0; i < elForm.children.length; i++) {
        //   elForm.children[i].style = 'display:none;'
        // }
        // elForm.removeChild(elForm.children[0])
      }
    },
    buttonClick(buttonId) {
      if (buttonId === 1) {
        this.addHouseMember()
      } else {
        this.deleteHouseMember()
      }
    },
    // 删除行
    removeHouseholdRelation(household_relation, index) {
      Object.assign(this.deleteRowInfo, { ...household_relation, index })
      // this.deleteRowInfo = { ...household_relation, index }
      console.log('household_relation', household_relation)
      console.log('household_relation.id', household_relation.id)
      console.log('index', index)
      // console.log(this.household.household_relation[index].id)
      // let id = this.household.household_relation[index].id
      // let confirmButton = document.querySelector('#confirm')
      // confirmButton.addEventListener('click', async function () {
      //   const res = await this.$API.household.removeHouseholdRelation(id)
      //   console.log(res)
      // })

      this.household_relation.splice(index, 1)
    },
    // 确认删除行
    async confirmDeleteRow() {
      let index = this.deleteRowInfo.index
      let id = this.household.household_relation[index].id
      const res = await this.$API.household.removeHouseholdRelation(id)
      console.log(res)
      this.deleteRowInfo = {}
      this.batchRemoveRowInfo = []
      this.tempBatchRemoveRowLength = 0
      this.getHouseholdData(this.household.id ? this.page : 1)

      this.$message({ type: 'success', message: '修改户口信息成功' })
      this.dialogVisible = false
    },
    // 确认提交户口信息
    async addConfirmHouseholdRelation() {
      let data = {
        household_number: this.household.household_number,
        household_name: this.household.household_name,
        household_ID: this.household.household_ID,
        household_sex: this.household.household_sex,
        household_birthday: this.household.household_birthday,
        household_phone: this.household.household_phone,
        is_poor_household: this.household.is_poor_household
      }
      if (data.household_sex === 1) {
        data.household_sex = '男'
      } else {
        data.household_sex = '女'
      }
      if (typeof data.is_poor_household === 'string') {
        this.dict_is_poor_household.forEach(item => {
          if (item.is_poor_household === data.is_poor_household) {
            data.is_poor_household = item.is
          }
        })
      }
      // if (!data.is_poor_household) {
      //   data.is_poor_household = false
      // }
      // this.household.household_sex = this.household.household_sex === 2 ? '女' : '男'
      const res = await this.$API.household.addHousehold(data)
      console.log(res)
      if (res.code === 0) {
        this.$message({
          type: 'success',
          message: this.household.id ? '修改户口信息成功' : '添加户口信息成功'
        })
        this.getHouseholdData(this.household.id ? this.page : 1)
        this.dialogVisible = false
      } else {
        console.log('error submit!!')
        return false
      }
      console.log(this.household_relation)
      if (this.household_relation.length > this.household_relation_length) {
        /* eslint-disable */
        this.household_relation.forEach(async (item, i) => {
          let obj = {}
          obj.household_number = item.household_number
          obj.name = this.household_name1[i]
          obj.relation = this.household_relation1[i]
          // console.log('item', item)
          console.log('itemobj', obj)
          let res = await this.$API.household.addHouseholdRelation(obj)
          console.log(res)
          if (res.code === 0) {
            this.household_relation.push(res.result)
          } else {
            return Promise.reject(new Error('faile'))
          }
        })
      }
      this.$store.commit('addLength', this.household_relation.length)
      // this.household_relation_length = this.household_relation.length

      this.household = {
        household_number: '',
        household_name: '',
        household_sex: '',
        household_ID: '',
        household_birthday: '',
        household_phone: ''
      }
      this.household_relation = []
      this.household_name1 = []
      this.household_relation1 = []
    },
    handleCurrentChange(page) {
      console.log(page)
      this.page = page
      this.getHouseholdData(this.page, this.limit)
    },
    handleSizeChange(limit) {
      console.log(limit)

      this.limit = limit
      this.getHouseholdData(this.page, this.limit)
    },
    onChangeHouseholdName(value) {
      console.log('household_name', value)
      this.household_name1.push(value)
      // console.log('obj1', ...this.household_relation)
    },
    onChangeHouseholdRelation(value) {
      console.log('household_relation', value)
      this.household_relation1.push(value)
      // console.log('obj2', ...this.household_relation)
    },
    // 添加行
    addHouseholdRelation() {
      console.log('this.householdData', this.householdData)
      console.log('未添加数据', this.household_relation)
      // console.log('添加行', this.household.household_number)
      let circle = { household_name: '', household_relation: '' }

      if (circle !== null) {
        let newObj = {}

        // for (let k in circle) {
        //   newObj[k] = ''
        // }
        Object.assign(newObj, { household_name: circle.household_name })
        Object.assign(newObj, { household_relation: circle.household_relation })
        newObj.household_number = this.household.household_number
        console.log('newObj', newObj)
        console.log('原始household_relation数组长度', this.household_relation.length)
        console.log(this.household_relation)

        this.household_relation.splice(this.household_relation.length, 0, newObj)

        // this.household_relation.push(newObj)
        console.log('添加行后的household_relation数组长度', this.household_relation.length)
        console.log(this.household_relation)
      }
    },
    // 更新添加行
    updateHouseholdRelation() {
      let circle = { household_name: '', household_relation: '' }
      if (circle !== null) {
        let newObj = {}
        Object.assign(newObj, { household_name: circle.household_name })
        Object.assign(newObj, { household_relation: circle.household_relation })
        newObj.household_number = this.household.household_number
        this.household_relation.splice(this.household_relation.length, 0, newObj)
        this.update_household_relation.splice(this.update_household_relation.length, 0, newObj)
      }
    },
    // 选中户主关系的数组id
    handleHouseholdRelationChange(selection) {
      if (selection.length === 0) return
      this.batchRemoveRowInfo = [...selection]

      this.tempBatchRemoveRowLength = this.batchRemoveRowInfo.length
      this.selectedRelationIds = selection.map(item => item.id)

      console.log('this.selectedRelationIds', this.selectedRelationIds)
    },

    // 批量删除行
    confirmBatchRemoveRow() {
      console.log('this.batchRemoveRowInfo', this.batchRemoveRowInfo)
      this.batchRemoveRowInfo.forEach(rowInfo => {
        this.household_relation.forEach(relation => {
          if (relation.household_name === rowInfo.household_name) {
            this.household_relation.splice(this.household_relation.indexOf(relation), 1)
          }
        })
      })
    },
    // 确认批量删除行
    async confirmBatchRemove() {
      if (this.tempBatchRemoveRowLength !== 0) {
        const res = await this.$API.household.batchRemoveHouseholdRelation(this.selectedRelationIds)
        console.log(res)
      }
      if (this.household.id === undefined) {
        this.addConfirmHouseholdRelation()
      }

      this.selectedRelationIds = []
      this.batchRemoveRowInfo = []
      this.getHouseholdData(this.household.id ? this.page : 1)
      if (this.household.id) this.$message({ type: 'success', message: `修改户口信息成功` })
      this.dialogVisible = false
    },
    // 取消修改户口信息
    async cancelHousehold() {
      if (this.household.id) {
        this.$refs['household'].resetFields()
        console.log(this.$refs['household'].model)
        let id = this.$refs['household'].model.id
        let data = {
          household_number: this.$refs['household'].model.household_number,
          household_name: this.$refs['household'].model.household_name,
          household_sex: this.$refs['household'].model.household_sex,
          household_ID: this.$refs['household'].model.household_ID,
          household_birthday: this.$refs['household'].model.household_birthday,
          household_phone: this.$refs['household'].model.household_phone
        }
        let relationIds = []
        relationIds = this.$refs['household'].model.household_relation.map(item => item.id)
        await this.$API.household.updateHousehold(id, data)
        relationIds.forEach(async (relationId, i) => {
          let relationData = {
            household_number: this.$refs['household'].model.household_relation[i].household_number,
            name: this.$refs['household'].model.household_relation[i].name,
            relation: this.$refs['household'].model.household_relation[i].relation
          }
          await this.$API.household.updateHouseholdRelation(relationId, relationData)
          relationData = {}
        })
      }
      this.dialogVisible = false
      this.household = {
        household_number: '',
        household_name: '',
        household_sex: '',
        household_ID: '',
        household_birthday: '',
        household_phone: ''
      }
      this.$refs['household'].clearValidate()
      this.batchRemoveRowInfo = []
      this.selectedRelationIds = []
      this.selectedHouseholdIndexs = []
      this.deleteRowInfo = {}
      this.household_relation = []
      this.tempBatchRemoveRowLength = 0
    },
    // 修改户口信息
    updateHousehold(household, index) {
      this.dialogVisible = true
      console.log(household)
      this.selectedHouseholdIndexs = []
      this.selectedHouseholdIndexs.push(index)
      this.household = { ...household }
      console.log(this.household.household_relation)
      this.household_relation = []
      this.household.household_relation.forEach(item => {
        let obj = {}
        obj.id = item.id
        obj.household_number = item.household_number
        obj.household_name = item.name
        obj.household_relation = item.relation
        this.household_relation.push(obj)
        console.log('obj', obj)
      })
      // console.log(this.hosuehold_relation.length)
    },
    // 修改户主信息
    async update_household(e) {
      let label = null
      console.log(e)
      if (e.target !== undefined) {
        console.log('$event', e.target.parentNode.parentNode.parentNode.children[0].innerText)
        label = e.target.parentNode.parentNode.parentNode.children[0].innerText
      }
      console.log('label', label)
      if (typeof e === 'boolean') {
        label = '是否贫困'
      } else if (label === null) {
        label = '性别'
      } else {
        label = label
      }

      // 整理修改户主信息数据
      console.log('修改的户主信息', this.household)
      let id = this.household.id
      let data = {
        household_number: this.household.household_number,
        household_name: this.household.household_name,
        household_sex: this.household.household_sex === 2 ? '女' : '男',
        household_ID: this.household.household_ID,
        household_birthday: this.household.household_birthday,
        household_phone: this.household.household_phone,
        is_poor_household: this.household.is_poor_household
      }
      if (typeof data.is_poor_household === 'string') {
        this.dict_is_poor_household.forEach(item => {
          if (item.is_poor_household === data.is_poor_household) {
            data.is_poor_household = item.is
          }
        })
      }
      console.log('修改户主信息的id', id)
      console.log('整理修改户主的信息', data)
      const res = await this.$API.household.updateHousehold(id, data)
      // if (res.code === 0) {
      //   this.$message({ type: 'success', message: `修改${label}成功` })
      // }
    },

    // 修改户主关系姓名或关系信息
    async updateHouseholdNameOrRelation(e, relation, index) {
      console.log(
        this.householdData.forEach(item => {
          console.log('item.household_relation', item.household_relation)
        })
      )
      console.log(relation)
      console.log(relation.household_number)
      console.log(relation.household_name)
      console.log(relation.household_relation)
      console.log(this.household_relation[index])
      let data = {
        id: this.householdData[this.selectedHouseholdIndexs[0]].household_relation[index].id,
        data_relation: {
          household_number: relation.household_number,
          name: relation.household_name,
          relation: relation.household_relation
        }
      }
      console.log(data)

      const res = await this.$API.household.updateHouseholdRelation(data.id, data.data_relation)
      console.log('更新户主信息', res)
      // this.household_name1.push(relation.household_name)
      // this.household_relation1.push(relation.household_relation)
      // console.log(this.household_name1[index])
      // console.log(this.household_relation1[index])
      // if (relation.household_name === this.household_name1[index]) return
      console.log(e)
      console.log(index)
    },
    // 确认修改户主关系信息
    async updateConfirmHouseholdRelation(householdId) {
      this.$store.commit('addLength', this.household_relation_length)
      this.household_relation_length = this.$store.state.household.household_relation_length
      console.log('householdId', householdId)
      console.log('this.household_relation.length', this.household_relation.length)
      console.log('this.household_relation_length', this.household_relation_length)

      if (this.household_relation.length > this.household_relation_length && this.household_name1[0] !== undefined && this.household_relation1[0] !== undefined) {
        this.update_household_relation.forEach(async (item, i) => {
          let obj = {}
          obj.household_number = item.household_number
          obj.name = this.household_name1[i]
          obj.relation = this.household_relation1[i]
          // console.log('item', item)
          console.log('itemobj', obj)
          let res = await this.$API.household.addHouseholdRelation(obj)
          console.log('新增户主关系信息', res)
        })
      }
      this.$store.commit('addLength', this.household_relation_length)
      // this.household_relation_length = this.household_relation.length
      console.log('this.household_relation_length', this.household_relation_length)
      this.household = {
        household_number: '',
        household_name: '',
        household_sex: '',
        household_ID: '',
        household_birthday: '',
        household_phone: ''
      }
      this.household_relation = []
      this.update_household_relation = []
      this.household_name1 = []
      this.household_relation1 = []
      console.log('this.page', this.page)

      this.getHouseholdData(householdId ? this.page : 1)

      this.$message({ type: 'success', message: '修改户口信息成功' })
      this.dialogVisible = false
    },
    // 删除户口信息
    async removeHousehold(household) {
      console.log('删除户口信息', household)
      let id = household.id

      this.$confirm(`确定删除${household.household_number}的信息吗？`)
        .then(async () => {
          const res = await this.$API.household.deleteHouseholdInfo(id)
          if (res.code === 0) {
            this.$message.success('删除成功')
            this.getHouseholdData()
          }
        })
        .catch(() => {
          this.$message.info('取消删除')
        })
    },
    // 批量删除选中的户口信息
    handleSelectionChange(selection) {
      console.log('selection', selection)
      this.selectedIds = selection.map(item => item.id)
    },
    // 批量删除户口信息
    batchRemoveHousehold() {
      let ids = []
      this.selectedIds.forEach(id => ids.push(id))
      console.log('ids', ids)
      this.$confirm('确定删除吗？')
        .then(async () => {
          const res = await this.$API.household.batchRemoveHouseholdInfo(ids)
          if (res.code === 0) {
            this.$message.success('删除成功')
            this.getHouseholdData()
          }
        })
        .catch(err => {
          console.log(err)
          this.$message.info('取消删除')
        })
    }
  }
}
</script>

<style scoped>
.container {
  padding: 20px 20px;
}

.demo-table-expand {
  font-size: 0;
}
.demo-table-expand label {
  width: 90px;
  color: #99a9bf;
}
.demo-table-expand .el-form-item {
  margin-right: 0;
  margin-bottom: 0;
  width: 50%;
}
</style>
