<template>
  <div>个人中心</div>
</template>

<script>
export default {
  name: 'PersonalCenter'
}
</script>

<style scoped></style>
