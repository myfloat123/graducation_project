import request from '@/utils/request'

/* eslint-disable */
// 获取村民信息
export const getVillagerInfo = (page, limit) => request({ url: `/villagers`, method: 'get', params: { page, limit } })

// 获取一条村民信息
export const getOneVillagerInfo = params => request({ url: '/villagers/info', method: 'get', params })
// 获取多条村民信息
export const getMoreVillagerInfo = ({ villager_name, villager_ID_number, villager_phone }, page, limit) => request({ url: `/villagers/moreinfo?villager_name=${villager_name}&villager_ID_number=${villager_ID_number}&villager_phone=${villager_phone}&page=${page}&limit=${limit}`, method: 'get' })

// 新增或修改村民信息
export const addOrUpdateVillager = data => {
  // 存在id则修改村民信息
  if (data.id) {
    return request({ url: `/villagers/${data.id}`, method: 'put', data })
  } else {
    // 更新村民信息
    return request({ url: '/villagers/add', method: 'post', data })
  }
}

// 删除村民信息
export const removeVillager = id => request({ url: `/villagers/${id}/off`, method: 'post' })

// 批量删除村民信息
export const batchRemoveVillager = ids => request({ url: '/villagers/batchremove', method: 'post', data: ids })
