import * as user from './user'
import * as table from './table'
import * as villager from './villager'
import * as household from './household'
import * as relation from './relation'
import * as assistinfo from './assistinfo'
import * as assistplan from './assistplan'
import * as infrastructure from './infrastructure'
import * as resource from './resource'
import * as housebuild from './housebuild'
import * as finance from './finance'
import * as hygiene from './hygiene'
import * as land from './land'
import * as file from './file'

// 引入权限相关的接口文件
import * as useracl from './acl/user'
import role from './acl/role'
import permission from './acl/permission'
export default {
  user,
  table,
  villager,
  household,
  relation,
  assistinfo,
  assistplan,
  infrastructure,
  resource,
  housebuild,
  finance,
  hygiene,
  land,
  file,
  useracl,
  role,
  permission
}
