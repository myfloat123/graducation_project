<template>
  <div>
    <el-container class="container">
      <el-header>修改密码</el-header>
      <el-main>
        <el-form ref="ruleForm" :model="ruleForm" status-icon :rules="rules" label-width="100px" class="demo-ruleForm">
          <el-form-item label="原密码" prop="password1">
            <el-input v-model="ruleForm.password1" type="text" />
          </el-form-item>
          <el-form-item label="新密码" prop="password">
            <el-input v-model="ruleForm.password" type="password" autocomplete="off" />
          </el-form-item>
          <el-form-item label="确认密码" prop="checkPass">
            <el-input v-model="ruleForm.checkPass" type="password" autocomplete="off" />
          </el-form-item>

          <el-form-item class="button-footer">
            <el-button :loading="loading" type="primary" @click="submitForm('ruleForm')">提交</el-button>
            <el-button @click="resetForm('ruleForm')">重置</el-button>
          </el-form-item>
        </el-form>

        <!-- :before-close="dialogBeforeClose" -->
        <el-dialog ref="dialog" title="" :visible.sync="dialogVisible">
          <div id="divDialog" />
          <div v-show="false" slot="footer">
            <el-button @click="dialogVisible = false">取 消</el-button>
            <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
          </div>
        </el-dialog>
      </el-main>
    </el-container>
  </div>
</template>

<script>
import bcrypt from 'bcryptjs'
import { mapGetters } from 'vuex'
export default {
  data() {
    /* eslint-disable */
    // 校验原密码
    var checkPassword1 = async (rule, value, callback) => {
      if (!value) {
        return callback(new Error('原密码不能为空'))
      } else if (value !== '') {
        const res = await this.getUserInfo()
        // console.log(res)
        const flag = bcrypt.compareSync(this.ruleForm.password1, res.password)
        if (!flag) {
          callback(new Error('原密码不正确'))
        }
        callback()
      }
      // setTimeout(() => {
      //   if (!Number.isInteger(value)) {
      //     callback(new Error('请输入数字值'))
      //   } else {
      //     if (value < 4) {
      //       callback(new Error('密码长度不能小于4'))
      //     } else {
      //       callback()
      //     }
      //   }
      // }, 1000)
    }
    // 校验密码长度
    var validatePass = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入密码'))
      } else if (value.length < 6) {
        callback(new Error('密码长度不能小于6'))
      } else {
        callback()
      }
    }
    // 校验新密码和确认密码是否一致
    var validatePass2 = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请再次输入密码'))
      } else if (value !== this.ruleForm.password) {
        callback(new Error('两次输入密码不一致!'))
      } else {
        callback()
      }
    }
    return {
      ruleForm: {
        password1: '',
        password: '',
        checkPass: ''
      },
      rules: {
        password1: [{ validator: checkPassword1, trigger: 'blur' }],
        password: [{ validator: validatePass, trigger: 'blur' }],
        checkPass: [{ validator: validatePass2, trigger: 'blur' }]
      },
      loading: false,
      dialogVisible: false
    }
  },
  computed: {
    ...mapGetters(['sidebar', 'avatar'])
  },
  methods: {
    // 退出登录
    async logout() {
      this.loading = true
      await this.$store.dispatch('user/logout')
      this.$router.push(`/login?redirect=${this.$route.fullPath}`)
      this.loading = false
    },
    // 提交表单数据
    async submitForm(formName) {
      this.$refs[formName].validate(async valid => {
        if (valid) {
          const data = {
            password: this.ruleForm.checkPass
          }
          const result = await this.$API.user.updatePassword(data)
          console.log(result)

          this.$message({
            type: 'success',
            message: '修改密码成功'
          })
          setTimeout(this.logout, 1000)

          // alert('修改密码成功')
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    // 重置表单数据
    resetForm(formName) {
      this.$refs[formName].resetFields()
    },
    // 获取用户信息
    async getUserInfo() {
      const res = await this.$API.user.getInfo()
      if (res.code === 0) {
        return res.result
      } else {
        return Promise.reject(new Error('faile'))
      }
    }
  }
}
</script>

<style scoped>
.container {
  padding: 10px;
}
.el-header {
  width: 100%;
  border-radius: 5px 5px 0px 0px;
  background-color: #b3c0d1;
  color: #333;
  text-align: center;
  line-height: 60px;
}

.el-main {
  border-radius: 0px 0px 5px 5px;
  background-color: #fff;
  color: #333;
  text-align: center;
  /* line-height: 160px; */
}
</style>
