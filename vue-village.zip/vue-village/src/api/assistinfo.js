import request from '@/utils/request'

// 获取所有帮扶信息
/* eslint-disable */
export const getAssistinfo = (page, limit) => request({ url: '/assistinfo', method: 'get', params: { page, limit } })

// 获取某个帮扶信息接口
export const getOneAssistinfo = id => request({ url: `/assistinfo/${id}`, method: 'get' })

// 获取任意帮扶信息接口
export const getEveryAssistinfoData = (data, page, limit) => request({ url: `/assistinfo/moreinfo?page=${page}&limit=${limit}&recipient=${data.recipient}&executive_condition=${data.executive_condition}` })

// 新增帮扶信息接口
export const addAssistinfoData = data => request({ url: '/assistinfo/add', method: 'post', data })

// 修改帮扶信息
export const updateAssistinfo = (id, data) => request({ url: `/assistinfo/${id}`, method: 'put', data })

// 删除帮扶信息
export const deleteAssistinfo = id => request({ url: `/assistinfo/${id}/off`, method: 'post' })

// 批量删除帮扶信息接口
export const batchRemoveAssistinfo = ids => request({ url: `/assistinfo/batchremove`, method: 'post', data: ids })
