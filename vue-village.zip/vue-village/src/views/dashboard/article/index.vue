<template>
  <div class="container">
    <div id="article-container">
      <div id="before" />
      <pre>{{ articleData1 }}</pre>
      <div id="after" />
    </div>
  </div>
</template>

<script>
import { mapState } from 'vuex'
export default {
  name: 'Article',
  computed: {
    ...mapState({
      articleData1: state => state.article.articleData1
    })
  },
  data() {
    return {
      articleData: ''
    }
  },
  created() {
    console.log('article组件------------------------------')
    console.log(this.articleData1)
  }
}
</script>

<style scoped>
#app {
  height: 100vh;
}
#article-container {
  display: flex;
  justify-content: space-around;
}

/* #before {
  width: 509px;
  height: 100vh;
  background-color: #f2f6fc;
  z-index: 99;
}
#after {
  width: 509px;
  height: 100vh;
  background-color: #f2f6fc;
  z-index: 99;
} */
pre {
  /* position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, 50%); */
  /* padding: 10px 500px; */
  /* width: 100%;
  height: 100%; */
  width: 500px;
  margin: 0px auto;
  padding: 20px 0px;
  white-space: pre-wrap;
  word-wrap: break-word;
}
</style>
