<template>
  <div class="container">
    <el-form inline style="margin-top: 20px">
      <!-- 表单元素 -->
      <el-form-item>
        <el-input v-model="tempSearchObj.housebuild_code" placeholder="房屋建筑编号" />
      </el-form-item>
      <el-form-item>
        <el-input v-model="tempSearchObj.villager_name" placeholder="村民" />
      </el-form-item>
      <!-- 查询与清空按钮 -->
      <!--  -->
      <!--  -->
      <el-button type="primary" icon="el-icon-search" @click="search">查询</el-button>
      <el-button type="default" @click="resetSearch">清空</el-button>
    </el-form>

    <div style="margin-bottom: 20px">
      <!-- 添加与批量删除按钮 -->
      <el-button type="primary" icon="el-icon-plus" @click="showAddHousebuild">添加</el-button>
      <el-button type="danger" icon="el-icon-delete" :disabled="selectedIds.length === 0" @click="batchRemove">批量删除</el-button>
    </div>

    <!-- table表格：展示房屋建筑信息 -->
    <!--  -->
    <el-table v-loading="listLoading" border stripe :data="pageList" style="width: 100%" @selection-change="handleSelectionChange">
      <el-table-column type="selection" />
      <el-table-column type="index" label="序号" align="center" />
      <el-table-column header-align="center" align="center" prop="housebuild_code" label="房屋建筑编号" />
      <el-table-column header-align="center" align="center" prop="villager_name" label="村民" />
      <el-table-column header-align="center" align="center" prop="createdAt" label="发布时间" />
      <el-table-column header-align="center" align="center" prop="have_or_not_safety_danger" label="有无安全隐患">
        <template slot-scope="{ row }">
          <el-tag :type="have_or_not_safety_danger_tag(row)" disable-transitions>{{ row.have_or_not_safety_danger }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column header-align="center" align="center" prop="have_or_not_violate_build" label="有无违规建筑">
        <template slot-scope="{ row }">
          <el-tag :type="have_or_not_violate_build_tag(row)" disable-transitions>{{ row.have_or_not_violate_build }}</el-tag>
        </template>
      </el-table-column>

      <el-table-column label="操作" align="center" width="400">
        <template slot-scope="{ row }">
          <el-button type="info" icon="el-icon-info" size="mini" @click="showHousebuildDetail(row)">查看</el-button>
          <el-button type="warning" icon="el-icon-edit" size="mini" @click="showUpdateHousebuild(row)">修改</el-button>
          <el-button type="danger" icon="el-icon-delete" size="mini" @click="removeHousebuild(row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页器 -->
    <el-pagination style="margin-top: 20px; text-align: center" :current-page="page" :page-sizes="[3, 5, 10]" :page-count="7" :page-size.sync="limit" layout="prev, pager, next, jumper, ->, sizes, total" :total="total" @current-change="handleCurrentChange" @size-change="handleSizeChange" />

    <!-- 房屋建筑信息弹窗 -->
    <el-dialog :title="housebuild.id ? '修改房屋建筑信息' : '添加房屋建筑信息'" :visible.sync="dialogVisible" :before-close="dialogBeforeClose">
      <el-form ref="housebuildForm" :model="housebuild" label-width="120px" :rules="housebuildRules">
        <el-form-item label="房屋建筑编号" prop="housebuild_code" style="width: 400px">
          <el-input v-model="housebuild.housebuild_code" :disabled="disabled_housebuild ? true : false" />
        </el-form-item>
        <el-form-item label="村民" prop="villager_name" style="width: 400px">
          <el-input v-model="housebuild.villager_name" :disabled="disabled_housebuild ? true : false" />
        </el-form-item>
        <el-form-item v-show="housebuild.id" label="发布时间" prop="createdAt" style="width: 400px">
          <el-input v-model="housebuild.createdAt" :disabled="true" />
        </el-form-item>
        <el-form-item v-show="housebuild.createdAt !== housebuild.updatedAt" label="修改时间" prop="updatedAt" style="width: 400px">
          <el-input v-model="housebuild.updatedAt" :disabled="true" />
        </el-form-item>
        <el-form-item label="有无安全隐患" prop="have_or_not_safety_danger">
          <el-select v-model="housebuild.have_or_not_safety_danger" :disabled="disabled_housebuild ? true : false">
            <el-option v-for="item in dict_have_or_not" :key="item.id" :label="item.have_or_not" :value="item.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="有无违规建筑" prop="have_or_not_violate_build">
          <el-select v-model="housebuild.have_or_not_violate_build" :disabled="disabled_housebuild ? true : false">
            <el-option v-for="item in dict_have_or_not" :key="item.id" :label="item.have_or_not" :value="item.id" />
          </el-select>
        </el-form-item>
      </el-form>
      <div v-show="!disabled_housebuild" slot="footer">
        <el-button @click="cancel">取 消</el-button>
        <el-button type="primary" @click="housebuild.id ? updateHousebuild() : addHousebuild()">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import dayjs from 'dayjs'
export default {
  name: 'House',
  data() {
    return {
      // 所有选择的housebuild的id数组
      selectedIds: [],
      // 房屋建筑信息列表
      list: [],
      // 每页房屋建筑信息列表
      pageList: [],
      // 是否显示列表加载的提示
      listLoading: false,
      // 当前页码
      page: 1,
      // 每页数量
      limit: 3,
      // 总数
      total: 0,
      // 是否显示弹窗
      dialogVisible: false,
      // 是否查看房屋建筑信息
      disabled_housebuild: false,
      // 收集搜索条件输入的对象
      tempSearchObj: {
        housebuild_code: '',
        villager_name: ''
      },
      // 包含请求搜索条件数据的对象
      searchObj: {
        housebuild_code: '',
        villager_name: ''
      },
      // 当前操作的房屋建筑信息对象
      housebuild: {
        housebuild_code: '',
        villager_name: '',
        have_or_not_safety_danger: '',
        have_or_not_violate_build: ''
      },
      // 房屋建筑信息验证规则
      housebuildRules: {
        housebuild_code: [{ required: true, message: '请输入房屋建筑编号', trigger: 'blur' }],
        villager_name: [{ required: true, message: '请输入村民', trigger: 'blur' }],
        have_or_not_safety_danger: [{ required: true, message: '请选择有无安全隐患', trigger: 'blur' }],
        have_or_not_violate_build: [{ required: true, message: '请选择有无违规建筑', trigger: 'blur' }]
      },
      // 有无字典
      dict_have_or_not: [
        { id: 1, have_or_not: '有' },
        { id: 2, have_or_not: '无' }
      ]
    }
  },
  mounted() {
    this.getHousebuildData()
  },
  methods: {
    // 获取房屋建筑信息
    async getHousebuildData(page = 1, limit = 3, searchObj = { housebuild_code: '', villager_name: '' }) {
      this.page = page
      this.limit = limit
      this.searchObj = searchObj
      this.listLoading = true
      let params = { page, limit, ...searchObj }
      const res = await this.$API.housebuild.getHousebuildInfo(params)
      this.listLoading = false
      console.log(res)
      if (res.code === 0) {
        res.result.pageList.forEach(housebuild => {
          this.dict_have_or_not.forEach(item => {
            if (item.id === housebuild.have_or_not_safety_danger) {
              housebuild.have_or_not_safety_danger = item.have_or_not
            }
          })
          this.dict_have_or_not.forEach(item => {
            if (item.id === housebuild.have_or_not_violate_build) {
              housebuild.have_or_not_violate_build = item.have_or_not
            }
          })
          housebuild.createdAt = dayjs(housebuild.createdAt).format('YYYY-MM-DD HH:mm:ss')
          housebuild.updatedAt = dayjs(housebuild.updatedAt).format('YYYY-MM-DD HH:mm:ss')
        })

        this.pageList = res.result.pageList
        this.list = res.result.list
        this.total = res.result.total
      }
    },
    // 有无安全隐患tag标签
    have_or_not_safety_danger_tag(housebuild) {
      if (housebuild.have_or_not_safety_danger === '有') {
        return 'danger'
      } else {
        return 'success'
      }
    },
    // 有无违规建筑tag标签
    have_or_not_violate_build_tag(housebuild) {
      if (housebuild.have_or_not_violate_build === '有') {
        return 'danger'
      } else {
        return 'success'
      }
    },
    // 关闭弹窗之前的处理函数
    dialogBeforeClose(done) {
      this.$confirm('确认关闭？')
        .then(_ => {
          done()
          this.housebuild = {
            housebuild_code: '',
            villager_name: '',
            have_or_not_safety_danger: '',
            have_or_not_violate_build: ''
          }
          this.disabled_housebuild = false
          this.$refs['housebuildForm'].clearValidate()
        })
        .catch(_ => {
          console.log(_)
        })
    },
    // 查看房屋建筑信息详情
    showHousebuildDetail(housebuild) {
      this.dialogVisible = true
      this.disabled_housebuild = true
      this.housebuild = { ...housebuild }
    },
    // 搜索房屋建筑信息
    search() {
      this.searchObj = { ...this.tempSearchObj }
      this.getHousebuildData(this.page, this.limit, this.searchObj)
    },
    // 清空
    resetSearch() {
      this.tempSearchObj = {
        housebuild_code: '',
        villager_name: ''
      }
      this.searchObj = {
        housebuild_code: '',
        villager_name: ''
      }
      this.getHousebuildData()
    },
    // 显示修改房屋建筑信息弹窗
    showUpdateHousebuild(housebuild) {
      this.dialogVisible = true
      this.housebuild = { ...housebuild }
    },
    // 更新房屋建筑信息
    async updateHousebuild() {
      let data = {
        housebuild_code: this.housebuild.housebuild_code,
        villager_name: this.housebuild.villager_name,
        have_or_not_safety_danger: this.housebuild.have_or_not_safety_danger,
        have_or_not_violate_build: this.housebuild.have_or_not_violate_build
      }
      typeof data.have_or_not_safety_danger === 'string' && (data.have_or_not_safety_danger = data.have_or_not_safety_danger === '无' ? 2 : 1)
      typeof data.have_or_not_violate_build === 'string' && (data.have_or_not_violate_build = data.have_or_not_violate_build === '无' ? 2 : 1)
      const res = await this.$API.housebuild.updateHousebuildInfo(this.housebuild.id, data)
      if (res.code === 0) {
        this.$message({
          type: 'success',
          message: '更新成功'
        })
      }
      this.housebuild = {
        housebuild_code: '',
        villager_name: '',
        have_or_not_safety_danger: '',
        have_or_not_violate_build: ''
      }
      this.getHousebuildData(this.page)
      this.dialogVisible = false
    },
    // 取消
    cancel() {
      this.$refs['housebuildForm'].clearValidate()
      this.housebuild = {
        housebuild_code: '',
        villager_name: '',
        have_or_not_safety_danger: '',
        have_or_not_violate_build: ''
      }
      this.dialogVisible = false
      this.disabled_housebuild = false
    },
    // 显示添加房屋建筑信息弹窗
    showAddHousebuild() {
      this.dialogVisible = true
      this.housebuild.housebuild_code = 'FWJZ' + `${+new Date()}`.slice(-4) || ''
    },
    // 添加房屋建筑信息
    addHousebuild() {
      this.$refs['housebuildForm'].validate(async valid => {
        if (valid) {
          const res = await this.$API.housebuild.addHousebuildInfo(this.housebuild)
          if (res.code === 0) {
            this.$message({
              type: 'success',
              message: '新增房屋建筑信息成功'
            })
            this.total = this.total + 1
            this.dialogVisible = false
            this.getHousebuildData(this.housebuild.id ? this.page : 1, this.limit, this.searchObj)
            this.housebuild = {
              housebuild_code: '',
              villager_name: '',
              have_or_not_safety_danger: '',
              have_or_not_violate_build: ''
            }
          } else {
            console.log('error submit!!')
            return false
          }
        }
      })
      this.dialogVisible = false
    },
    // 选中的数据
    handleSelectionChange(selection) {
      this.selectedIds = selection.map(item => item.id)
    },
    // 删除房屋建筑信息
    removeHousebuild(housebuild) {
      this.$confirm(`确定删除${housebuild.housebuild_code}的信息？`, '提示', {
        confirmButtonClass: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(async () => {
          const res = await this.$API.housebuild.removeHousebuildInfo(housebuild.id)
          if (res.code === 0) {
            this.$message({
              type: 'success',
              message: '删除成功'
            })
            this.getHousebuildData(this.pageList.length > 1 ? this.page : (this.page = this.page - 1), this.limit, this.searchObj)
          }
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
    },
    // 批量删除
    batchRemove() {
      this.$confirm('确定删除吗？')
        .then(async () => {
          const res = await this.$API.housebuild.batchRemoveHousebuildInfo(this.selectedIds)
          if (res.code === 0) {
            this.$message.success('删除成功')
            this.getHousebuildData(this.page, this.limit, this.searchObj)
          }
        })
        .catch(err => {
          console.log(err)
          this.$message.info('取消删除')
        })
    },
    // 处理当前页变化
    handleCurrentChange(page) {
      this.page = page
      this.getHousebuildData(this.page, this.limit, this.searchObj)
    },
    // 处理每页显示数目变化
    handleSizeChange(limit) {
      this.limit = limit
      this.getHousebuildData(this.page, this.limit, this.searchObj)
    }
  }
}
</script>

<style scoped>
.container {
  padding: 0px 20px;
}

>>> .el-textarea.is-disabled .el-textarea__inner {
  background-color: #fff;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  color: #606266;
}

>>> .el-input.is-disabled .el-input__inner {
  background-color: #fff;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  color: #606266;
}
</style>
