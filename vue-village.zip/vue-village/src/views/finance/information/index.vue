<template>
  <div v-cloak class="container">
    <el-form inline style="margin-top: 20px">
      <!-- 表单元素 -->
      <el-form-item>
        <el-input v-model="tempSearchObj.finance_code" placeholder="财务编号" />
      </el-form-item>
      <el-form-item>
        <el-select v-model="tempSearchObj.finance_type" placeholder="类型">
          <el-option v-for="item in dict_finance_type" :key="item.id" :label="item.finance_type" :value="item.id" />
        </el-select>
      </el-form-item>
      <!-- 查询与清空按钮 -->
      <!-- @click="search" -->
      <!-- @click="resetSearch" -->
      <el-button type="primary" icon="el-icon-search" @click="search">查询</el-button>
      <el-button type="default" @click="resetSearch">清空</el-button>
    </el-form>

    <div style="margin-bottom: 20px">
      <!-- 添加与批量删除按钮 -->
      <el-button type="primary" icon="el-icon-plus" @click="showAddFinance">添加</el-button>
      <el-button type="danger" icon="el-icon-delete" :disabled="selectedIds.length === 0" @click="batchRemove">批量删除</el-button>
      <el-button type="primary" icon="el-icon-download" plain @click="download">下载Excel模板</el-button>
      <el-button type="primary" icon="el-icon-sort-down" plain @click="lead">导入</el-button>
      <input id="lead" type="file" style="display: none" />
      <el-button type="primary" icon="el-icon-sort-up" plain style="margin-left: 10px" @click="derive">导出</el-button>
    </div>

    <!-- table表格：展示财务信息 -->
    <el-table v-loading="listLoading" border stripe :data="pageList" style="width: 100%" @selection-change="handleSelectionChange">
      <el-table-column type="selection" />
      <el-table-column type="index" label="序号" align="center" width="55" />
      <el-table-column header-align="center" align="center" prop="finance_code" label="财务编号" width="170" />
      <el-table-column header-align="center" align="center" prop="finance_type" label="类型" width="150" />
      <el-table-column header-align="center" align="center" prop="finance_money" label="金额" width="150" />
      <el-table-column header-align="center" align="center" prop="finance_explain" label="说明" width="200" />
      <el-table-column header-align="center" align="center" prop="createdAt" label="创建时间" width="200" />
      <el-table-column header-align="center" align="center" prop="prop" label="操作" width="400" fixed="right">
        <template slot-scope="{ row }">
          <el-button type="info" icon="el-icon-info" size="mini" @click="showFinanceDetail(row)">查看</el-button>
          <el-button type="warning" icon="el-icon-edit" size="mini" @click="showUpdateFinance(row)">修改</el-button>
          <el-button type="danger" icon="el-icon-delete" size="mini" @click="removeFinance(row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页器 -->
    <!--  -->
    <!--  -->
    <el-pagination style="margin-top: 20px; text-align: center" :current-page="page" :page-sizes="[3, 5, 10]" :page-count="7" :page-size.sync="limit" layout="prev, pager, next, jumper, ->, sizes, total" :total="total" @current-change="handleCurrentChange" @size-change="handleSizeChange" />

    <!-- 财务信息弹窗 -->
    <!-- :before-close="dialogBeforeClose" -->
    <el-dialog :title="finance.id ? `${disabled_finance ? '查看' : '修改'}财务信息` : '添加财务信息'" :visible.sync="dialogVisible" :before-close="dialogBeforeClose">
      <el-form ref="financeForm" :model="finance" inline :rules="financeRules">
        <el-form-item label="财务编号" prop="finance_code">
          <el-input v-model="finance.finance_code" style="width: 200px" :disabled="disabled_finance ? true : false" />
        </el-form-item>
        <el-form-item label="类型" prop="finance_type" label-width="80px">
          <el-select v-model="finance.finance_type" :disabled="disabled_finance ? true : false">
            <el-option v-for="item in dict_finance_type" :key="item.id" :label="item.finance_type" :value="item.id" />
          </el-select>
        </el-form-item>

        <div class="finance-money">
          <el-form-item label="金额" prop="finance_money" label-width="80px">
            <el-input v-model="finance.finance_money" :disabled="disabled_finance ? true : false" />
          </el-form-item>
          <el-form-item prop="finance_money_unit" style="width: 110px">
            <el-select v-model="finance.finance_money_unit" placeholder="单位" style="width: 80px" :disabled="disabled_finance ? true : false">
              <el-option v-for="item in dict_finance_money_unit" :key="item.id" :label="item.finance_money_unit" :value="item.id" />
            </el-select>
          </el-form-item>
        </div>

        <el-form-item v-show="finance.id" label="创建时间" prop="createdAt">
          <el-input v-model="finance.createdAt" disabled />
        </el-form-item>
        <el-form-item v-show="finance.updatedAt !== finance.createdAt" label="更新时间" prop="updatedAt" label-width="100px">
          <el-input v-model="finance.updatedAt" disabled />
        </el-form-item>
        <el-form-item label="说明" prop="finance_explain" label-width="60px">
          <el-input v-model="finance.finance_explain" type="textarea" :autosize="{ minRows: 5, maxRows: 10 }" :cols="100" :disabled="disabled_finance ? true : false" />
        </el-form-item>
      </el-form>
      <div v-show="!disabled_finance" slot="footer">
        <el-button @click="cancel">取 消</el-button>
        <el-button type="primary" @click="finance.id ? updateFinance() : addFinance()">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import axios from 'axios'
import dayjs from 'dayjs'
export default {
  name: 'Information',
  data() {
    return {
      // 当前页码
      page: 1,
      // 每页数量
      limit: 3,
      // 总数
      total: 0,
      // 是否显示列表加载的提示
      listLoading: false,
      // 选择的财务信息id数组
      selectedIds: [],
      // 每页财务信息列表
      pageList: [],
      // 财务信息列表
      list: [],
      // 是否显示弹窗
      dialogVisible: false,
      // 是否查财务信息
      disabled_finance: false,
      // 收集搜索条件输入的对象
      tempSearchObj: {
        finance_code: '',
        finance_type: ''
      },
      // 包含请求搜索条件数据的对象
      searchObj: {
        finance_code: '',
        finance_type: ''
      },
      // 当前操作的财务信息对象
      finance: {
        finance_code: '',
        finance_type: '',
        finance_money: '',
        finance_money_unit: '',
        finance_explain: ''
      },
      // 财务类型字典
      dict_finance_type: [
        { id: 1, finance_type: '收入' },
        { id: 2, finance_type: '支出' }
      ],
      // 金额单位
      dict_finance_money_unit: [
        { id: 1, finance_money_unit: '万' },
        { id: 2, finance_money_unit: '十万' },
        { id: 3, finance_money_unit: '百万' },
        { id: 4, finance_money_unit: '千万' },
        { id: 5, finance_money_unit: '亿' }
      ],
      // 财务信息验证规则
      financeRules: {
        finance_code: [{ required: true, message: '请输入财务编号', trigger: 'blur' }],
        finance_type: [{ required: true, message: '请选择类型', trigger: 'blur' }],
        finance_money: [{ required: true, message: '请输入金额', trigger: 'blur' }],
        finance_money_unit: [{ required: true, message: '请选择单位', trigger: 'blur' }],
        finance_explain: [{ required: false, message: '请填写说明', trigger: 'blur' }]
      }
    }
  },
  mounted() {
    this.getFinanceData().then(() => {
      // 移除 v-cloak 指令
      this.$el.removeAttribute('v-cloak')
    })
  },
  methods: {
    async getFinanceData(page = 1, limit = 3, searchObj = { finance_code: '', finance_type: '' }) {
      this.page = page
      this.limit = limit
      this.searchObj = searchObj
      this.listLoading = true
      let params = { page, limit, ...searchObj }
      const res = await this.$API.finance.getFinanceInfo(params)
      this.listLoading = false
      console.log(res)
      if (res.code === 0) {
        res.result.pageList.forEach(finance => {
          finance.createdAt = dayjs(finance.createdAt).format('YYYY-MM-DD HH:mm:ss')
          finance.updatedAt = dayjs(finance.updatedAt).format('YYYY-MM-DD HH:mm:ss')
          this.dict_finance_type.forEach(item => {
            if (item.id === finance.finance_type) {
              finance.finance_type = item.finance_type
            }
          })
        })
        res.result.list.forEach(finance => {
          finance.createdAt = dayjs(finance.createdAt).format('YYYY-MM-DD HH:mm:ss')
          finance.updatedAt = dayjs(finance.updatedAt).format('YYYY-MM-DD HH:mm:ss')
          this.dict_finance_type.forEach(item => {
            if (item.id === finance.finance_type) {
              finance.finance_type = item.finance_type
            }
          })
        })
        this.pageList = res.result.pageList
        this.list = res.result.list
        this.total = res.result.total
      }
    },
    // 显示修改财务信息弹窗
    showUpdateFinance(finance) {
      this.dialogVisible = true
      this.finance = { ...finance }
    },
    // 修改财务信息
    async updateFinance() {
      let id = this.finance.id
      let data = {
        finance_code: this.finance.finance_code,
        finance_type: this.finance.finance_type,
        finance_money: this.finance.finance_money,
        finance_money_unit: this.finance.finance_money_unit,
        finance_explain: this.finance.finance_explain
      }

      if (typeof data.finance_type === 'string') {
        this.dict_finance_type.forEach(item => {
          if (item.finance_type === data.finance_type) {
            data.finance_type = item.id
          }
        })
      }
      if (typeof data.finance_money_unit === 'string') {
        this.dict_finance_money_unit.forEach(item => {
          if (item.finance_money_unit === data.finance_money_unit) {
            data.finance_money_unit = item.id
          }
        })
      }

      const res = await this.$API.finance.updateFinanceInfo(id, data)
      if (res.code === 0) {
        this.$message({
          type: 'success',
          message: '更新成功'
        })
        this.finance = {
          finance_code: '',
          finance_type: '',
          finance_money: '',
          finance_money_unit: '',
          finance_explain: ''
        }
        this.getFinanceData(this.page)
        this.dialogVisible = false
      }
    },
    // 查看财务信息详情
    async showFinanceDetail(finance) {
      this.dialogVisible = true
      this.disabled_finance = true
      this.finance = { ...finance }
    },
    // 取消
    cancel() {
      this.finance = {
        finance_code: '',
        finance_type: '',
        finance_money: '',
        finance_money_unit: '',
        finance_explain: ''
      }
      this.dialogVisible = false
      this.disabled_finance = false
      this.$refs['financeForm'].clearValidate()
    },
    // 关闭弹窗之前的处理函数
    dialogBeforeClose(done) {
      this.$confirm('确认关闭？')
        .then(_ => {
          done()
          this.finance = {
            finance_code: '',
            finance_type: '',
            finance_money: '',
            finance_money_unit: '',
            finance_explain: ''
          }
          this.disabled_finance = false
          this.$refs['financeForm'].clearValidate()
        })
        .catch(_ => {
          console.log(_)
        })
    },
    // 显示新增财务信息的弹窗
    showAddFinance() {
      this.dialogVisible = true
      this.finance.finance_code = 'CW' + `${+new Date()}`.slice(-4) || ''
    },
    // 新增财务信息
    addFinance() {
      this.$refs['financeForm'].validate(async valid => {
        if (valid) {
          const res = await this.$API.finance.addFinanceInfo(this.finance)
          if (res.code === 0) {
            this.$message({
              type: 'success',
              message: '新增财务信息成功'
            })
            this.total = this.total + 1
            this.dialogVisible = false
            // (this.page = Math.ceil(this.total / this.limit))
            this.getFinanceData(this.finance.id ? this.page : 1, this.limit, this.searchObj)
            this.finance = {
              finance_code: '',
              finance_type: '',
              finance_money: '',
              finance_money_unit: '',
              finance_explain: ''
            }
          } else {
            console.log('error submit!!')
            return false
          }
        }
        this.dialogVisible = false
      })
    },
    // 删除财务信息
    removeFinance(finance) {
      this.$confirm(`确定删除${finance.finance_code}的信息？`, '提示', {
        confirmButtonClass: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(async () => {
          const res = await this.$API.finance.removeFinanceInfo(finance.id)
          if (res.code === 0) {
            this.$message({
              type: 'success',
              message: '删除成功'
            })
            this.getFinanceData(this.pageList.length > 1 ? this.page : (this.page = this.page - 1), this.limit, this.searchObj)
          }
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
    },
    // 查询财务信息
    search() {
      this.searchObj = { ...this.tempSearchObj }
      this.getFinanceData(this.page, this.limit, this.searchObj)
    },
    // 清空
    resetSearch() {
      this.searchObj = {
        finance_code: '',
        finance_type: ''
      }
      this.tempSearchObj = {
        finance_code: '',
        finance_type: ''
      }
      this.getFinanceData()
    },
    // 处理当前页变化
    handleCurrentChange(page) {
      this.page = page
      this.getFinanceData(this.page, this.limit, this.searchObj)
    },
    // 处理每页显示数目变化
    handleSizeChange(limit) {
      this.limit = limit
      this.getFinanceData(this.page, this.limit, this.searchObj)
    },
    // 下载Excel表格模板
    async download() {
      axios
        .get('http://localhost:8000/finance/download', {
          params: {
            fields: '财务编号,类型,金额,单位,说明'
          },
          responseType: 'arraybuffer'
        })
        .then(response => {
          // 将响应的二进制数据转换为Blob对象
          const blob = new Blob([response.data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })

          // 创建一个链接，用于下载文件
          const link = document.createElement('a')
          link.href = URL.createObjectURL(blob)
          link.download = 'finance_lead.xlsx'

          // 模拟点击下载链接
          link.click()

          // 释放URL对象占用的内存
          URL.revokeObjectURL(link.href)
        })
        .catch(error => {
          console.error(error)
        })
    },
    // 导入Excel表格信息
    lead() {
      const _this = this
      const lead = document.querySelector('#lead')
      lead.click()

      // 定义导入Excel表格的函数
      async function importExcel() {
        // console.log(lead)
        const file = lead.files[0]
        console.log(file)
        // 创建 FormData 实例
        const formData = new FormData()
        // 调用append函数，向formData中追加数据
        formData.append('file', file)
        const response = await _this.$API.finance.leadFinanceInfo(formData)
        console.log(response)
        if (response.code === 0) {
          _this.$message({
            type: 'success',
            message: response.message
          })
          _this.getFinanceData(_this.page, _this.limit, _this.searchObj)
          // setTimeout(window.location.reload(), 1000)
        } else {
          _this.$message({
            type: 'error',
            message: '文件上传失败'
          })
        }
      }
      lead.addEventListener('change', importExcel)
    },
    // 导出Excel表格信息
    async derive() {
      // 向导出接口发请求
      const response = await axios.get(`http://localhost:8000/finance/derive`, { responseType: 'blob' })
      console.log(response)
      // 创建链接用于下载文件
      const url = window.URL.createObjectURL(new Blob([response.data]))
      console.log(response.data)
      console.log(url)
      // 创建a标签
      const link = document.createElement('a')
      link.href = url
      // 设置download属性
      link.setAttribute('download', 'finance_derive.xlsx')
      // 将链接放入到body标签
      document.body.appendChild(link)
      // 模拟链接点击下载
      link.click()
      // 释放URL对象占用的内存
      window.URL.revokeObjectURL(link.href)
    },
    // 选中的数据
    handleSelectionChange(selection) {
      this.selectedIds = selection.map(item => item.id)
    },
    // 批量删除财务信息
    batchRemove() {
      this.$confirm('确定删除吗？')
        .then(async () => {
          const res = await this.$API.finance.batchRemoveFinanceInfo(this.selectedIds)
          if (res.code === 0) {
            this.$message.success('删除成功')
            this.getFinanceData(this.page, this.limit, this.searchObj)
          }
        })
        .catch(err => {
          console.log(err)
          this.$message.info('取消删除')
        })
    }
  }
}
</script>

<style scoped>
.container {
  padding: 0px 20px;
}

.finance-money {
  display: flex;
  display: inline-block;
}

.finance-money .el-form-item {
  margin-right: 0px;
}

>>> .el-textarea.is-disabled .el-textarea__inner {
  background-color: #fff;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  color: #606266;
}

>>> .el-input.is-disabled .el-input__inner {
  background-color: #fff;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  color: #606266;
}

[v-cloak] {
  display: none;
}
</style>
