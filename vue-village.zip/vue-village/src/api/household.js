import request from '@/utils/request'

/* eslint-disable */
// 获取所有户口信息
export const getHouseholdInfo = (page, limit) => request({ url: '/household', method: 'get', params: { page, limit } })

// 获取每户信息
export const getMoreHouseholdInfo = ({ household_number, household_name }, page, limit) => request({ url: `/household/moreinfo?page=${page}&limit=${limit}&household_number=${household_number}&household_name=${household_name}` })

// 新增每户信息
export const addHousehold = data => request({ url: '/household/add', method: 'post', data })

// 修改户主信息
export const updateHousehold = (id, data) => request({ url: `/household/${id}`, method: 'put', data })

// 删除户口信息
export const deleteHouseholdInfo = (id) => request({ url: `/household/${id}/off`, method: 'post' })

// 批量删除户口信息
export const batchRemoveHouseholdInfo = (ids) => request({ url: '/household/batchremove', method: 'post', data: ids })

// 新增户主关系信息
export const addHouseholdRelation = data => request({ url: '/relation/add', method: 'post', data })

// 修改户主关系信息
export const updateHouseholdRelation = (id, data) => request({ url: `/relation/${id}`, method: 'put', data })

// 删除户主关系信息
export const removeHouseholdRelation = (id) => request({ url: `/relation/${id}/off`, method: 'post' })

// 批量删除户主关系信息
export const batchRemoveHouseholdRelation = (ids) => request({ url: '/relation/batchremove', method: 'post', data: ids })

// 获取贫困家庭信息
export const getHouseholdPoorInfo = (params) => request({ url: `/household/poor`, method: 'get', params })

// 补丁修改是否贫困
export const patchUpdateHouseholdPoor = (id, data) => request({ url: `/household/poor/${id}`, method: 'patch', data })

// 获取脱困家庭信息
export const getHouseholdNotPoorInfo = (params) => request({ url: `/household/notpoor`, method: 'get', params })
