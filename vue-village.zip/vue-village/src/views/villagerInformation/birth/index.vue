<template>
  <div>
    <el-card class="box-card" style="margin: 10px 0px">
      <div slot="header" class="clearfix">
        <!-- 头部左侧内容 -->
        <el-tabs v-model="activeName" @tab-click="handleClick">
          <el-tab-pane label="用户管理" name="first">用户管理</el-tab-pane>
          <el-tab-pane label="配置管理" name="second">配置管理</el-tab-pane>
          <el-tab-pane label="角色管理" name="third">角色管理</el-tab-pane>
          <el-tab-pane label="定时任务补偿" name="fourth">定时任务补偿</el-tab-pane>
        </el-tabs>

        <div ref="charts" class="charts" />
      </div>
    </el-card>
    <el-card class="footer-left" />
    <el-card class="footer-right" />
  </div>
</template>

<script>
import * as echarts from 'echarts'
export default {
  name: 'Birth',
  data() {
    return {
      mycharts: null,
      date: [],
      option: {
        xAxis: {
          data: ['A', 'B', 'C', 'D', 'E']
        },
        yAxis: {},
        series: [
          {
            data: [10, 22, 28, 43, 49],
            type: 'line',
            stack: 'x',
            areaStyle: {}
          },
          {
            data: [5, 4, 3, 5, 10],
            type: 'line',
            stack: 'x',
            areaStyle: {}
          }
        ]
      }
    }
  },
  watch: {
    listState() {
      this.mycharts.setOption(this.option)
    }
  },
  mounted() {
    this.mycharts = echarts.init(this.$refs.charts)
  }
}
</script>

<style scoped></style>
