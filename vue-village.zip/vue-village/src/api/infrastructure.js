import request from '@/utils/request'

/* eslint-disable */
// 获取所有基础设施信息
export const getInfrastructureInfo = (page, limit) => request({ url: '/infrastructure', method: 'get', params: { page, limit } })

// 修改某个基础设施信息
export const updateInfrastructureInfo = (id, data) => request({ url: `/infrastructure/${id}`, method: 'put', data })

// 补丁修改某个基础设施信息
export const updatePatchInfrastructureInfo = (id, data) => request({ url: `/infrastructure/${id}`, method: 'patch', data })

// 添加基础设施信息
export const addInfrastructureInfo = data => request({ url: '/infrastructure/add', method: 'post', data })

// 删除某个基础设施信息
export const removeOneInfrastructureInfo = id => request({ url: `/infrastructure/${id}/off`, method: 'post' })

// 获取某些基础设施信息
export const getMoreInfrastructureInfo = ({ infra_code, infra_name, construction_unit }, page, limit) => request({ url: `/infrastructure/moreinfo?infra_code=${infra_code}&infra_name=${infra_name}&construction_unit=${construction_unit}&page=${page}&limit=${limit}`, method: 'get' })

// 批量删除基础设施信息
export const batchRemoveInfrastructureInfo = (ids) => request({ url: '/infrastructure/batchremove', method: 'post', data: ids })
