import request from '@/utils/request'

// 获取财务信息
export const getFinanceInfo = (params) => request({ url: '/finance/info', method: 'get', params })

// 修改财务信息
export const updateFinanceInfo = (id, data) => request({ url: `/finance/${id}`, method: 'put', data })

// 新增财务信息
export const addFinanceInfo = data => request({ url: '/finance/add', method: 'post', data })

// 删除财务信息
export const removeFinanceInfo = id => request({ url: `/finance/info/${id}/off`, method: 'post' })

// 批量删除财务信息
export const batchRemoveFinanceInfo = ids => request({ url: '/finance/info/batchremove', method: 'post', data: ids })

// 下载Excel表格模板
// export const downloadFinanceTemplate = (params) => request.get('/finance/download', {
//   params,
//   responseType: 'arraybuffer'
// })

// 导入Excel表格信息
export const leadFinanceInfo = (formData) => request({ url: '/finance/lead', method: 'post', data: formData })

// 导出Excel表格信息
export const deriveFinanceInfo = () => request.get('/finance/derive', { responseType: 'blob' })
