<template>
  <el-card>
    <div slot="header" class="header">
      <div class="category-header">
        <span>支出类别占比</span>
        <el-radio-group v-model="value">
          <el-radio-button label="全部渠道" />
          <el-radio-button label="线上" />
          <el-radio-button label="实体" />
        </el-radio-group>
      </div>
    </div>
    <div>
      <div ref="charts" class="charts" />
    </div>
  </el-card>
</template>

<script>
import * as echarts from 'echarts'
export default {
  name: 'Category',
  data() {
    return {
      value: '全部渠道'
    }
  },
  mounted() {
    // 饼图
    const mychart = echarts.init(this.$refs.charts)
    mychart.setOption({
      title: {
        text: '支出类别',
        subtext: 1048,
        left: 'center',
        top: 'center'
      },
      tooltip: {
        trigger: 'item'
      },
      series: [
        {
          name: 'Access From',
          type: 'pie',
          radius: ['40%', '70%'],
          avoidLabelOverlap: false,
          itemStyle: {
            borderRadius: 10,
            borderColor: '#fff',
            borderWidth: 2
          },
          label: {
            show: true,
            position: 'outside'
          },
          labelLine: {
            show: true
          },
          data: [
            { value: 1048, name: '农业' },
            { value: 735, name: '渔业' },
            { value: 580, name: '其他' },
            { value: 484, name: '集体经济' },
            { value: 300, name: '畜牧业' }
          ]
        }
      ]
    })
    // 绑定事件
    mychart.on('mouseover', params => {
      // 获取鼠标移上去的那条数据
      const { name, value } = params.data
      // 重新设置标题
      mychart.setOption({
        title: {
          text: name,
          subtext: value
        }
      })
    })
  }
}
</script>

<style scoped>
.category-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header {
  border-bottom: 1px solid #eee;
}

.charts {
  width: 100%;
  height: 300px;
}
</style>
