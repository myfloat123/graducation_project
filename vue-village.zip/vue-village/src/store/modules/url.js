const state = {
  url: ''
}
const actions = {}
const mutations = {
  SET_URL(state, urlPath) {
    state.url = urlPath
    window.localStorage.setItem('fullpath', state.url)
  }
}
const getters = {}

export default {
  state,
  actions,
  mutations,
  getters
}
