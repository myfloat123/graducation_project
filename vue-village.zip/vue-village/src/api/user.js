import request from '@/utils/request'

export const Login = data => request({ url: '/users/login', method: 'post', data })

export function getInfo(token) {
  return request({
    url: '/users/',
    method: 'get',
    params: { token }
  })
}

export function Logout() {
  return request({
    url: '/users/logout',
    method: 'post'
  })
}

export const updatePassword = data => request({ url: '/users/', method: 'patch', data })
